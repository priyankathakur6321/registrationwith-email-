

# import random
# nn = random.randint(100000, 999970)
# print(nn)
import random, string
from datetime import timedelta

from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.hashers import check_password
from django.contrib import auth, messages
from django.contrib.auth import (authenticate, login, logout,
                                 update_session_auth_hash)
from django.contrib.auth.decorators import login_required
# from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import EmailMultiAlternatives, send_mail
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import redirect, render
from django.template.loader import get_template, render_to_string
from django.urls import reverse
from django.utils.encoding import force_bytes, force_text, smart_str
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
# Create your views here.
from frontapp.forms import *
from frontapp.tokens import account_activation_token
from rental import settings
from django.db.models import Q
from dashboardapp.forms import *
from dashboardapp.models import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import math
import razorpay

# razorpay_client = razorpay.Client(auth=("<APP_ID>", "<APP_SECRET>"))
client = razorpay.Client(auth=("rzp_live_c83sUmQ3yMtXpC", "XFZnvjjm9NuW8g787OSiVZKX"))
# client = razorpay.Client(auth=("rzp_test_Y53WgGWRDGgYnS", "KTEsyDoAATPWfPrhiKWYAmDP"))
from rental.settings import DEFAULT_FROM_EMAIL, BASE_DIR
from dashboardapp.decorators import *

key = 'V/eW+6qrm60-Bw8qAXFEKBlvbeOwyrVmMQD5AGl2f5'

from .messages_send import *

# for image compression
from PIL import Image
import PIL
import os
import glob
from PIL import ImageFile

ImageFile.LOAD_TRUNCATED_IMAGES = True


def handler(request, *args, **argv):
    return render(request, "error-page.html", locals())


def apply_coupen(request):
    ref_code = request.GET.get('ref_code')
    if ref_code:
        budget = ref_code.split('-')
        ref_id = budget[1]
        try:
            if budget[1]:
                id = budget[1]
                data = User.objects.get(id=id)

                if request.user.id == int(ref_id):

                    refrel_point = data.refrel_point + 0
                    messages = 'Referral code invalid'
                else:

                    refrel_point = data.refrel_point + 200
                    messages = 'Referral code apply successfully'

                User.objects.filter(id=id).update(refrel_point=refrel_point, refrel_status=0)

            else:
                messages = 'Referral code invalid'
        except:
            messages = 'Referral code invalid'
    else:
        messages = 'Somthing went wrong'
    return render(request, 'apply_copen_code.html', locals())


def cart_count(request):
    cart_id = "not_exist"
    result_list = tb_property.objects.filter(js_cart_id='gjkgylt7l8')

    if 'session_cart_id' in request.session:
        cart_id = request.session['session_cart_id']
        result_list = tb_property.objects.filter(js_cart_id=cart_id)
    if request.user.is_authenticated:
        result_list = tb_property.objects.filter(user_id=request.user.username)
    my_cart_count = len(result_list)
    return my_cart_count


def index(request):
    request.session['go_to'] = "/"
    request.session['city_selcetd'] = False
    request.session['city_id'] = []
    state_list = Cities_db.objects.filter(
        state_id__in=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
                      28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40])
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    form = Front_Filter_Form()
    form_pg = Front_Filter_Form_PG()
    my_cart_count = cart_count(request)
    latest_result_list = tb_property.objects.filter().order_by('-property_id')[:13]
    top_result_list = tb_property.objects.filter()[:13]
    newset_result_list = tb_property.objects.filter().order_by('-property_id')[:16]
    all_testimonials = tb_testimonials.objects.filter(active=True)[:15]
    home_features_list = tb_home_feature.objects.filter(status=True)
    # return render(request, 'index.html', locals())
    return render(request, 'new-index.html', locals())


def support(request):
    request.session['go_to'] = "/support"

    list = Faq_db.objects.all()
    my_cart_count = cart_count(request)
    if request.method == "POST":
        email = request.POST.get('email', '')
        description = request.POST.get('description', '')
        obj = support_db()
        obj.email = email
        obj.description = description
        obj.save()
        messages.success(request, 'Thank You For Submit.')
        d = ({})
        plaintext = get_template('email.txt')
        htmly = get_template('registration/support-email.html')
        subject, from_email, to = 'Welcome to Rade ONN Support', settings.DEFAULT_FROM_EMAIL, email
        text_content = plaintext.render(d)
        html_content = htmly.render(d)
        msg = EmailMultiAlternatives(
            subject, text_content, from_email, [to])
        msg.attach_alternative(html_content, "text/html")
        msg.send()
    else:
        q = request.GET.get('q', '')
        list = Faq_db.objects.filter(Q(title__contains=q) | Q(description__contains=q))
    page = request.GET.get('page', 1)

    paginator = Paginator(list, 10)
    try:
        list = paginator.page(page)
    except PageNotAnInteger:
        list = paginator.page(10)
    except EmptyPage:
        list = paginator.page(paginator.num_pages)
    return render(request, 'support.html', locals())


def aboutus(request):
    request.session['go_to'] = "/about-us"
    my_cart_count = cart_count(request)
    return render(request, 'aboutus.html', locals())


@login_required(login_url="login")
def account_details(request):
    my_cart_count = cart_count(request)
    if request.method == "POST":
        user_data = User.objects.get(id=request.user.id)
        user_data.bank_name = request.POST.get('bankname', '')
        user_data.bank_account = request.POST.get('account_number', '')
        user_data.account_holder_name = request.POST.get('holdername', '')
        user_data.ifse_code = request.POST.get('ifsc_code', '')
        user_data.save()
        messages.success(request, "Bank account successfully add.")

        print()
    else:
        print()
    list = User.objects.get(id=request.user.id)
    return render(request, 'account-details.html', locals())


@login_required(login_url="login")
def WithdrawalRequest(request):
    if request.method == "POST":
        user_data = User.objects.get(id=request.user.id)
        points = int(request.POST.get('points', ''))
        if points >= 100:
            from datetime import datetime
            now = datetime.now()
            messages.success(request, 'Withdrawal request successfully send.')
            user_data = User.objects.get(id=request.user.id)
            user_data.refrel_status = 1
            user_data.refrel_date = now.strftime("%d %B, %Y")
            user_data.save()
        else:
            messages.success(request, 'Insufficient balance')

    return redirect('/account-details')


@login_required(login_url="login")
def accept_property(request, new_id):
    my_cart_count = cart_count(request)
    list = Propety_Report.objects.filter(type=1, id=new_id)
    new_list = []
    for x in list:
        get_room_slug = x.new_property
        bad_chars = ["['", "'", "]", " ", "UUID(", ")", "["]
        for i in bad_chars:
            get_room_slug = get_room_slug.replace(i, '')
        my_list = get_room_slug.split(",")
        new_list += my_list
    result_list = tb_property.objects.filter(property_id__in=new_list)
    if request.method == "POST":
        checkassign = request.POST.get('status', '')

        from datetime import datetime
        now = datetime.now()
        new_obj = tb_cart()
        new_obj.payment_status = True
        new_obj.id = User.objects.get(id=request.user.id)
        new_obj.total_amount = 0
        new_obj.room_id = [checkassign]
        new_obj.order_id = 'repoted'
        new_obj.order_id = 'repoted'
        new_obj.added_date = now.strftime("%d %B, %Y")
        new_obj.save()
        Propety_Report.objects.filter(users_id=request.user.id, id=new_id).update(type=3)
        messages.success(request, "Property Successfully Add on Your Order.")
        result_list = ''
    return render(request, 'accept-property.html', locals())


def share_your_requirment(request):
    request.session['go_to'] = "/share-your-requirment"
    my_cart_count = cart_count(request)
    if request.method == "POST":
        obj = Propety_Requirment()
        obj.name = request.POST.get('name', '')
        obj.state = request.POST.get('state', '')
        obj.district = request.POST.get('district', '')
        obj.type = request.POST.get('type', '')
        if request.POST.get('share_bedroom', ''):
            obj.bedroom = request.POST.get('share_bedroom', '')
        else:
            obj.bedroom = request.POST.get('bedroom', '')
        obj.preference = request.POST.get('preference', '')
        obj.min_budget = request.POST.get('min_budget', '')
        obj.max_budget = request.POST.get('max_budget', '')
        obj.phone = request.POST.get('phone', '')
        obj.email = request.POST.get('email', '')
        obj.save()
        messages.success(request, "We'll Contact you soon as we found availability of your requirement.")
    else:
        pass
    return render(request, 'share-your-requirment.html', locals())


@login_required(login_url="login")
def property_edit(request, property_id):
    list_tb_property = tb_property.objects.get(property_id=property_id)

    if list_tb_property.is_pg:
        xx = '/edit-pg-form/' + str(property_id)
        return redirect(xx)

    if list_tb_property.is_rent:
        xx = '/edit-rent-form/' + str(property_id)
        return redirect(xx)


# send data to edit for pg
@login_required(login_url="login")
def edit_pg_form(request, property_id):
    print("pg_edit-------------------------")
    update_profile_data = User.objects.get(id=request.user.id)
    update_profile_data.email = request.user.email
    update_profile_data.phone = request.user.phone
    update_profile_data.phone2 = request.user.phone2
    update_profile_data.save()

    my_cart_count = cart_count(request)
    list = tb_property.objects.get(property_id=property_id)
    state_list = States_db.objects.filter(country_id=101)
    city_list = Cities_db.objects.filter(state_id=list.state.id)
    locality_list = Locality_db.objects.filter(city_id=list.district.id)
    image_list = tb_property_images.objects.filter(property_id=property_id)
    image_list_count = tb_property_images.objects.filter(property_id=property_id).count()

    attributes = Attributes_Db.objects.all()
    terms = Terms_Db.objects.all()
    property_type = Property_Type.objects.all()
    property_title = Property_Title.objects.all()
    term_values = []
    terms_vals = Terms_Values.objects.filter(property_id=property_id).values("title")
    for term_val in terms_vals:
        k = term_val['title']
        term_values.append(k)

    return render(request, 'edit-pg-form.html', locals())


# send data to edit for rent
@login_required(login_url="login")
def edit_rent_form(request, property_id):
    print("rent_edit-------------------------")

    update_profile_data = User.objects.get(id=request.user.id)
    update_profile_data.email = request.user.email
    update_profile_data.phone = request.user.phone
    update_profile_data.phone2 = request.user.phone2
    update_profile_data.save()

    my_cart_count = cart_count(request)
    list = tb_property.objects.get(property_id=property_id)
    state_list = States_db.objects.filter(country_id=101)
    city_list = Cities_db.objects.filter(state_id=list.state.id)
    locality_list = Locality_db.objects.filter(city_id=list.district.id)
    image_list = tb_property_images.objects.filter(property_id=property_id)
    image_list_count = tb_property_images.objects.filter(property_id=property_id).count()

    attributes = Attributes_Db.objects.all()
    terms = Terms_Db.objects.all()
    property_type = Property_Type.objects.all()
    property_title = Property_Title.objects.all()
    term_values = []
    terms_vals = Terms_Values.objects.filter(property_id=property_id).values("title")
    for term_val in terms_vals:
        k = term_val['title']
        term_values.append(k)

    return render(request, 'edit-rent-form.html', locals())


def terms_condition(request):
    request.session['go_to'] = "/terms-condition"
    my_cart_count = cart_count(request)
    return render(request, 'terms-condition.html', locals())


def privacy_policy(request):
    request.session['go_to'] = "/privacy-policy"
    my_cart_count = cart_count(request)
    return render(request, 'privacy-policy.html', locals())


def property_list(request):
    request.session['go_to'] = "/property-list"
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    xxxx = "All Property"
    result_list = tb_property.objects.filter(added_to_cart=False, is_rent=True).order_by('-property_id')

    if request.method == "POST":
        print("user_cart_id", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']
        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        print("extra_charges -", extra_charges, "\n room_charges - ", room_charges, "\n", "cart -id", user_cart_id)
        property_id = request.POST['property_id']

        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)
    attributes = Attributes_Db.objects.filter(use_in_filtering=True)
    terms = Terms_Db.objects.all()

    len = result_list.count()
    page = request.GET.get('page', 1)
    paginator = Paginator(result_list, 10)
    try:
        result_list = paginator.page(page)
    except PageNotAnInteger:
        result_list = paginator.page(1)
    except EmptyPage:
        result_list = paginator.page(paginator.num_pages)

    return render(request, 'property-list.html', locals())


def attributes_url(request, attributes_slug):
    request.session['go_to'] = "/attributes_slug"

    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    xxxx = "All Property"

    if request.method == "POST":
        print("user_cart_id", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']
        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        print("extra_charges -", extra_charges, "\n room_charges - ", room_charges, "\n", "cart -id", user_cart_id)
        property_id = request.POST['property_id']
        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)

    # to search property with attributes in url
    if attributes_slug:

        if attributes_slug in [c.slug for c in Attributes_Db.objects.all()]:
            attrs = Attributes_Db.objects.filter(slug=attributes_slug).values('id', 'title', 'slug')
            for attr in attrs:
                attr_id = attr['id']

            my_attrs = Attributes_Values.objects.values('attributes_id', 'property_id')
            new_id = []
            for my_attr in my_attrs:
                my_attr_id = my_attr['attributes_id']
                my_attr_pro_id = my_attr['property_id']
                if attr_id == my_attr_id:
                    pro_id = my_attr_pro_id
                    new_id.append(pro_id)

            result_list = tb_property.objects.filter(property_id__in=new_id).order_by('-property_id')
            len = result_list.count()
            page = request.GET.get('page', 1)
            paginator = Paginator(result_list, 10)
            try:
                result_list = paginator.page(page)
            except PageNotAnInteger:
                result_list = paginator.page(1)
            except EmptyPage:
                result_list = paginator.page(paginator.num_pages)

    return render(request, 'property-list.html', locals())


def terms_url(request, attributes_slug, terms_slug):
    request.session['go_to'] = "/attributes_slug/terms_slug"

    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    xxxx = "All Property"

    if request.method == "POST":
        print("user_cart_id", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']
        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        print("extra_charges -", extra_charges, "\n room_charges - ", room_charges, "\n", "cart -id", user_cart_id)
        property_id = request.POST['property_id']
        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)

    #  to search property with attributes and terms in urls
    if attributes_slug:

        if attributes_slug in [c.slug for c in Attributes_Db.objects.all()]:
            attrs = Attributes_Db.objects.filter(slug=attributes_slug).values('id', 'title', 'slug')
            for attr in attrs:
                attr_id = attr['id']

            my_attrs = Terms_Values.objects.values('title', 'attributes_id', 'property_id')
            new_id = []
            for my_attr in my_attrs:
                my_attr_id = my_attr['attributes_id']
                my_attr_pro_id = my_attr['property_id']
                my_attr_terms_title = my_attr['title']
                if attr_id == my_attr_id and my_attr_terms_title in [c.title for c in
                                                                     Terms_Db.objects.filter(slug=terms_slug)]:
                    pro_id = my_attr_pro_id
                    new_id.append(pro_id)

            result_list = tb_property.objects.filter(property_id__in=new_id).order_by('-property_id')
            len = result_list.count()
            page = request.GET.get('page', 1)
            paginator = Paginator(result_list, 10)
            try:
                result_list = paginator.page(page)
            except PageNotAnInteger:
                result_list = paginator.page(1)
            except EmptyPage:
                result_list = paginator.page(paginator.num_pages)

    return render(request, 'property-list.html', locals())


# to view properties
def view_pg_rent_property(request, uidb64):
    myurl = f"/view-details/{uidb64}"
    request.session['go_to'] = myurl
    go_pro_id = int(uidb64)
    if 'back_to' in request.session:
        back_to = request.session['back_to']
    # calculating views on a property
    if request.user.is_authenticated:
        my_user = request.user.id
        if int(uidb64) in [c.property_id for c in Views_On_Property.objects.all()]:
            if my_user not in [c.user_id for c in Views_On_Property.objects.filter(property_id=int(uidb64))]:
                obj_view = Views_On_Property()
                obj_view.property_id = int(uidb64)
                obj_view.user_id = request.user.id
                obj_view.total_count = +1
                obj_view.save()

        if int(uidb64) not in [c.property_id for c in Views_On_Property.objects.filter(user_id=request.user.id)]:
            obj_view = Views_On_Property()
            obj_view.property_id = int(uidb64)
            obj_view.user_id = request.user.id
            obj_view.total_count = +1
            obj_view.save()

        if int(uidb64) not in [c.property_id for c in Views_On_Property.objects.all()] and my_user not in [c.user_id for
                                                                                                           c in
                                                                                                           Views_On_Property.objects.all()]:
            obj_view = Views_On_Property()
            obj_view.property_id = int(uidb64)
            obj_view.user_id = request.user.id
            obj_view.total_count = +1
            obj_view.save()

    else:
        if 'set_my_id' not in request.session:
            randomnumber = random.randint(-50000, -11)

            if randomnumber not in [c.user_id for c in Views_On_Property.objects.all()]:
                request.session['set_my_id'] = randomnumber
            else:
                randomnumber = random.randint(-50000, -11)
                print(randomnumber)
            request.session['set_my_id'] = randomnumber

        if 'set_my_id' in request.session:
            my_user = request.session['set_my_id']

        # for not logined user
        if int(uidb64) in [c.property_id for c in Views_On_Property.objects.all()]:
            if my_user not in [c.user_id for c in Views_On_Property.objects.filter(property_id=int(uidb64))]:
                obj_view = Views_On_Property()
                obj_view.property_id = int(uidb64)
                obj_view.user_id = my_user
                obj_view.total_count = +1
                obj_view.save()

        if int(uidb64) not in [c.property_id for c in Views_On_Property.objects.filter(user_id=my_user)]:
            obj_view = Views_On_Property()
            obj_view.property_id = int(uidb64)
            obj_view.user_id = my_user
            obj_view.total_count = +1
            obj_view.save()

        if int(uidb64) not in [c.property_id for c in Views_On_Property.objects.all()] and my_user not in [c.user_id for
                                                                                                           c in
                                                                                                           Views_On_Property.objects.all()]:
            obj_view = Views_On_Property()
            obj_view.property_id = int(uidb64)
            obj_view.user_id = my_user
            obj_view.total_count = +1
            obj_view.save()

    property_views = Views_On_Property.objects.filter(property_id=int(uidb64)).distinct()

    pcount = property_views.count()
    tb_property.objects.filter(property_id=uidb64).update(total_count=pcount)

    # .===========end of calculating view script=======

    from datetime import datetime
    now = datetime.now()
    today_date = now.strftime("%m/%d/%Y")

    review_list = review_db.objects.filter(property_id=uidb64).order_by('-id')[:5]
    review_list_count = review_db.objects.filter(property_id=uidb64).count()
    review_list_5 = review_db.objects.filter(property_id=uidb64, rating1='5').count()
    review_list_4 = review_db.objects.filter(property_id=uidb64, rating1='4').count()
    review_list_3 = review_db.objects.filter(property_id=uidb64, rating1='3').count()
    review_list_2 = review_db.objects.filter(property_id=uidb64, rating1='2').count()
    review_list_1 = review_db.objects.filter(property_id=uidb64, rating1='1').count()
    if review_list:
        review_list_avrage = (
                                     5 * review_list_5 + 4 * review_list_4 + 3 * review_list_3 + 2 * review_list_2 + 1 * review_list_1) / review_list_count
    else:
        review_list_avrage = 0
    property_data = tb_property.objects.get(property_id=uidb64)
    latest_result_list = tb_property.objects.filter(is_pg=property_data.is_pg, is_rent=property_data.is_rent,
                                                    rooms_pg=property_data.rooms_pg,
                                                    rooms_rent=property_data.rooms_rent,
                                                    prefered_tenant=property_data.prefered_tenant,
                                                    prefered_tenant_type=property_data.prefered_tenant_type).order_by(
        '-property_id')[:13]

    if request.method == "POST":
        print("user_cart_id--", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']

        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_data.property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_data.property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)
    attributes = Attributes_Values.objects.filter(property_id=uidb64)
    terms = Terms_Values.objects.filter(property_id=uidb64)

    # to print date or immidate (avialabilty from)
    new_today_date = today_date.split("/")
    print(new_today_date)
    k = tb_property.objects.filter(property_id=uidb64).values("availabilty")
    for i in k:
        if i['availabilty']:
            new_avail_date = i['availabilty'].split("/")
            if int(new_avail_date[-1]) < int(new_today_date[-1]):
                avail_date = "Immediate"
            if int(new_avail_date[-1]) == int(new_today_date[-1]) and int(new_avail_date[0]) < int(new_today_date[0]):
                avail_date = "Immediate"
            if int(new_avail_date[-1]) == int(new_today_date[-1]) and int(new_avail_date[0]) == int(
                    new_today_date[0]) and int(new_avail_date[1]) <= int(new_today_date[1]):
                avail_date = "Immediate"

    # if username is phone number then show radeonn(as owner)
    posted_u = [c.posted_user_name for c in tb_property.objects.filter(property_id=int(uidb64))]
    if posted_u[0] in [c.phone for c in User.objects.all()]:
        new_user_name = "radeonn"

    return render(request, 'single-property.html', locals())


def Notifiy_me(request):
    request.session['go_to'] = "/Notifiy_me"
    if request.method == "POST":
        property_id = request.POST.get('property_id', '')
        email = request.POST.get('email', '')
        obj = tb_property.objects.get(property_id=property_id)
        aaa = notify_property()
        aaa.property_id = obj
        aaa.email = email
        aaa.save()
        messages.success(request, 'Thank You For Submit.')

        xxx = "/view-details/" + str(property_id)
    return redirect(xxx, locals())


def Report_propert(request):
    if request.method == "POST":
        property_id = request.POST.get('property_id', '')
        email = request.POST.get('email', '')
        username = request.POST.get('username', '')
        subject = request.POST.get('subject', '')
        description = request.POST.get('description', '')
        obj = tb_property.objects.get(property_id=property_id)
        users_id = User.objects.get(id=request.user.id)
        dddd = Propety_Report()
        dddd.email = email
        dddd.property_id = obj
        dddd.users_id = users_id
        dddd.username = username
        dddd.subject = subject
        dddd.description = description
        dddd.save()
        messages.success(request, 'Thank You For Submit Report')
        d = ({'username': username})
        plaintext = get_template('email.txt')
        htmly = get_template('registration/report-submit.html')
        subject, from_email, to = 'Radeonn Report Submitted', settings.DEFAULT_FROM_EMAIL, email
        text_content = plaintext.render(d)
        html_content = htmly.render(d)
        msg = EmailMultiAlternatives(
            subject, text_content, from_email, [to])
        msg.attach_alternative(html_content, "text/html")
        msg.send()

        return redirect('/my-orders', locals())


def Review_feedback(request):
    request.session['go_to'] = "/Review_feedback"
    if request.method == "POST":
        property_id = request.POST.get('property_id', '')
        rating = request.POST.get('rating', '')
        email = request.POST.get('email', '')
        username = request.POST.get('username', '')
        obj = tb_property.objects.get(property_id=property_id)
        dddd = review_db()
        dddd.property_id = obj
        dddd.rating1 = rating
        dddd.email = email
        dddd.name = username
        dddd.save()
        messages.success(request, 'Thank You For Submit Feedback')
        d = ({})
        plaintext = get_template('email.txt')
        htmly = get_template('registration/feedback-email.html')
        subject, from_email, to = 'Thank you for feedback', settings.DEFAULT_FROM_EMAIL, email
        text_content = plaintext.render(d)
        html_content = htmly.render(d)
        msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
        msg.attach_alternative(html_content, "text/html")
        msg.send()
        return redirect('/my-orders', locals())


def rent_property(request):
    request.session['back_to'] = "rent"
    print("rent ----properties-------------")
    request.session['go_to'] = "/rent-property"
    xxxx = "Rent Property"
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    result_list = tb_property.objects.filter(added_to_cart=False, is_rent=True, is_pg=False).order_by('property_id')
    print(result_list.count())
    if request.method == "POST":
        print("user_cart_id", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']
        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        print("extra_charges -", extra_charges, "\n room_charges - ", room_charges, "\n", "cart -id", user_cart_id)
        property_id = request.POST['property_id']
        print()
        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)
    attributes = Attributes_Db.objects.filter(is_rent=True, use_in_filtering=True)
    is_rent = True
    terms = Terms_Db.objects.all()

    len = result_list.count()

    page = request.GET.get('page', 1)
    paginator = Paginator(result_list, 10)
    try:
        result_list = paginator.page(page)
    except PageNotAnInteger:
        result_list = paginator.page(1)
    except EmptyPage:
        result_list = paginator.page(paginator.num_pages)
    return render(request, 'property-list.html', locals())


def pg_property(request):
    print("pg ----properties-------------")
    request.session['back_to'] = "pg"
    request.session['go_to'] = "/pg-property"
    xxxx = "PG Property"
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])
    result_list = tb_property.objects.filter(added_to_cart=False, is_rent=False, is_pg=True).order_by('property_id')
    if request.method == "POST":
        print("user_cart_id", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']
        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        print("extra_charges -", extra_charges, "\n room_charges - ", room_charges, "\n", "cart -id", user_cart_id)
        property_id = request.POST['property_id']

        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)
    attributes = Attributes_Db.objects.filter(is_pg=True, use_in_filtering=True, )
    terms = Terms_Db.objects.all()

    len = result_list.count()

    page = request.GET.get('page', 1)
    paginator = Paginator(result_list, 10)
    try:
        result_list = paginator.page(page)
    except PageNotAnInteger:
        result_list = paginator.page(1)
    except EmptyPage:
        result_list = paginator.page(paginator.num_pages)
    return render(request, 'pg-list.html', locals())


# filter by for rent
def search_list(request):
    print("search-list-------------------------")
    request.session['go_to'] = "/search_list"
    xxxx = "Search Property"
    print(xxxx)
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    if request.method == "POST":
        not_null = 0
        bhk = request.POST.getlist('bhk[]')
        type_of_property = request.POST.getlist('type_of_property')
        furnished_status = request.POST.getlist('furnished_status')
        prefered_tenant = request.POST.getlist('prefered_tenant')
        occupation = request.POST.getlist('occupation')
        Live_in = request.POST.get('Live_in', '')
        city = request.POST.getlist('city')
        Kitchen_self = request.POST.get('Kitchen_self', '')
        city_select = request.POST.getlist('city_select', '')
        yyyy = request.POST.getlist('yyyy', '')
        xxxx = request.POST.getlist('xxxx', '')
        locality_select = request.POST.getlist('locality_select', '')
        Park = request.POST.get('Park', '')
        PowerBackup = request.POST.get('PowerBackup', '')
        Lift = request.POST.get('Lift', '')
        fridge = request.POST.get('fridge', '')
        Gymnasium = request.POST.get('Gymnasium', '')
        SwimmingPool = request.POST.get('SwimmingPool', '')
        ClubHouse = request.POST.get('ClubHouse', '')
        TV = request.POST.get('TV', '')
        CCTV = request.POST.get('CCTV', '')
        WheelchairFriendly = request.POST.get('WheelchairFriendly', '')
        Owner_Free = request.POST.get('Owner_Free', '')
        with_image = request.POST.get('with_image', '')
        VisitorParking = request.POST.get('VisitorParking', '')
        WiFi = request.POST.get('WiFi', '')
        DiningTable = request.POST.get('DiningTable', '')
        maxprice = request.POST.get('maxprice', '')
        minprice = request.POST.get('minprice', '')

        budget_start_range = minprice
        budget_end_range = maxprice
        rent_property_type = request.POST.get('rent_property_type')
        if city_select:
            print("")
            print("got city--")
        else:
            if yyyy:
                city_select = yyyy
            else:
                if xxxx:
                    city_select = xxxx

        if city_select:
            print(city_select, "updated city------------")
            district = []
            for i in city_select:
                if i[0] in "0123456789":
                    district.append(str(i))
                else:
                    city_data = Cities_db.objects.filter(name=i).values('id', 'name')

                    for citydata in city_data:
                        city_id = citydata['id']
                        city_name = citydata['name']
                        district.append(str(city_id))
        district_Q = Q()
        if district:
            print("district----", district)
            district_Q = Q(district__in=district)

        locality_Q = Q()
        if locality_select:
            print("locality_select----", locality_select)
            not_null = 1
            locality_Q = Q(locality__in=locality_select)
        rent_property_list_Q = Q()
        if rent_property_type:
            print(rent_property_type, "rent_property_type----------")
            rent_property_list_Q = Q(title=rent_property_type)

        budget_end_range_Q = Q()
        if budget_end_range:
            print(budget_end_range, "budget_end_range----------")
            budget_end_range_Q = Q(total_rent__lte=int(budget_end_range))

        budget_start_range_Q = Q()
        if budget_start_range:
            print(budget_start_range, "budget_start_range----------")
            budget_start_range_Q = Q(total_rent__gte=int(budget_start_range))

        maxprice_Q = Q()
        minprice_Q = Q()
        if maxprice:
            not_null = 1
            maxprice_Q = Q(total_rent__lte=int(maxprice))
        if minprice:
            not_null = 1
            minprice_Q = Q(total_rent__gte=int(minprice))
        bhk_Q = Q()
        if bhk:
            not_null = 1
            bhk_Q = Q(rooms_rent__in=bhk)
        type_of_property_Q = Q()
        if type_of_property:
            not_null = 1
            type_of_property_Q = Q(rent_property_type__in=type_of_property)
        Park_Q = Q()
        if Park:
            not_null = 1
            Park_Q = Q(Park=Park)
        PowerBackup_Q = Q()
        if PowerBackup:
            not_null = 1
            PowerBackup_Q = Q(PowerBackup=PowerBackup)
        Lift_Q = Q()
        if Lift:
            not_null = 1
            Lift_Q = Q(Lift=Lift)
        fridge_Q = Q()
        if fridge:
            not_null = 1
            fridge_Q = Q(fridge=fridge)
        Gymnasium_Q = Q()
        if Gymnasium:
            not_null = 1
            Gymnasium_Q = Q(Gymnasium=Gymnasium)
        SwimmingPool_Q = Q()
        if SwimmingPool:
            not_null = 1
            SwimmingPool_Q = Q(SwimmingPool=SwimmingPool)
        ClubHouse_Q = Q()
        if ClubHouse:
            not_null = 1
            ClubHouse_Q = Q(ClubHouse=ClubHouse)
        TV_Q = Q()
        if TV:
            not_null = 1
            TV_Q = Q(TV=TV)
        CCTV_Q = Q()
        if CCTV:
            not_null = 1
            CCTV_Q = Q(CCTV=CCTV)
        occupation_Q = Q()
        if occupation:
            not_null = 1
            occupation_Q = Q(occupation__in=occupation)
        WheelchairFriendly_Q = Q()
        if WheelchairFriendly:
            not_null = 1
            WheelchairFriendly_Q = Q(WheelchairFriendly=WheelchairFriendly)
        VisitorParking_Q = Q()
        if VisitorParking:
            not_null = 1
            VisitorParking_Q = Q(VisitorParking=VisitorParking)
        WiFi_Q = Q()
        if WiFi:
            not_null = 1
            WiFi_Q = Q(WiFi=WiFi)
        DiningTable_Q = Q()
        if DiningTable:
            not_null = 1
            DiningTable_Q = Q(DiningTable=DiningTable)
        Kitchen_self_Q = Q()
        if Kitchen_self:
            not_null = 1
            Kitchen_self_Q = Q(Kitchen_self=Kitchen_self)
        prefered_tenant_Q = Q()
        if prefered_tenant:
            not_null = 1
            prefered_tenant_Q = Q(prefered_tenant_type__in=prefered_tenant)
        Live_in_Q = Q()
        if Live_in:
            not_null = 1
            prefered_tenant_Q = Q(for_livein=True)
        furnished_status_Q = Q()
        if furnished_status:
            not_null = 1
            furnished_status_Q = Q(furnished_status__in=furnished_status)
        Owner_Free_Q = Q()
        if Owner_Free:
            not_null = 1
            Owner_Free_Q = Q(Owner_Free=True)
        with_image_Q = Q()
        if with_image:
            not_null = 1
            print()
            list_query = tb_property_images.objects.all()
            lsit_id = []
            for list_query in list_query:
                lsit_id.append(list_query.property_id_id)
            with_image_Q = Q(property_id__in=lsit_id)

        # filter on attributes
        attributes_terms_Q = Q()
        my_terms = Terms_Db.objects.values('slug', 'title', 'attributes_id')

        for myterms in my_terms:
            term_slug = myterms['slug']
            term_title = myterms['title']
            attr_id = myterms['attributes_id']
            res = request.POST.get(term_slug)
            if res == "True":
                my_attrs = Terms_Values.objects.values('title', 'attributes_id', 'property_id')
                new_id = []
                for my_attr in my_attrs:
                    my_attr_id = my_attr['attributes_id']
                    my_attr_pro_id = my_attr['property_id']
                    my_attr_terms_title = my_attr['title']
                    if attr_id == my_attr_id and my_attr_terms_title in [c.title for c in
                                                                         Terms_Db.objects.filter(slug=term_slug)]:
                        pro_id = my_attr_pro_id
                        new_id.append(pro_id)
                if new_id:
                    not_null = 1
                    attributes_terms_Q = Q(property_id__in=new_id)
                    result = tb_property.objects.filter(property_id__in=new_id)
                # else:
                #     attributes_terms_Q = Q(property_id__in=str(0))
                #     print(attributes_terms_Q)
                #     not_null = 1

                new_id_len = len(new_id)
                print(new_id, "----new_id----", new_id_len, "-----new_id_len----")
                if new_id_len == 0:
                    print("under iff====================")
                    attributes_terms_Q = Q(property_id=str(0))
                    print(attributes_terms_Q)
                    not_null = 1

        is_rent_Q = Q(is_rent=True)
        is_pg_Q = Q(is_pg=False)
        added_to_cart_Q = Q(added_to_cart=False)
        if not_null == 1:
            result_list = tb_property.objects.filter(district_Q, locality_Q, budget_end_range_Q, budget_start_range_Q,
                                                     occupation_Q, Live_in_Q, bhk_Q, type_of_property_Q, Park_Q,
                                                     PowerBackup_Q,
                                                     Lift_Q, fridge_Q, Gymnasium_Q, SwimmingPool_Q, ClubHouse_Q, TV_Q,
                                                     CCTV_Q, WheelchairFriendly_Q, VisitorParking_Q, WiFi_Q,
                                                     DiningTable_Q, Kitchen_self_Q, prefered_tenant_Q,
                                                     furnished_status_Q, Owner_Free_Q, with_image_Q, attributes_terms_Q,
                                                     is_rent_Q, added_to_cart_Q, is_pg_Q).distinct().order_by(
                'property_id')
        if not_null == 0:
            result_list = tb_property.objects.filter(district_Q, locality_Q, rent_property_list_Q, budget_end_range_Q,
                                                     budget_start_range_Q, is_rent=True, added_to_cart=False).order_by(
                'property_id')
            if result_list:
                print("")
                print(result_list.count(), "we got--------------------------------")
            else:
                print("else-------------------------------")
                result_list = tb_property.objects.filter(is_rent_Q, added_to_cart=False).distinct()
        rlen = result_list.count()
        print(rlen, "-----------rrrrrlen---------")
        # page = request.GET.get('page', 1)
        # paginator = Paginator(result_list, 10)
        # try:
        #     result_list = paginator.page(page)
        # except PageNotAnInteger:
        #     result_list = paginator.page(10)
        # except EmptyPage:
        #     result_list = paginator.page(paginator.num_pages)
    return render(request, 'property-filter-ajax.html', locals())


# filter by for pg
def pg_search_list(request):
    print("--------filter by for pg-----------")
    request.session['go_to'] = "/pg_search_list"
    xxxx = "Search PG Property"
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    if request.method == "POST":
        not_null = 0
        bhk = request.POST.getlist('bhk[]')
        type_of_property = request.POST.getlist('type_of_property')
        furnished_status = request.POST.getlist('furnished_status')
        prefered_tenant = request.POST.getlist('prefered_tenant')
        city = request.POST.getlist('city')
        Kitchen_self = request.POST.get('Kitchen_self', '')
        Park = request.POST.get('Park', '')
        PowerBackup = request.POST.get('PowerBackup', '')
        Lift = request.POST.get('Lift', '')
        fridge = request.POST.get('fridge', '')
        Gymnasium = request.POST.get('Gymnasium', '')
        SwimmingPool = request.POST.get('SwimmingPool', '')
        ClubHouse = request.POST.get('ClubHouse', '')
        TV = request.POST.get('TV', '')
        CCTV = request.POST.get('CCTV', '')
        WheelchairFriendly = request.POST.get('WheelchairFriendly', '')
        Owner_Free = request.POST.get('Owner_Free', '')
        with_image = request.POST.get('with_image', '')
        print("with_image------------------", with_image)
        VisitorParking = request.POST.get('VisitorParking', '')
        WiFi = request.POST.get('WiFi', '')
        DiningTable = request.POST.get('DiningTable', '')
        city_select = request.POST.getlist('city_select', '')
        yyyy = request.POST.getlist('yyyy', '')
        xxxx = request.POST.getlist('xxxx', '')
        locality_select = request.POST.getlist('locality_select', '')
        maxprice = request.POST.get('maxprice', '')
        minprice = request.POST.get('minprice', '')

        budget_start_range = minprice
        budget_end_range = maxprice
        rent_property_type = request.POST.get('rent_property_type')
        if city_select:
            print("")
            print("got city--")
        else:
            if yyyy:
                city_select = yyyy
            else:
                if xxxx:
                    city_select = xxxx

        if city_select:
            print(city_select, "updated city------------")
            district = []
            for i in city_select:
                if i[0] in "0123456789":
                    district.append(str(i))
                else:
                    city_data = Cities_db.objects.filter(name=i).values('id', 'name')

                    for citydata in city_data:
                        city_id = citydata['id']
                        city_name = citydata['name']
                        district.append(str(city_id))
        district_Q = Q()
        if district:
            print("district----", district)
            district_Q = Q(district__in=district)

        locality_Q = Q()
        if locality_select:
            print("locality_select----", locality_select)
            not_null = 1
            locality_Q = Q(locality__in=locality_select)
        rent_property_list_Q = Q()
        if rent_property_type:
            print(rent_property_type, "rent_property_type----------")
            rent_property_list_Q = Q(rooms_pg=rent_property_type)

        budget_end_range_Q = Q()
        if budget_end_range:
            print(budget_end_range, "budget_end_range----------")
            budget_end_range_Q = Q(total_rent__lte=int(budget_end_range))

        budget_start_range_Q = Q()
        if budget_start_range:
            print(budget_start_range, "budget_start_range----------")
            budget_start_range_Q = Q(total_rent__gte=int(budget_start_range))

        maxprice_Q = Q()
        minprice_Q = Q()
        if maxprice:
            maxprice_Q = Q(total_rent__lte=int(maxprice))
            not_null = 1
        if minprice:
            minprice_Q = Q(total_rent__gte=int(minprice))
            not_null = 1
        bhk_Q = Q()
        if bhk:
            bhk_Q = Q(rooms_rent__in=bhk)
            not_null = 1
        type_of_property_Q = Q()
        if type_of_property:
            type_of_property_Q = Q(rent_property_type__in=type_of_property)
            not_null = 1
        Park_Q = Q()
        if Park:
            Park_Q = Q(Park=Park)
            not_null = 1
        PowerBackup_Q = Q()
        if PowerBackup:
            PowerBackup_Q = Q(PowerBackup=PowerBackup)
            not_null = 1
        Lift_Q = Q()
        if Lift:
            Lift_Q = Q(Lift=Lift)
            not_null = 1
        fridge_Q = Q()
        if fridge:
            fridge_Q = Q(fridge=fridge)
            not_null = 1
        Gymnasium_Q = Q()
        if Gymnasium:
            Gymnasium_Q = Q(Gymnasium=Gymnasium)
            not_null = 1
        SwimmingPool_Q = Q()
        if SwimmingPool:
            SwimmingPool_Q = Q(SwimmingPool=SwimmingPool)
            not_null = 1
        ClubHouse_Q = Q()
        if ClubHouse:
            ClubHouse_Q = Q(ClubHouse=ClubHouse)
            not_null = 1
        TV_Q = Q()
        if TV:
            TV_Q = Q(TV=TV)
            not_null = 1
        CCTV_Q = Q()
        if CCTV:
            CCTV_Q = Q(CCTV=CCTV)
            not_null = 1
        WheelchairFriendly_Q = Q()
        if WheelchairFriendly:
            WheelchairFriendly_Q = Q(WheelchairFriendly=WheelchairFriendly)
            not_null = 1
        VisitorParking_Q = Q()
        if VisitorParking:
            VisitorParking_Q = Q(VisitorParking=VisitorParking)
            not_null = 1
        WiFi_Q = Q()
        if WiFi:
            WiFi_Q = Q(WiFi=WiFi)
            not_null = 1
        DiningTable_Q = Q()
        if DiningTable:
            DiningTable_Q = Q(DiningTable=DiningTable)
            not_null = 1
        Kitchen_self_Q = Q()
        if Kitchen_self:
            Kitchen_self_Q = Q(Kitchen_self=Kitchen_self)
            not_null = 1
        prefered_tenant_Q = Q()
        if prefered_tenant:
            prefered_tenant_Q = Q(prefered_tenant_type__in=prefered_tenant)
            not_null = 1

        if prefered_tenant:
            prefered_tenant_Q = Q(gender_prefer__in=prefered_tenant)
            not_null = 1
        furnished_status_Q = Q()
        if furnished_status:
            furnished_status_Q = Q(furnished_status__in=furnished_status)
            not_null = 1
        Owner_Free_Q = Q()
        if Owner_Free:
            Owner_Free_Q = Q(Owner_Free=True)
            not_null = 1
        with_image_Q = Q()
        if with_image:
            print("yeah ----got image-----------")
            list_query = tb_property_images.objects.all()
            lsit_id = []
            # print(lsit_id,"---------before list")
            for list_query in list_query:
                lsit_id.append(list_query.property_id_id)
            # print(lsit_id, "---------after list")
            with_image_Q = Q(property_id__in=lsit_id)
            not_null = 1

        attributes_terms_Q = Q()
        # filter on attributes of pg
        my_terms = Terms_Db.objects.values('slug', 'title', 'attributes_id')

        for myterms in my_terms:
            term_slug = myterms['slug']
            term_title = myterms['title']
            attr_id = myterms['attributes_id']
            res = request.POST.get(term_slug)
            if res == "True":
                my_attrs = Terms_Values.objects.values('title', 'attributes_id', 'property_id')
                new_id = []
                for my_attr in my_attrs:
                    my_attr_id = my_attr['attributes_id']
                    my_attr_pro_id = my_attr['property_id']
                    my_attr_terms_title = my_attr['title']
                    if attr_id == my_attr_id and my_attr_terms_title in [c.title for c in
                                                                         Terms_Db.objects.filter(slug=term_slug)]:
                        pro_id = my_attr_pro_id
                        new_id.append(pro_id)
                if new_id:
                    attributes_terms_Q = Q(property_id__in=new_id)
                    print(attributes_terms_Q)
                    result = tb_property.objects.filter(property_id__in=new_id)
                    not_null = 1
                else:
                    attributes_terms_Q = Q(property_id__in=str(0))
                    print(attributes_terms_Q)
                    not_null = 1

        is_pg_Q = Q(is_pg=True)
        is_rent_Q = Q(is_rent=False)
        added_to_cart_Q = Q(added_to_cart=False)
        if not_null == 1:
            result_list = tb_property.objects.filter(district_Q, locality_Q, maxprice_Q, minprice_Q, is_rent_Q, is_pg_Q,
                                                     bhk_Q, type_of_property_Q, Park_Q, PowerBackup_Q, Lift_Q, fridge_Q,
                                                     Gymnasium_Q, SwimmingPool_Q, ClubHouse_Q, TV_Q, CCTV_Q,
                                                     WheelchairFriendly_Q, VisitorParking_Q, WiFi_Q, DiningTable_Q,
                                                     Kitchen_self_Q, prefered_tenant_Q, furnished_status_Q,
                                                     Owner_Free_Q, with_image_Q, attributes_terms_Q,
                                                     added_to_cart_Q).distinct().order_by('property_id')
            print(result_list.count(), "---------result_list11111")
        if not_null == 0:
            result_list = tb_property.objects.filter(district_Q, locality_Q, maxprice_Q, minprice_Q, is_pg=True,
                                                     added_to_cart=False, rooms_pg=rent_property_type).order_by(
                'property_id')
            print(result_list.count(), "---------result_list2222")
            if result_list:
                print("")
                print(result_list.count(), "we got--------------------------------")
            else:
                print("else-------------------------------")
                result_list = tb_property.objects.filter(is_pg_Q, added_to_cart=False).distinct()
                print(result_list.count(), "---------result_list3333")
        rlen = result_list.count()

        # page = request.GET.get('page', 1)
        # paginator = Paginator(result_list, 10)
        # try:
        #     result_list = paginator.page(page)
        # except PageNotAnInteger:
        #     result_list = paginator.page(10)
        # except EmptyPage:
        #     result_list = paginator.page(paginator.num_pages)
    return render(request, 'pg-filter-ajax.html', locals())


# search rent property from index(first) page
def search(request):
    request.session['back_to'] = "search"
    print("search---------------------------")
    request.session['go_to'] = "/search"
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])
    my_cart_count = cart_count(request)
    posting = 0
    if request.method == "GET":
        print("post.........................")
        budget_start_range = request.GET.get('budget_start_range')
        budget_end_range = request.GET.get('budget_end_range')
        locality = request.GET.getlist('locality')
        is_pg = request.GET.get('is_pg', '')
        rent_property_type = request.GET.get('rent_property_type')

        rent_property_list_Q = Q()
        if rent_property_type:
            print(rent_property_type, "rent_property_type----------")
            rent_property_list_Q = Q(title=rent_property_type)
            request.session['rentrent_property_type'] = rent_property_type
            posting = 1

        budget_end_range_Q = Q()
        if budget_end_range:
            print(budget_end_range, "budget_end_range----------")
            budget_end_range_Q = Q(total_rent__lte=int(budget_end_range))
            request.session['rentbudget_end_range'] = budget_end_range
            posting = 1

        budget_start_range_Q = Q()
        if budget_start_range:
            print(budget_start_range, "budget_start_range----------")
            budget_start_range_Q = Q(total_rent__gte=int(budget_start_range))
            request.session['rentbudget_start_range'] = budget_start_range
            posting = 1

        if locality:
            print(locality, "--------locality")
            request.session['rentlocality'] = locality
            posting = 1

            district = []
            for i in locality:
                if i[0] in "0123456789":
                    district.append(str(i))
                else:
                    city_data = Cities_db.objects.filter(name=i).values('id', 'name')

                    for citydata in city_data:
                        city_id = citydata['id']
                        city_name = citydata['name']
                        district.append(str(city_id))
            locality_p_list = Locality_db.objects.filter(city_id__id__in=district)
            locality_count = Locality_db.objects.filter(city_id__id__in=district).count()
            print(locality_count, "-------------------locality_count")
            yyyy = [c.name for c in Cities_db.objects.filter(id__in=district)]

            yyyys = set(yyyy)
            yyyy = list(yyyys)
            print(yyyy, "got city in cities_db------")
            if yyyy:
                print()
                print(yyyy, "title-----------")
            else:
                xxxx = 'Search Property'

        else:
            district = 594  # chandigarh
            locality_p_list = Locality_db.objects.filter(city_id__id__icontains=district)
            xxxx = Cities_db.objects.get(id=district)
            print(xxxx, "got city in cities_db ccc------")
            if xxxx:
                print()
                print(xxxx, "title-----------")
            else:
                xxxx = 'Search Property'

        district_Q = Q()
        if district:
            if district == 594:
                district_Q = Q(district=district)
            else:
                district_Q = Q(district__in=district)

        is_rent_Q = Q(is_rent=True)
        result_list1 = tb_property.objects.filter(rent_property_list_Q, budget_end_range_Q, budget_start_range_Q,
                                                  is_rent_Q, district_Q).distinct()

        if result_list1:
            result_list2 = tb_property.objects.filter(is_rent_Q).exclude(rent_property_list_Q, budget_end_range_Q,
                                                                         budget_start_range_Q, district_Q).distinct()

            from itertools import chain
            result_list = list(chain(result_list1, result_list2))
            len1 = result_list1.count()
            # len2 = result_list2.count()
            len = len1
            print()
            print('---------RRRRRR----------')
        else:
            result_list = tb_property.objects.filter(added_to_cart=False, is_rent=True)
            len = result_list.count()
            print(len, "-------------")
            xxxx = 'Search Property'
            print(result_list, '----------notRRRRR---------')

    else:
        print("else...............................................")
        result_list = tb_property.objects.filter(added_to_cart=False, is_rent=True)
        len = result_list.count()
        xxxx = 'Search Property'
        print(result_list, '----------notRRRRR-else---------')

    if posting == 0:
        print("yeah----**********************************")
        rentbudget_start_range = ""
        rentbudget_end_range = ""
        rentlocality = ""
        if 'rentlocality' in request.session:
            rentlocality = request.session['rentlocality']
        rentrent_property_type = ""

        rentrent_property_list_Q = Q()
        if 'rentrent_property_type' in request.session:
            rentrent_property_type = request.session['rentrent_property_type']
            print(rentrent_property_type, "rent_property_type----ss------")
            rentrent_property_list_Q = Q(title=rentrent_property_type)

        rentbudget_end_range_Q = Q()
        if 'rentbudget_end_range' in request.session:
            rentbudget_end_range = request.session['rentbudget_end_range']
            print(rentbudget_end_range, "rentbudget_end_range----ss------")
            rentbudget_end_range_Q = Q(total_rent__lte=int(rentbudget_end_range))

        rentbudget_start_range_Q = Q()
        if 'rentbudget_start_range' in request.session:
            rentbudget_start_range = request.session['rentbudget_start_range']
            print(rentbudget_start_range, "budget_start_range----sss------")
            rentbudget_start_range_Q = Q(total_rent__gte=int(rentbudget_start_range))

        if rentlocality:
            print(rentlocality, "--------locality---------sss")

            district = []
            for i in rentlocality:
                if i[0] in "0123456789":
                    district.append(str(i))
                else:
                    city_data = Cities_db.objects.filter(name=i).values('id', 'name')

                    for citydata in city_data:
                        city_id = citydata['id']
                        city_name = citydata['name']
                        district.append(str(city_id))
            locality_p_list = Locality_db.objects.filter(city_id__id__in=district)
            locality_count = Locality_db.objects.filter(city_id__id__in=district).count()
            print(locality_count, "-------------------locality_count")
            yyyy = [c.name for c in Cities_db.objects.filter(id__in=district)]

            yyyys = set(yyyy)
            yyyy = list(yyyys)
            print(yyyy, "got city in cities_db------")
            if yyyy:
                print()
                print(yyyy, "title-----------")
            else:
                xxxx = 'Search Property'

        else:
            district = 594  # chandigarh
            locality_p_list = Locality_db.objects.filter(city_id__id__icontains=district)
            xxxx = Cities_db.objects.get(id=district)
            print(xxxx, "got city in cities_db ccc------")
            if xxxx:
                print()
                print(xxxx, "title-----------")
            else:
                xxxx = 'Search Property'

        print(district, "-----------district---bbbbbbbb-------")
        district_Q = Q()
        if district:
            print(district, "-----------district----------")
            if district == 594:
                district_Q = Q(district=district)
            else:
                district_Q = Q(district__in=district)

        is_rent_Q = Q(is_rent=True)
        result_list1 = tb_property.objects.filter(rentrent_property_list_Q, rentbudget_end_range_Q,
                                                  rentbudget_start_range_Q,
                                                  is_rent_Q, district_Q).distinct()

        if result_list1:
            result_list2 = tb_property.objects.filter(is_rent_Q).exclude(rentrent_property_list_Q,
                                                                         rentbudget_end_range_Q,
                                                                         rentbudget_start_range_Q,
                                                                         district_Q).distinct()

            from itertools import chain
            result_list = list(chain(result_list1, result_list2))
            len1 = result_list1.count()
            # len2 = result_list2.count()
            len = len1
            print()
            print('---------RRRRRR----------')
        else:
            result_list = tb_property.objects.filter(added_to_cart=False, is_rent=True)
            len = result_list.count()
            print(len, "-------------")
            xxxx = 'Search Property'
            print(result_list, '----------notRRRRR---------')

    print(posting, "-------------0--------posting")
    print(type(posting), "------------ttt---------posting")
    print(len, "------------len")

    attributes = Attributes_Db.objects.filter(is_rent=True, use_in_filtering=True)
    is_rent = True
    # print("++++++++ATTRIBUteS++++++", attributes)
    terms = Terms_Db.objects.all()

    page = request.GET.get('page', 1)
    paginator = Paginator(result_list, 10)
    try:
        result_list = paginator.page(page)
    except PageNotAnInteger:
        result_list = paginator.page(10)
    except EmptyPage:
        result_list = paginator.page(paginator.num_pages)

    return render(request, 'property-list.html', locals())


# search pg property from index(first) page
def search_for_pg(request):
    request.session['back_to'] = "pg-search"
    request.session['go_to'] = "/pg-search"
    city_p_list = Cities_db.objects.filter(id__in=[3237, 594, 706, 2707, 3659, 5583, 4460, 2724, 733, 1558, 783, 3378])

    my_cart_count = cart_count(request)
    posting = 0

    if request.method == "GET":
        print("post..............................")
        budget_start_range = request.GET.get('budget_start_range')
        budget_end_range = request.GET.get('budget_end_range')
        locality = request.GET.getlist('locality_pg')
        is_pg = True
        rent_property_type = request.GET.get('rooms_pg')

        rent_property_list_Q = Q()
        if rent_property_type:
            print(rent_property_type, "rent_property_type----------")
            rent_property_list_Q = Q(rooms_pg=rent_property_type)
            request.session['pgrent_property_type'] = rent_property_type
            posting = 1

        budget_end_range_Q = Q()
        if budget_end_range:
            print(budget_end_range, "budget_end_range----------")
            budget_end_range_Q = Q(total_rent__lte=int(budget_end_range))
            request.session['pgbudget_end_range'] = budget_end_range
            posting = 1

        budget_start_range_Q = Q()
        if budget_start_range:
            print(budget_start_range, "budget_start_range----------")
            budget_start_range_Q = Q(total_rent__gte=int(budget_start_range))
            request.session['pgbudget_start_range'] = budget_start_range
            posting = 1

        if locality:
            print(locality, "--------locality")
            request.session['pglocality'] = locality
            posting = 1

            district = []
            for i in locality:
                if i[0] in "0123456789":
                    district.append(str(i))
                else:
                    city_data = Cities_db.objects.filter(name=i).values('id', 'name')

                    for citydata in city_data:
                        city_id = citydata['id']
                        city_name = citydata['name']
                        district.append(str(city_id))
            locality_p_list = Locality_db.objects.filter(city_id__id__in=district)
            locality_count = Locality_db.objects.filter(city_id__id__in=district).count()
            print(locality_count, "-------------------locality_count")
            yyyy = [c.name for c in Cities_db.objects.filter(id__in=district)]

            yyyys = set(yyyy)
            yyyy = list(yyyys)
            print(yyyy, "got city in cities_db------")
            if yyyy:
                print()
                print(yyyy, "title-----------")
            else:
                xxxx = 'Search Pg Property'
        else:
            district = 594  # chandigarh
            locality_p_list = Locality_db.objects.filter(city_id__id__icontains=district)
            xxxx = Cities_db.objects.get(id=district)
            print(xxxx, "got city in cities_db ccc------")
            if xxxx:
                print()
                print(xxxx, "title-----------")
            else:
                xxxx = 'Search Pg Property'

        print(district, "-----------district---bbbbbbbb-------")
        district_Q = Q()
        if district:
            print(district, "-----------district----------")
            if district == 594:
                district_Q = Q(district=district)
            else:
                district_Q = Q(district__in=district)

        is_pg_Q = Q(is_pg=True)
        result_list1 = tb_property.objects.filter(is_pg_Q, budget_end_range_Q, budget_start_range_Q, district_Q,
                                                  rooms_pg=rent_property_type).distinct()
        print(result_list1, "result------111111111111111111111111111111111")

        if result_list1:
            result_list2 = tb_property.objects.filter(is_pg_Q).exclude(budget_end_range_Q, budget_start_range_Q,
                                                                       district_Q,
                                                                       rooms_pg=rent_property_type).distinct()

            from itertools import chain
            result_list = list(chain(result_list1, result_list2))
            len1 = result_list1.count()
            len = len1
            print()
            print('---------RRRRRR----------')

        else:
            result_list = tb_property.objects.filter(added_to_cart=False, is_pg=True)
            len = result_list.count()
            xxxx = 'Search Pg Property'
            print(result_list, '----------notRRRRR---------')

    else:
        result_list = tb_property.objects.filter(added_to_cart=False, is_pg=True)
        len = result_list.count()
        xxxx = 'Search Pg Property'
        print(result_list, '----------notRRRRRelse---------')

    if posting == 0:
        print("yeah----**********************************")
        pgbudget_start_range = ""
        pgbudget_end_range = ""
        pglocality = ""
        if 'pglocality' in request.session:
            pglocality = request.session['pglocality']
        pgrent_property_type = ""

        pgrent_property_list_Q = Q()
        if 'pgrent_property_type' in request.session:
            pgrent_property_type = request.session['pgrent_property_type']
            print(pgrent_property_type, "rent_property_type---ss-------")
            pgrent_property_list_Q = Q(title=pgrent_property_type)

        pgbudget_end_range_Q = Q()
        if 'pgbudget_end_range' in request.session:
            pgbudget_end_range = request.session['pgbudget_end_range']
            print(pgbudget_end_range, "budget_end_range-----ss-----")
            pgbudget_end_range_Q = Q(total_rent__lte=int(pgbudget_end_range))

        pgbudget_start_range_Q = Q()
        if 'pgbudget_start_range' in request.session:
            pgbudget_start_range = request.session['pgbudget_start_range']
            print(pgbudget_start_range, "budget_start_range----sss------")
            pgbudget_start_range_Q = Q(total_rent__gte=int(pgbudget_start_range))

        if pglocality:
            print(pglocality, "--------locality---------sss")

            district = []
            for i in pglocality:
                if i[0] in "0123456789":
                    district.append(str(i))
                else:
                    city_data = Cities_db.objects.filter(name=i).values('id', 'name')

                    for citydata in city_data:
                        city_id = citydata['id']
                        city_name = citydata['name']
                        district.append(str(city_id))
            locality_p_list = Locality_db.objects.filter(city_id__id__in=district)
            locality_count = Locality_db.objects.filter(city_id__id__in=district).count()
            print(locality_count, "-------------------locality_count")
            yyyy = [c.name for c in Cities_db.objects.filter(id__in=district)]

            yyyys = set(yyyy)
            yyyy = list(yyyys)
            print(yyyy, "got city in cities_db------")
            if yyyy:
                print()
                print(yyyy, "title-----------")
            else:
                xxxx = 'Search Pg Property'

        else:
            district = 594  # chandigarh
            locality_p_list = Locality_db.objects.filter(city_id__id__icontains=district)
            xxxx = Cities_db.objects.get(id=district)
            print(xxxx, "got city in cities_db ccc------")
            if xxxx:
                print()
                print(xxxx, "title-----------")
            else:
                xxxx = 'Search Pg Property'

        print(district, "-----------district---bbbbbbbb-------")
        district_Q = Q()
        if district:
            print(district, "-----------district----------")
            if district == 594:
                district_Q = Q(district=district)
            else:
                district_Q = Q(district__in=district)

        is_pg_Q = Q(is_pg=True)
        result_list1 = tb_property.objects.filter(is_pg_Q, pgbudget_end_range_Q, pgbudget_start_range_Q,
                                                  district_Q, rooms_pg=pgrent_property_type).distinct()
        print(result_list1, "result------111111111111111111111111111111111")

        if result_list1:
            result_list2 = tb_property.objects.filter(is_pg_Q).exclude(is_pg_Q, pgbudget_end_range_Q,
                                                                       pgbudget_start_range_Q, district_Q,
                                                                       rooms_pg=pgrent_property_type).distinct()

            from itertools import chain
            result_list = list(chain(result_list1, result_list2))
            len1 = result_list1.count()
            len = len1
            print()
            print('---------RRRRRR----------')

        else:
            result_list = tb_property.objects.filter(added_to_cart=False, is_pg=True)
            len = result_list.count()
            xxxx = 'Search Pg Property'
            print(result_list, '----------notRRRRR---------')

    print(posting, "-------------0--------posting")
    print(type(posting), "------------ttt---------posting")
    attributes = Attributes_Db.objects.filter(is_pg=True, use_in_filtering=True)
    is_pg = True
    terms = Terms_Db.objects.all()

    page = request.GET.get('page', 1)
    paginator = Paginator(result_list, 10)
    try:
        result_list = paginator.page(page)
    except PageNotAnInteger:
        result_list = paginator.page(10)
    except EmptyPage:
        result_list = paginator.page(paginator.num_pages)
    return render(request, 'pg-list.html', locals())


def view_response(request):
    request.session['go_to'] = "/view-response"
    result_list = tb_property.objects.filter(added_to_cart=True, posted_user_name=request.user.username)
    new_list = []
    for i in result_list:
        id_list = []
        if i.user_id:
            id_list.append(i.property_id)
            id_list.append(i.title)
            id_list.append(i.street_address)
            user_list = User.objects.filter(username=i.user_id)
            for user_list in user_list:
                id_list.append(user_list.username)
                id_list.append(user_list.email)
                id_list.append(user_list.phone)
            new_list.append(id_list)
    return render(request, 'view-response.html', locals())


@login_required(login_url="login")
def referrals(request):
    my_cart_count = cart_count(request)
    if request.method == "POST":
        user_data = User.objects.get(id=request.user.id)
        user_data.bank_name = request.POST.get('bankname', '')
        user_data.bank_account = request.POST.get('account_number', '')
        user_data.account_holder_name = request.POST.get('holdername', '')
        user_data.ifse_code = request.POST.get('ifsc_code', '')
        user_data.save()
        messages.success(request, "Bank account successfully add.")

        print()
    else:
        print()
    list = User.objects.get(id=request.user.id)
    return render(request, 'referrals.html', locals())


def faq(request):
    request.session['go_to'] = "/faq"
    my_cart_count = cart_count(request)
    return render(request, 'faq.html', locals())


def login_without_password(request):
    print("-----login-with-phone--------")
    try:
        phone = request.GET.get('email')
        user = User.objects.get(phone=phone)
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        print("-----after-login-with-phone--------")
        if request.GET and 'next' in request.GET:
            next = request.GET['next']
            print(next, "-----next-after-login-with-phone--------")
            return HttpResponseRedirect(next)
        print("-----next-not found-after-login-with-phone--------")
        return redirect('/')
    except:
        print()
        print(next, "-----exception-after-login-with-phone--------")
    return redirect('/')


def login_without_password_email(request):
    print("-----login-with-email--------")
    try:
        phone = request.GET.get('email')
        print(phone, "email-----===------")
        user = User.objects.get(email=phone)
        print(user, "=====")
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        print("-----after-login-with-email--------")
        if request.GET and 'next' in request.GET:
            next = request.GET['next']
            print(next, "-----next-after-login-with-email--------")
            return HttpResponseRedirect(next)
        print("-----next-not-found-after-login-with-email--------")
        return redirect('/')
    except:
        print()
        print("-----exception-after-login-with-email--------")
    return redirect('/')


def login_func(request):
    request.session['city_selcetd'] = False
    request.session['city_id'] = []
    state_list = Cities_db.objects.filter(
        state_id__in=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
                      23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40])

    form = Front_Filter_Form()
    my_cart_count = cart_count(request)
    latest_result_list = tb_property.objects.filter().order_by('-property_id')[:13]
    top_result_list = tb_property.objects.filter()[:13]
    newset_result_list = tb_property.objects.filter().order_by('-property_id')[:16]
    all_testimonials = tb_testimonials.objects.filter(active=True)[:15]
    home_features_list = tb_home_feature.objects.filter(status=True)
    form = UserLoginForm()
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = request.POST['email']
            password = request.POST['password']
            try:
                try:
                    username = User.objects.get(email=email.lower()).username
                    user = authenticate(username=username, password=password)
                except:
                    user = authenticate(username=email, password=password)
            except:
                user = None
                invalid_credentials = True
                print("invalid")
            if user is not None:
                auth.login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                if request.GET and 'next' in request.GET:
                    next = request.GET['next']
                    return HttpResponseRedirect(next)
                else:
                    if request.user.is_superuser or request.user.is_staff:
                        from dashboardapp.views import get_user_permissions
                        get_user_permissions(request)
                        return redirect(reverse('home_dashboard'))
                    else:
                        return redirect(reverse('index'))
            else:
                invalid_credentials = True
    else:
        form_login = UserLoginForm()
    return render(request, 'login_2.html', locals())


def logout_view(request):
    auth.logout(request)
    return redirect("index")


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = True
            user.is_seller = True
            user.save()
            to_email = form.cleaned_data.get('email')
            current_site = get_current_site(request)
            d = ({
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            plaintext = get_template('email.txt')
            htmly = get_template(
                'registration/account_activation_email.html')
            subject, from_email, to = 'RadeONN Accoount Verification email', settings.DEFAULT_FROM_EMAIL, to_email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(
                subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()

            return redirect('account_activation_sent')
        else:
            form = SignUpForm(request.POST)
    else:
        form = SignUpForm()

    return render(request, 'signup.html', locals())


def register_send_mails(emails, username):
    d = ({'email': emails, 'username': username})
    plaintext = get_template('email.txt')
    htmly = get_template('registration/welcome_template.html')
    subject, from_email, to = "Welcome To RadeoNN", settings.DEFAULT_FROM_EMAIL, emails
    text_content = plaintext.render(d)
    html_content = htmly.render(d)
    msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
    msg.attach_alternative(html_content, "text/html")
    msg.send()


def activate(request, uidb64, token, backend='django.contrib.auth.backends.ModelBackend'):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        register_send_mails(request.user.email, request.user.username)
        return redirect('/post_property')
    else:
        return render(request, 'account_verification/account_activation_invalid.html', locals())


def account_activation_sent(request):
    return render(request, 'account_verification/account_activation_sent.html', locals())


def blog(request):
    request.session['go_to'] = "/blog"
    list = blog_db.objects.all()
    return render(request, 'blog.html', locals())


def blog_detail(request, id):
    myurl = f"/blog-detail/{id}"
    request.session['go_to'] = myurl
    single = blog_db.objects.get(id=id)
    return render(request, 'blog-detail.html', locals())


#########################################################################
def widget_check(request):
    return render(request, 'widget_check.html', locals())


def update_profile(request):
    if request.method == "POST":
        update_profile_data = User.objects.get(id=request.user.id)
        update_profile_data.first_name = request.POST['first_name']
        update_profile_data.last_name = request.POST['last_name']
        update_profile_data.nickname = request.POST['nickname']
        update_profile_data.email = request.POST['email']
        update_profile_data.phone = request.POST['phone']
        update_profile_data.phone2 = request.POST['phone2']
        update_profile_data.save()
        updated = True
        profile_data = User.objects.get(id=request.user.id)
    if request.user.is_superuser:
        profile_data = User.objects.get(id=request.user.id)
        return render(request, "profile_admin.html", locals())

    if request.user.is_staff:
        user_data = User.objects.get(id=request.user.id)
        from datetime import datetime
        from datetime import datetime, timedelta

        now = datetime.now()
        today_count = tb_property.objects.filter(posted_by=user_data.username,
                                                 posted_on=now.strftime("%d %B, %Y")).count()
        total_count = tb_property.objects.filter(posted_by=user_data.username).count()
        main_list = []

        start_date = request.GET.get('start_date', '')
        end_date = request.GET.get('end_date', '')
        aa = 0
        if start_date and end_date:
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
            xx = end_date - start_date
            aa = xx.days

        for i in range(0, aa):
            list = []
            now_1 = end_date - timedelta(days=i)
            list.append(now_1.strftime("%d %B, %Y"))
            aa_count = tb_property.objects.filter(posted_by=user_data.username,
                                                  posted_on=now_1.strftime("%d %B, %Y")).count()
            list.append(aa_count)
            main_list.append(list)

        return render(request, "dashboard/user-view.html", locals())

    else:
        profile_data = User.objects.get(id=request.user.id)
        return render(request, "profile.html", locals())


def update_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            success = True
        else:
            form = PasswordChangeForm(request.user, request.POST)
            error = True
    else:
        form = PasswordChangeForm(request.user)
    if request.user.is_superuser:
        return render(request, "change_password_admin.html", locals())
    else:
        return render(request, "change_password.html", locals())


def signup_with_email(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.is_seller = True
            to_email = form.cleaned_data.get('email')
            firstname, after_domain = to_email.split('@')
            user.username = firstname
            user.save()

            current_site = get_current_site(request)
            d = ({
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            plaintext = get_template('email.txt')
            htmly = get_template(
                'registration/account_activation_email.html')
            subject, from_email, to = 'RadeONN Accoount Verification email', settings.DEFAULT_FROM_EMAIL, to_email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(
                subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()

            return redirect('account_activation_sent')
        else:
            form = SignUpForm(request.POST)
    else:
        form = SignUpForm()
    return render(request, 'signup_email.html', locals())


def signup_with_phone_number(request):
    digits = [i for i in range(0, 10)]
    random_str = ""
    for i in range(5):
        index_1 = math.floor(random.random() * 10)
        random_str += str(digits[index_1])

    if 'signupwith' in request.POST:

        form = SignUpForm(request.POST)

        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.is_seller = True
            user.otp = random_str
            user.username = str(request.POST['phone'])
            request.session['username'] = str(request.POST['phone'])
            phone_number = request.POST['phone']
            user.save()
            check_message_sent = sendotp(key, phone_number, random_str)
            if check_message_sent:
                return render(request, 'confirm_otp.html', locals())
            else:
                print("error")
        else:
            form = SignUpForm(request.POST)
    else:
        form = SignUpForm()
    if 'otp_entered' in request.POST:
        otp = request.POST['otp']
        user = User.objects.get(username=request.session['username'])
        user_otp = user.otp
        if otp == user_otp:
            user.is_active = True
            user.save()
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            return redirect('post_property')
        else:
            incorrect_otp = True
    try:
        print(request.session['username'])
    except:
        print("not")
    return render(request, 'signup_phone.html', locals())


def otp_check(request):
    return render(request, 'confirm_otp.html', locals())


def contact_us(request):
    request.session['go_to'] = "/contact-us"
    from datetime import datetime
    now = datetime.now()
    d = now.strftime("%d %B, %Y")

    form = contactForm()
    if request.method == "POST":
        form = contactForm(request.POST)
        f = form.save(commit=False)
        f.email = request.POST['email']
        email = request.POST['email']
        f.message = request.POST.get('message')
        f.name = request.POST['name_is']
        f.number = request.POST['number']
        f.query_on = now.strftime("%d %B, %Y")
        f.save()
        saved = True
        d = ({'email': email})
        plaintext = get_template('email.txt')
        htmly = get_template('registration/contact_us_template.html')
        subject, from_email, to = 'Thank You For Contacting Rade onn', DEFAULT_FROM_EMAIL, email
        text_content = plaintext.render(d)
        html_content = htmly.render(d)
        msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
        msg.attach_alternative(html_content, "text/html")
        msg.send()
        done = True
    return render(request, 'contact.html', locals())


def add_subscription(request):
    request.session['go_to'] = "/added-subscription"
    from datetime import datetime
    now = datetime.now()
    d = now.strftime("%d %B, %Y")
    form = tb_subscribers_form()
    if request.method == "POST":
        form = tb_subscribers_form(request.POST)
        f = form.save(commit=False)
        f.email = request.POST['email']
        f.subscribed_on = now.strftime("%d %B, %Y")
        f.save()
        return render(request, "thankyou_sub.html", locals())
    else:
        return redirect("/")


def signin_with_email(request):
    print("signin_with_email----------------------------------------------")
    n_url = "/home"
    if 'go_to' in request.session:
        n_url = request.session['go_to']
    if 'signin_email_1' in request.POST:
        entered_email = request.POST['email']
        if User.objects.filter(email=str(entered_email)).exists():
            return render(request, 'login_email_exists.html', locals())
        else:
            return render(request, 'login_email_new.html', locals())
    if 'new_user_form' in request.POST:
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = True
            user.is_seller = True
            user.email = request.POST['email']
            to_email = request.POST['email']
            firstname, after_domain = to_email.split('@')
            user.username = firstname
            user.save()
            current_site = get_current_site(request)
            d = ({
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            plaintext = get_template('email.txt')
            htmly = get_template(
                'registration/account_activation_email.html')
            subject, from_email, to = 'RadeONN Accoount Verification email', settings.DEFAULT_FROM_EMAIL, to_email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(
                subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
            return redirect('account_activation_sent')
    if 'old_user_form' in request.POST:
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = request.POST['email']
            password = request.POST['password']
            try:
                try:
                    username = User.objects.get(email=email.lower()).username
                    print(username, 'username befor user')
                    user = authenticate(username=username, password=password)
                    print(user, 'user after user')
                except:
                    user = authenticate(username=email, password=password)
                    print(user, 'user after user- exception')
            except:
                user = None
                invalid_credentials = True
                print("invalid")
            if user is not None:
                auth.login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                if request.GET and 'next' in request.GET:
                    next = request.GET['next']
                    return HttpResponseRedirect(next)
                else:
                    if request.user.is_superuser or request.user.is_staff:
                        from dashboardapp.views import get_user_permissions
                        get_user_permissions(request)
                        return redirect(reverse('home_dashboard'))

                    else:
                        if n_url == "/home":
                            return redirect("/")
                        else:
                            return redirect(n_url)

            else:
                invalid_credentials = True
    return render(request, 'login_email1.html', locals())


def signin_with_email2(request, slug):
    if 'signin_email_1' in request.POST:
        entered_email = request.POST['email']
        if User.objects.filter(email=str(entered_email)).exists():
            return render(request, 'login_email_exists.html', locals())
        else:
            return render(request, 'login_email_new.html', locals())
    if 'new_user_form' in request.POST:
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.is_seller = True
            user.email = request.POST['email']
            to_email = request.POST['email']
            firstname, after_domain = to_email.split('@')
            user.username = firstname
            user.save()
            current_site = get_current_site(request)
            d = ({
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            plaintext = get_template('email.txt')
            htmly = get_template(
                'registration/account_activation_email.html')
            subject, from_email, to = 'RadeONN Accoount Verification email', settings.DEFAULT_FROM_EMAIL, to_email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(
                subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
            return redirect('account_activation_sent')
    if 'old_user_form' in request.POST:
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = request.POST['email']
            password = request.POST['password']
            try:
                try:
                    username = User.objects.get(email=email.lower()).username
                    user = authenticate(username=username, password=password)
                except:
                    user = authenticate(username=email, password=password)
            except:
                user = None
                invalid_credentials = True
                print("invalid")
            if user is not None:
                auth.login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                # auth.login(request, user)
                if request.GET and 'next' in request.GET:
                    next = request.GET['next']
                    return HttpResponseRedirect(next)
                else:
                    if request.user.is_superuser or request.user.is_staff:
                        if slug:
                            my_url = f"/{slug}"
                            return redirect(my_url)
                        else:
                            from dashboardapp.views import get_user_permissions

                            get_user_permissions(request)
                            return redirect(reverse('home_dashboard'))
                    else:
                        if slug:
                            my_url = f"/{slug}"
                            return redirect(my_url)
                        else:
                            return redirect("/")
            else:
                invalid_credentials = True
    return render(request, 'login_email1.html', locals())


def signin_with_phone(request):
    n_url = "/home"
    if 'go_to' in request.session:
        n_url = request.session['go_to']
    digits = [i for i in range(0, 10)]
    generated_otp = ""
    for i in range(5):
        index_1 = math.floor(random.random() * 10)
        generated_otp += str(digits[index_1])
    print(generated_otp)
    form = SignUpForm()
    if 'step1_phone' in request.POST:
        entered_phone_number = request.POST['phone_number']

        if User.objects.filter(phone=entered_phone_number).exists():
            user = User.objects.get(phone=entered_phone_number)
            user.otp = generated_otp
            user.set_password(generated_otp)
            user.otp_expired = False
            user.save()
            check_message_sent = sendotp(key, entered_phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'confirm_otp.html', locals())
            else:
                phone_error = True
                print("error")
            print("exists")
        else:
            form = SignUpForm(request.POST)

            user = User.objects.create_user(username=str(request.POST['phone_number']),
                                            password=generated_otp,
                                            is_active=False,
                                            is_seller=True,
                                            otp=generated_otp,
                                            otp_expired=False,
                                            phone=str(request.POST['phone_number']))

            phone_number = request.POST['phone_number']

            check_message_sent = sendotp(key, phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'confirm_otp.html', locals())
            else:
                phone_error = True

    if 'otp_entered' in request.POST:
        entered_phone_number = request.POST['entered_phone_number']
        entered_otp = request.POST['otp']
        user = User.objects.get(phone=entered_phone_number)
        if check_password(entered_otp, user.password):
            print("matched")
            if not user.otp_expired:
                user.otp_expired = False
                user.is_active = True
                user.save()
                login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                # login(request, user)

                if request.user.is_superuser or request.user.is_staff:
                    from dashboardapp.views import get_user_permissions
                    get_user_permissions(request)
                    return redirect(reverse('home_dashboard'))
                else:
                    if n_url == "/home":
                        return redirect("/")
                    else:
                        return redirect(n_url)
            elif user.otp_expired:
                otp_expired = True
                return render(request, 'confirm_otp.html', locals())


        else:
            otp_expired = True
            return render(request, 'confirm_otp.html', locals())
    return render(request, 'login_phone1.html', locals())


def signin_with_phone2(request, slug):
    digits = [i for i in range(0, 10)]
    generated_otp = ""
    for i in range(5):
        index_1 = math.floor(random.random() * 10)
        generated_otp += str(digits[index_1])
    print(generated_otp)
    form = SignUpForm()
    if 'step1_phone' in request.POST:
        entered_phone_number = request.POST['phone_number']
        if User.objects.filter(phone=entered_phone_number).exists():
            user = User.objects.get(phone=entered_phone_number)
            user.otp = generated_otp
            user.set_password(generated_otp)
            user.otp_expired = False
            user.save()
            check_message_sent = sendotp(key, entered_phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'confirm_otp.html', locals())
            else:
                phone_error = True
                print("error")
            print("exists")
        else:
            form = SignUpForm(request.POST)
            user = User.objects.create_user(username=str(request.POST['phone_number']),
                                            password=generated_otp,
                                            is_active=False,
                                            is_seller=True,
                                            otp=generated_otp,
                                            otp_expired=False,
                                            phone=str(request.POST['phone_number']))

            phone_number = request.POST['phone_number']

            check_message_sent = sendotp(key, phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'confirm_otp.html', locals())
            else:
                phone_error = True

    if 'otp_entered' in request.POST:
        entered_phone_number = request.POST['entered_phone_number']
        entered_otp = request.POST['otp']
        user = User.objects.get(phone=entered_phone_number)
        if check_password(entered_otp, user.password):

            if not user.otp_expired:
                user.otp_expired = False
                user.is_active = True
                user.save()
                login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                # login(request, user)
                if slug:
                    my_url = f"/{slug}"
                    return redirect(my_url)
                else:
                    return redirect("/")
            elif user.otp_expired:
                otp_expired = True
                return render(request, 'confirm_otp.html', locals())


        else:
            otp_expired = True
            return render(request, 'confirm_otp.html', locals())
    return render(request, 'login_phone1.html', locals())


@login_required(login_url="login")
def my_properties(request):
    return render(request, 'my-property-list.html', locals())


@login_required(login_url="login")
def edit_my_property(request, slug):
    return render(request, 'edit_my_property.html', locals())


def plans_priceing(result_list):
    total_amount = 0
    main_list = []
    for i in result_list:
        list_room = []
        if i.is_pg == True:
            if i.rooms_pg == 'Single Room':
                list_room.append(1)
                list_room.append(0)
            if i.rooms_pg == 'Double Room':
                list_room.append(2)
                list_room.append(0)
            if i.rooms_pg == 'Triple Room':
                list_room.append(3)
                list_room.append(0)
            if i.rooms_pg == 'Four Room':
                list_room.append(4)
                list_room.append(0)
            if i.rooms_pg == 'Five Room':
                list_room.append(5)
                list_room.append(0)
            if i.rooms_pg == 'Six Room':
                list_room.append(6)
                list_room.append(0)
            if i.rooms_pg == 'Seven Room':
                list_room.append(7)
                list_room.append(0)
            if i.rooms_pg == 'Eight Room':
                list_room.append(8)
                list_room.append(0)
        if i.is_rent == True:
            if i.rooms_rent == '1':
                list_room.append(1)
            if i.rooms_rent == '2':
                list_room.append(2)
            if i.rooms_rent == '3':
                list_room.append(3)
            if i.rooms_rent == '4':
                list_room.append(4)
            if i.rooms_rent == '5':
                list_room.append(5)
            if i.rooms_rent == '6':
                list_room.append(6)
            if i.rooms_rent == '7':
                list_room.append(7)
            if i.rooms_rent == '8':
                list_room.append(8)
            if i.for_livein == True:
                list_room.append(1)
            else:
                list_room.append(0)
        main_list.append(list_room)
    max_value = max(main_list)
    total_lenth = len(main_list)
    ddd = False
    for xx in main_list:
        if xx[1] == 1:
            ddd = True

    if max_value[0] == 1:
        if total_lenth <= 5:
            total_amount = 1500
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 3000
        elif total_lenth > 10:
            total_amount = 4500
    if max_value[0] == 2:
        if total_lenth <= 5:
            total_amount = 2000
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 4000
        elif total_lenth > 10:
            total_amount = 6000
    if max_value[0] == 3:
        if total_lenth <= 5:
            total_amount = 3000
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 6000
        elif total_lenth > 10:
            total_amount = 9000
    if max_value[0] == 4:
        if total_lenth <= 5:
            total_amount = 4000
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 8000
        elif total_lenth > 10:
            total_amount = 12000
    if max_value[0] == 5:
        if total_lenth <= 5:
            total_amount = 5000
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 10000
        elif total_lenth > 10:
            total_amount = 15000
    if max_value[0] == 6:
        if total_lenth <= 5:
            total_amount = 6000
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 12000
        elif total_lenth > 10:
            total_amount = 18000
    if max_value[0] == 7:
        if total_lenth <= 5:
            total_amount = 7000
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 14000
        elif total_lenth > 10:
            total_amount = 21000
    if max_value[0] == 8:
        if total_lenth <= 5:
            total_amount = 8000
        elif total_lenth > 5 and total_lenth <= 10:
            total_amount = 16000
        elif total_lenth > 10:
            total_amount = 24000
    if ddd == True:
        total_amount += 1000

    return total_amount


def my_cart(request):
    request.session['go_to'] = "/my-cart"
    cart_id = "not_exist"

    if 'session_cart_id' in request.session:
        cart_id = request.session['session_cart_id']
        result_list = tb_property.objects.filter(js_cart_id=cart_id)
    if request.user.is_authenticated:
        print("logged in data")
        result_list = tb_property.objects.filter(user_id=request.user.username)
        count_list = tb_property.objects.filter(
            Q(js_cart_id=cart_id) | Q(user_id=request.user.username) & Q(added_to_cart=False)).count()
        for i in result_list:
            db_data = tb_property.objects.get(property_id=i.property_id)
            db_data.added_to_cart = False
            db_data.user_id = request.user.username
            db_data.js_cart_id = ""
            db_data.save()
    else:
        result_list = tb_property.objects.filter(Q(js_cart_id=cart_id) & Q(added_to_cart=False))
        count_list = tb_property.objects.filter(Q(js_cart_id=cart_id) & Q(added_to_cart=False)).count()
    my_cart_count = len(result_list)
    if my_cart_count == 0:
        no_items = True
    if result_list:
        # -------------------------------------------------------------
        total_amount = plans_priceing(result_list)
        # -------------------------------------------------------------

    if 'remove_id' in request.POST:
        print(request.POST['remove_id'])
        tb_property.objects.filter(property_id=request.POST['remove_id']).update(added_to_cart=False, user_id='',
                                                                                 js_cart_id="")
        return redirect("/my-cart")

    if count_list == 1:
        data_string = 'You need to add 4 more properties'
    elif count_list == 2:
        data_string = 'You need to add 3 more properties'
    elif count_list == 3:
        data_string = 'You need to add 2 more properties'
    elif count_list == 4:
        data_string = 'You need to add 1 more property'
    elif count_list == 5:
        data_string = ' '
    elif count_list == 6:
        data_string = 'You need to add 4 more properties'
    elif count_list == 7:
        data_string = 'You need to add 3 more properties'
    elif count_list == 8:
        data_string = 'You need to add 2 more properties'
    elif count_list == 9:
        data_string = 'You need to add 1 more property'
    else:
        data_string = ''
    if request.user.is_authenticated:
        current_user_data = User.objects.get(id=request.user.id)
    return render(request, 'my-cart-list.html', locals())


@login_required(login_url="login")
def place_order(request):
    result_list = tb_property.objects.filter(user_id=request.user.username, added_to_cart=False)
    my_cart_count = len(result_list)
    total_amount = 0
    rooms_total = 0
    all_room_slugs = []
    new_total_amount = 0
    if result_list:
        # -------------------------------------------------------------
        total_amount = plans_priceing(result_list)
        actual_amount = total_amount

        if request.method == "POST":
            t_amount = total_amount
            use_refrel = request.POST.get('use_refrel')
            if use_refrel == "on":
                current_user = User.objects.get(id=request.user.id)

                if current_user.refrel_point > total_amount:
                    total_amount = 0

                else:
                    total_amount = total_amount - current_user.refrel_point

                discount = actual_amount - total_amount
                remaining_refel_points = current_user.refrel_point - t_amount
                if "-" not in str(remaining_refel_points):
                    current_user.refrel_point = remaining_refel_points
                else:
                    current_user.refrel_point = 0

                current_user.save()
                if total_amount == 0:
                    new_total_amount = 1

    print(new_total_amount)
    # -------------------------------------------------------------

    if new_total_amount == 1:
        for i in result_list:
            all_room_slugs.append(i.property_id)
            x = ''.join(random.choices(string.ascii_letters + string.digits, k=14))
            new_x = f"order_{x}"
            order_id = new_x
            from datetime import datetime
            now = datetime.now()
            form = tb_cart_form()
            f = form.save(commit=False)
            f.order_id = order_id
            f.room_id = all_room_slugs
            f.payment_status = False
            f.added_date = now.strftime("%d %B, %Y")
            f.id_id = request.user.id
            f.total_amount = total_amount
            f.save()

            y = ''.join(random.choices(string.ascii_letters + string.digits, k=14))
            new_y = f"pay_{y}"

            rp_id = new_y
            db_data = tb_cart.objects.get(order_id=order_id)
            get_room_slug = db_data.room_id
            bad_chars = ["['", "'", "]", " ", "UUID(", ")", "["]
            for i in bad_chars:
                get_room_slug = get_room_slug.replace(i, '')

            my_list = get_room_slug.split(",")

            for i in my_list:
                db_property_data = tb_property.objects.get(property_id=i)
                db_property_data.added_to_cart = True
                db_property_data.save()
            ordered_data = tb_cart.objects.get(cart_id=db_data.cart_id)
            ordered_data.rp_id = rp_id
            ordered_data.payment_status = True
            ordered_data.save()


    else:
        for i in result_list:
            all_room_slugs.append(i.property_id)
        extra_zeros = "00"
        razor_amount = str(total_amount) + extra_zeros
        DATA = {'amount': razor_amount, 'currency': 'INR', 'receipt': 'Rade onn Property Plans',
                'payment_capture': 1}
        order_data = client.order.create(data=DATA)
        order_id = order_data['id']
        if request.user.email:
            email = request.user.email
        else:
            email = 'Johndoe@example.com'
        if request.user.username:
            name = request.user.username
        else:
            name = 'john'
        if request.user.phone:
            phone = request.user.phone
        else:
            phone = '9876543210'
        from datetime import datetime
        now = datetime.now()
        form = tb_cart_form()

        f = form.save(commit=False)
        f.order_id = order_data['id']
        f.room_id = all_room_slugs
        f.payment_status = False
        f.added_date = now.strftime("%d %B, %Y")
        f.id_id = request.user.id
        f.total_amount = total_amount
        f.save()

    return render(request, 'place_order_confirm.html', locals())


@login_required(login_url="login")
def my_orders(request):
    tb_cart_list = tb_cart.objects.filter(id=request.user.id, payment_status=True)
    new_list = []
    for x in tb_cart_list:
        get_room_slug = x.room_id
        bad_chars = ["['", "'", "]", " ", "UUID(", ")", "["]
        for i in bad_chars:
            get_room_slug = get_room_slug.replace(i, '')
        my_list = get_room_slug.split(",")
        new_list += my_list
    result_list = tb_property.objects.filter(property_id__in=new_list)
    return render(request, 'my_orders.html', locals())


@login_required(login_url="login")
def payment_status(request, pair):
    payment_id = pair
    resp = client.payment.fetch(payment_id)
    rp_id = resp['id']
    rp_order_id = resp['order_id']
    db_data = tb_cart.objects.get(order_id=rp_order_id)
    get_room_slug = db_data.room_id
    bad_chars = ["['", "'", "]", " ", "UUID(", ")", "["]
    for i in bad_chars:
        get_room_slug = get_room_slug.replace(i, '')
    print(get_room_slug)
    my_list = get_room_slug.split(",")
    for i in my_list:
        db_property_data = tb_property.objects.get(property_id=i)
        db_property_data.added_to_cart = True
        db_property_data.save()
    ordered_data = tb_cart.objects.get(cart_id=db_data.cart_id)
    ordered_data.rp_id = rp_id
    ordered_data.payment_status = True
    ordered_data.save()
    return redirect("/my-orders")


# sorting all and rental property
def view_properties_by_filter(request, slug):
    myurl = f"/view-properties/{slug}"
    request.session['go_to'] = myurl
    xxxx = slug
    zzz = random.randint(000, 200)
    result_list = tb_property.objects.all().order_by('-property_id')[:zzz]
    if slug == "explore-PG":
        result_list = tb_property.objects.filter(is_pg=True).order_by('-property_id')[:zzz]
    if slug == "new-arrival":
        result_list = tb_property.objects.filter(added_to_cart=False).order_by('-property_id')[:zzz]
    if slug == "highly-rated":
        list_id_5 = []
        list_id_4 = []
        list_id_3 = []
        list_id_2 = []
        list_id_1 = []
        re_list = review_db.objects.all().order_by('-rating1')
        for i in re_list:
            if i.rating1 == '5':
                print(i.rating1)
                list_id_5.append(i.property_id.property_id)
            if i.rating1 == '4':
                list_id_4.append(i.property_id.property_id)
            if i.rating1 == '3':
                list_id_3.append(i.property_id.property_id)
            if i.rating1 == '2':
                list_id_2.append(i.property_id.property_id)
            if i.rating1 == '1':
                list_id_1.append(i.property_id.property_id)

        result_list = tb_property.objects.filter(property_id__in=list_id_5,
                                                 added_to_cart=False) | tb_property.objects.filter(
            property_id__in=list_id_4, added_to_cart=False) | tb_property.objects.filter(property_id__in=list_id_3,
                                                                                         added_to_cart=False) | tb_property.objects.filter(
            property_id__in=list_id_2, added_to_cart=False) | tb_property.objects.filter(property_id__in=list_id_1,
                                                                                         added_to_cart=False)
    if slug == "explore-rents-properties":
        result_list = tb_property.objects.filter(added_to_cart=False, is_rent=True).order_by('-property_id')[:zzz]
    if slug == "low-to-high":
        result_list = tb_property.objects.filter(added_to_cart=False).order_by('total_rent')
    if slug == "high-to-low":
        result_list = tb_property.objects.filter(added_to_cart=False).order_by('-total_rent')
    if slug == "Live-In":
        result_list = tb_property.objects.filter(added_to_cart=False, for_livein=True).order_by('-property_id')[:zzz]
    if slug == "Family":
        result_list = tb_property.objects.filter(added_to_cart=False, prefered_tenant_type='Family').order_by(
            '-property_id')[:zzz]
    if slug == "Professional":
        result_list = tb_property.objects.filter(added_to_cart=False, occupation='professional ').order_by(
            '-property_id')[:zzz]
    if slug == "Student":
        result_list = tb_property.objects.filter(added_to_cart=False, occupation='student ').order_by('-property_id')[
                      :zzz]

    if request.method == "POST":
        print("user_cart_id", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']
        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        print("extra_charges -", extra_charges, "\n room_charges - ", room_charges, "\n", "cart -id", user_cart_id)
        property_id = request.POST['property_id']
        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)
    attributes = Attributes_Db.objects.filter(is_rent=True, use_in_filtering=True)
    is_rent = True
    terms = Terms_Db.objects.all()
    # result_list = tb_property.objects.filter().order_by('-property_id')

    len = result_list.count()
    page = request.GET.get('page', 1)
    paginator = Paginator(result_list, 10)
    try:
        result_list = paginator.page(page)
    except PageNotAnInteger:
        result_list = paginator.page(1)
    except EmptyPage:
        result_list = paginator.page(paginator.num_pages)

    return render(request, 'property-list.html', locals())


# sorting of pg properties
def pg_view_properties_by_filter(request, slug):
    myurl = f"/pg-view-properties/{slug}"
    request.session['go_to'] = myurl
    xxxx = slug
    zzz = random.randint(000, 200)
    result_list = tb_property.objects.filter(is_pg=True).order_by('-property_id')[:zzz]
    if slug == "explore-PG":
        result_list = tb_property.objects.filter(is_pg=True).order_by('-property_id')[:zzz]
    if slug == "new-arrival":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False).order_by('-property_id')[:zzz]
    if slug == "highly-rated":
        list_id_5 = []
        list_id_4 = []
        list_id_3 = []
        list_id_2 = []
        list_id_1 = []
        re_list = review_db.objects.all().order_by('-rating1')
        for i in re_list:
            if i.rating1 == '5':
                print(i.rating1)
                list_id_5.append(i.property_id.property_id)
            if i.rating1 == '4':
                list_id_4.append(i.property_id.property_id)
            if i.rating1 == '3':
                list_id_3.append(i.property_id.property_id)
            if i.rating1 == '2':
                list_id_2.append(i.property_id.property_id)
            if i.rating1 == '1':
                list_id_1.append(i.property_id.property_id)

        result_list = tb_property.objects.filter(is_pg=True, property_id__in=list_id_5,
                                                 added_to_cart=False) | tb_property.objects.filter(
            property_id__in=list_id_4, added_to_cart=False) | tb_property.objects.filter(property_id__in=list_id_3,
                                                                                         added_to_cart=False) | tb_property.objects.filter(
            property_id__in=list_id_2, added_to_cart=False) | tb_property.objects.filter(property_id__in=list_id_1,
                                                                                         added_to_cart=False)
    if slug == "explore-rents-properties":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False, is_rent=True).order_by(
            '-property_id')[:zzz]
    if slug == "low-to-high":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False).order_by('total_rent')
    if slug == "high-to-low":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False).order_by('-total_rent')
    if slug == "Live-In":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False, for_livein=True).order_by(
            '-property_id')[:zzz]
    if slug == "Family":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False,
                                                 prefered_tenant_type='Family').order_by('-property_id')[:zzz]
    if slug == "Professional":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False, occupation='professional ').order_by(
            '-property_id')[:zzz]
    if slug == "Student":
        result_list = tb_property.objects.filter(is_pg=True, added_to_cart=False, occupation='student ').order_by(
            '-property_id')[:zzz]

    if request.method == "POST":
        print("user_cart_id", request.POST['user_cart_id'])
        user_cart_id = request.POST['user_cart_id']
        request.session['session_cart_id'] = request.POST['user_cart_id']
        extra_charges = request.POST.get('extra_charges', 0)
        room_charges = request.POST.get('room_charges', 0)
        print("extra_charges -", extra_charges, "\n room_charges - ", room_charges, "\n", "cart -id", user_cart_id)
        property_id = request.POST['property_id']
        if request.user.is_authenticated:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = request.user.username
            db_data.save()
        else:
            db_data = tb_property.objects.get(property_id=property_id)
            db_data.js_cart_id = user_cart_id
            db_data.user_id = ""
            db_data.save()
    my_cart_count = cart_count(request)
    attributes = Attributes_Db.objects.filter(is_pg=True, use_in_filtering=True, )
    terms = Terms_Db.objects.all()

    len = result_list.count()
    page = request.GET.get('page', 1)
    paginator = Paginator(result_list, 10)
    try:
        result_list = paginator.page(page)
    except PageNotAnInteger:
        result_list = paginator.page(1)
    except EmptyPage:
        result_list = paginator.page(paginator.num_pages)

    return render(request, 'pg-list.html', locals())


@login_required(login_url="login")
def post_property(request):
    request.session['clicked_url'] = "/post-property"
    print("request.session['clicked_url']", request.session['clicked_url'])
    if 'post_pg' in request.POST:
        update_profile_data = User.objects.get(id=request.user.id)
        update_profile_data.email = request.POST['email']
        update_profile_data.phone = request.POST['phone']
        update_profile_data.phone2 = request.POST['phone2']
        update_profile_data.save()
        return redirect("post-property/pg")
    if 'post_rent' in request.POST:
        update_profile_data = User.objects.get(id=request.user.id)
        update_profile_data.email = request.POST['email']
        update_profile_data.phone = request.POST['phone']
        update_profile_data.phone2 = request.POST['phone2']
        update_profile_data.save()
        return redirect("post-property/rent")
    return render(request, 'post_property_step1.html', locals())


@login_required(login_url="login")
def post_type_property(request, slug):
    update_profile_data = User.objects.get(id=request.user.id)
    update_profile_data.email = request.user.email
    update_profile_data.phone = request.user.phone
    update_profile_data.phone2 = request.user.phone2
    update_profile_data.save()

    state_list = States_db.objects.filter(country_id=101)
    primary_key_generated = ""
    from datetime import datetime
    now = datetime.now()
    floor_number_not_selected = False
    if request.method == "POST":
        form = property_form(request.POST, request.FILES)
        f1 = form.save(commit=False)
        if request.FILES.get('living_room_image', False):
            f1.living_room_image = request.FILES['living_room_image']
        if request.FILES.get('bed_rooms_image', False):
            f1.bed_rooms_image = request.FILES['bed_rooms_image']
        if request.FILES.get('bath_rooms_image', False):
            f1.bath_rooms_image = request.FILES['bath_rooms_image']
        if request.FILES.get('kitchen_image', False):
            f1.kitchen_image = request.FILES['kitchen_image']
        if request.FILES.get('others_image', False):
            f1.others_image = request.FILES['others_image']
        f1.posted_by = request.user.username
        f1.posted_on = now.strftime("%d %B, %Y")
        f1.added_to_cart = False
        f1.user_id = ""
        f1.js_cart_id = ""
        f1.posted_user_name = request.user.username
        if request.user.email:
            f1.posted_user_email = request.user.email
        elif not request.user.email:
            f1.posted_user_email = request.POST.get('', )
        if request.user.phone:
            f1.posted_user_phone1 = request.user.phone
        elif not request.user.phone:
            f1.posted_user_phone1 = request.POST.get('', )
        if request.user.phone2:
            f1.posted_user_phone2 = request.user.phone2
        elif not request.user.phone2:
            f1.posted_user_phone2 = request.POST.get('posted_user_phone2', '')
        if slug == "pg":
            f1.is_pg = True
            f1.rooms_pg = request.POST.get('rooms_pg', '')
            f1.pg_sharing_type = request.POST.get('pg_sharing_type', '')
        if slug == "rent":
            rent_number_bedrooms = request.POST['rent_number_bedrooms']
            rent_number_balcony = request.POST['rent_number_balcony']
            rent_number_bathrooms = request.POST['rent_number_bathrooms']
            rent_number_kitchen = request.POST['rent_number_kitchen']
            if rent_number_bedrooms is None or rent_number_bedrooms == "":
                bedrooms_not_selected = True
            else:
                bedrooms_not_selected = False
            if rent_number_balcony is None or rent_number_balcony == "":
                balcony_not_selected = True
            else:
                balcony_not_selected = False
            if rent_number_bathrooms is None or rent_number_bathrooms == "":
                bathrooms_not_selected = True
            else:
                bathrooms_not_selected = False
            if rent_number_kitchen is None or rent_number_kitchen == "":
                kitchen_not_selected = True
            else:
                bathrooms_not_selected = False
            f1.is_rent = True
            f1.rent_property_type = request.POST.get('rent_property_type', '')
            if request.POST.get('prefered_tenant') == "Live-in":
                f1.for_livein = True
            f1.maintain_charges = request.POST.get('rent_maintain_charges', '')
            f1.maintain_charges_type = request.POST.get('rent_maintain_charges_type', '')
            f1.age_of_construction = request.POST.get('age_of_construction', '')
            if rent_number_bedrooms == "1":
                f1.rooms_rent = "1"
                f1.bedroom1_length = request.POST.get('bedroom_1_length1', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth1', '')
            if rent_number_bedrooms == "2":
                f1.rooms_rent = "2"
                f1.bedroom1_length = request.POST.get('bedroom_1_length2', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth2', '')
                f1.bedroom2_length = request.POST.get('bedroom_2_length2', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth2', '')
            if rent_number_bedrooms == "3":
                f1.rooms_rent = "3"
                f1.bedroom1_length = request.POST.get('bedroom_1_length3', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth3', '')
                f1.bedroom2_length = request.POST.get('bedroom_2_length3', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth3', '')
                f1.bedroom3_length = request.POST.get('bedroom_3_length3', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth3', '')
            if rent_number_bedrooms == "4":
                f1.rooms_rent = "4"
                f1.bedroom1_length = request.POST.get('bedroom_1_length4', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth4', '')
                f1.bedroom2_length = request.POST.get('bedroom_2_length4', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth4', '')
                f1.bedroom3_length = request.POST.get('bedroom_3_length4', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth4', '')
                f1.bedroom4_length = request.POST.get('bedroom_4_length4', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth4', '')
            if rent_number_bedrooms == "5":
                f1.rooms_rent = "5"
                f1.bedroom1_length = request.POST.get('bedroom_1_length5', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth5', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length5', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth5', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length5', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth5', '')

                f1.bedroom4_length = request.POST.get('bedroom_4_length5', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth5', '')

                f1.bedroom5_length = request.POST.get('bedroom_5_length5', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth5', '')
            if rent_number_bedrooms == "6":
                f1.rooms_rent = "6"
                f1.bedroom1_length = request.POST.get('bedroom_1_length6', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth6', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length6', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth6', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length6', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth6', '')

                f1.bedroom4_length = request.POST.get('bedroom_4_length6', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth6', '')

                f1.bedroom5_length = request.POST.get('bedroom_5_length6', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth6', '')

                f1.bedroom6_length = request.POST.get('bedroom_6_length6', '')
                f1.bedroom6_breadth = request.POST.get('bedroom6_breadth6', '')
            if rent_number_bedrooms == "7":
                f1.rooms_rent = "7"
                f1.bedroom1_length = request.POST.get('bedroom_1_length7', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth7', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length7', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth7', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length7', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth7', '')

                f1.bedroom4_length = request.POST.get('bedroom_4_length7', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth7', '')

                f1.bedroom5_length = request.POST.get('bedroom_5_length7', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth7', '')

                f1.bedroom6_length = request.POST.get('bedroom_6_length7', '')
                f1.bedroom6_breadth = request.POST.get('bedroo6_breadth7', '')

                f1.bedroom7_length = request.POST.get('bedroom_7_length7', '')
                f1.bedroom7_breadth = request.POST.get('bedroom7_breadth7', '')
            if rent_number_bedrooms == "8":
                f1.rooms_rent = "8"
                f1.bedroom1_length = request.POST.get('bedroom_1_length8', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth8', '')

                f1.bedroom2_length = request.POST.get('bedroom2_length8', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth8', '')

                f1.bedroom3_length = request.POST.get('bedroom3_length8', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth8', '')

                f1.bedroom4_length = request.POST.get('bedroom4_length8', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth8', '')

                f1.bedroom5_length = request.POST.get('bedroom5_length8', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth8', '')

                f1.bedroom6_length = request.POST.get('bedroom6_length8', '')
                f1.bedroom6_breadth = request.POST.get('bedroom6_breadth8', '')

                f1.bedroom7_length = request.POST.get('bedroom_7_length8', '')
                f1.bedroom7_breadth = request.POST.get('bedroom7_breadth8', '')

                f1.bedroom8_length = request.POST.get('bedroom8_length8', '')
                f1.bedroom8_breadth = request.POST.get('bedroom8_breadth8', '')
            if rent_number_balcony == "1":
                f1.balcony = 1

                f1.balcony1_length = request.POST.get('1rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('1rent_balconyb1', '')
            if rent_number_balcony == "2":
                f1.balcony = 2

                f1.balcony1_length = request.POST.get('2rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('2rent_balconyb1', '')

                f1.balcony2_length = request.POST.get('2rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('2rent_balconyb2', '')
            if rent_number_balcony == "3":
                f1.balcony = 3

                f1.balcony1_length = request.POST.get('3rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('3rent_balconyb1', '')

                f1.balcony2_length = request.POST.get('3rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('3rent_balconyb2', '')

                f1.balcony3_length = request.POST.get('3rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('3rent_balconyb3', '')
            if rent_number_balcony == "4":
                f1.balcony = 4
                f1.balcony1_length = request.POST.get('4rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('4rent_balconyb1', '')

                f1.balcony2_length = request.POST.get('4rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('4rent_balconyb2', '')

                f1.balcony3_length = request.POST.get('4rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('4rent_balconyb3', '')

                f1.balcony4_length = request.POST.get('4rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('4rent_balconyb4', '')
            if rent_number_balcony == "5":
                f1.balcony = 5
                f1.balcony1_length = request.POST.get('5rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('5rent_balconyb1', '')

                f1.balcony2_length = request.POST.get('5rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('5rent_balconyb2', '')

                f1.balcony3_length = request.POST.get('5rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('5rent_balconyb3', '')

                f1.balcony4_length = request.POST.get('5rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('5rent_balconyb4', '')

                f1.balcony5_length = request.POST.get('5rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('5rent_balconyb5', '')
            if rent_number_balcony == "6":
                f1.balcony = 6
                f1.balcony1_length = request.POST.get('6rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('6rent_balconyb1', '')

                f1.balcony2_length = request.POST.get('6rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('6rent_balconyb2', '')

                f1.balcony3_length = request.POST.get('6rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('6rent_balconyb3', '')

                f1.balcony4_length = request.POST.get('6rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('6rent_balconyb4', '')

                f1.balcony5_length = request.POST.get('6rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('6rent_balconyb5', '')

                f1.balcony6_length = request.POST.get('6rent_balconyl6', '')
                f1.balcony6_breadth = request.POST.get('6rent_balconyb6', '')
            if rent_number_balcony == "7":
                f1.balcony = 7
                f1.balcony1_length = request.POST.get('7rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('7rent_balconyb1', '')

                f1.balcony2_length = request.POST.get('7rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('7rent_balconyb2', '')

                f1.balcony3_length = request.POST.get('7rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('7rent_balconyb3', '')

                f1.balcony4_length = request.POST.get('7rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('7rent_balconyb4', '')

                f1.balcony5_length = request.POST.get('7rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('7rent_balconyb5', '')

                f1.balcony6_length = request.POST.get('7rent_balconyl6', '')
                f1.balcony6_breadth = request.POST.get('7rent_balconyb6', '')

                f1.balcony7_length = request.POST.get('7rent_balconyl7', '')
                f1.balcony7_breadth = request.POST.get('7rent_balconyb7', '')
            if rent_number_balcony == "8":
                f1.balcony = 8
                f1.balcony1_length = request.POST.get('8rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('8rent_balconyb1', '')

                f1.balcony2_length = request.POST.get('8rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('8rent_balconyb2', '')

                f1.balcony3_length = request.POST.get('8rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('8rent_balconyb3', '')

                f1.balcony4_length = request.POST.get('8rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('8rent_balconyb4', '')

                f1.balcony5_length = request.POST.get('8rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('8rent_balconyb5', '')

                f1.balcony6_length = request.POST.get('8rent_balconyl6', '')
                f1.balcony6_breadth = request.POST.get('8rent_balconyb6', '')

                f1.balcony7_length = request.POST.get('8rent_balconyl7', '')
                f1.balcony7_breadth = request.POST.get('8rent_balconyb7', '')

                f1.balcony8_length = request.POST.get('8rent_balconyl8', '')
                f1.balcony8_breadth = request.POST.get('8rent_balconyb8', '')
            if rent_number_bathrooms == "1":
                f1.bathrooms = "1"
                f1.bathroom1_length = request.POST.get('rent_bathrooms_l_1', '')
                f1.bathroom1_breadth = request.POST.get('rent_bathrooms_b_1', '')
            if rent_number_bathrooms == "2":
                f1.bathrooms = "2"
                f1.bathroom1_length = request.POST.get('2rent_bathrooms_l_1', '')
                f1.bathroom1_breadth = request.POST.get('2rent_bathrooms_b_1', '')

                f1.bathroom2_length = request.POST.get('2rent_bathrooms_l_2', '')
                f1.bathroom2_breadth = request.POST.get('2rent_bathrooms_b_2', '')
            if rent_number_bathrooms == "3":
                f1.bathrooms = "3"
                f1.bathroom1_length = request.POST.get('3rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('3rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('3rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('3rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('3rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('3rent_bathroomsb3', '')
            if rent_number_bathrooms == "4":
                f1.bathrooms = "4"
                f1.bathroom1_length = request.POST.get('4rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('4rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('4rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('4rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('4rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('4rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('4rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('4rent_bathroomsb4', '')
            if rent_number_bathrooms == "5":
                f1.bathrooms = "5"
                f1.bathroom1_length = request.POST.get('5rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('5rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('5rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('5rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('5rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('5rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('5rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('5rent_bathroomsb4', '')

                f1.bathroom5_length = request.POST.get('5rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('5rent_bathroomsb5', '')
            if rent_number_bathrooms == "6":
                f1.bathrooms = "6"
                f1.bathroom1_length = request.POST.get('6rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('6rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('6rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('6rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('6rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('6rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('6rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('6rent_bathroomsb4', '')

                f1.bathroom5_length = request.POST.get('6rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('6rent_bathroomsb5', '')

                f1.bathroom6_length = request.POST.get('6rent_bathroomsl6', '')
                f1.bathroom6_breadth = request.POST.get('6rent_bathroomsb6', '')
            if rent_number_bathrooms == "7":
                f1.bathrooms = "7"
                f1.bathroom1_length = request.POST.get('7rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('7rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('7rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('7rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('7rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('7rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('7rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('7rent_bathroomsb4', '')

                f1.bathroom5_length = request.POST.get('7rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('7rent_bathroomsb5', '')

                f1.bathroom6_length = request.POST.get('7rent_bathroomsl6', '')
                f1.bathroom6_breadth = request.POST.get('7rent_bathroomsb6', '')

                f1.bathroom7_length = request.POST.get('7rent_bathroomsl7', '')
                f1.bathroom7_breadth = request.POST.get('7rent_bathroomsb7', '')
            if rent_number_bathrooms == "8":
                f1.bathrooms = "8"
                f1.bathroom1_length = request.POST.get('8rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('8rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('8rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('8rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('8rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('8rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('8rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('8rent_bathroomsl4', '')

                f1.bathroom5_length = request.POST.get('8rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('8rent_bathroomsl5', '')

                f1.bathroom6_length = request.POST.get('8rent_bathroomsl6', '')
                f1.bathroom6_breadth = request.POST.get('8rent_bathroomsb6', '')

                f1.bathroom7_length = request.POST.get('8rent_bathroomsl7', '')
                f1.bathroom7_breadth = request.POST.get('8rent_bathroomsb7', '')

                f1.bathroom8_length = request.POST.get('8rent_bathroomsl8', '')
                f1.bathroom8_breadth = request.POST.get('8rent_bathroomsb8', '')
            if rent_number_kitchen == "1":
                f1.rent_number_kitchen = 1
                f1.rent_kitchen_lenth_1 = request.POST.get('rent_kitchen_lenth_1', '')
                f1.rent_kitchen_breadth_1 = request.POST.get('rent_kitchen_breadth_1', '')
            if rent_number_kitchen == "2":
                f1.rent_number_kitchen = 2
                f1.rent_kitchen_lenth_1 = request.POST.get('rent_kitchen_lenth_1', '')
                f1.rent_kitchen_breadth_1 = request.POST.get('rent_kitchen_breadth_1', '')

                f1.rent_kitchen_lenth_2 = request.POST.get('rent_kitchen_lenth_2', '')
                f1.rent_kitchen_breadth_2 = request.POST.get('rent_kitchen_breadth_2', '')
            if rent_number_kitchen == "3":
                f1.rent_number_kitchen = 3
                f1.rent_kitchen_lenth_1 = request.POST.get('rent_kitchen_lenth_1', '')
                f1.rent_kitchen_breadth_1 = request.POST.get('rent_kitchen_breadth_1', '')

                f1.rent_kitchen_lenth_2 = request.POST.get('rent_kitchen_lenth_2', '')
                f1.rent_kitchen_breadth_2 = request.POST.get('rent_kitchen_breadth_2', '')

                f1.rent_kitchen_lenth_3 = request.POST.get('rent_kitchen_lenth_3', '')
                f1.rent_kitchen_breadth_3 = request.POST.get('rent_kitchen_breadth_3', '')

            # ----------------------------------------------------------
            floor_number_1 = request.POST.get('floor_number_1', '')
            if floor_number_1:
                f1.floor_number = request.POST.get('floor_number_1', '')
            else:
                f1.floor_number = request.POST.get('floor_number')
            total_floors_1 = request.POST.get('total_floors_1', '')
            if total_floors_1:
                f1.total_floors = request.POST.get('total_floors_1', '')
            else:
                f1.total_floors = request.POST.get('total_floors')
            # ---------------------------------------------------------
            furnished_status = request.POST.get('furnished_status', )
            if furnished_status is None or furnished_status == "":
                furnished_status_not_selected = True
            else:
                furnished_status_not_selected = False
            f1.furnished_status = request.POST.get('furnished_status', )
        f1.carpet_type = request.POST.get('rent_carpet_type', '')
        f1.carpet_area = request.POST.get('carpet_area', '')
        f1.super_type = request.POST.get('rent_super_type', '')
        f1.super_area = request.POST.get('super_area', '')
        f1.PoojaRoom = request.POST.get('PoojaRoom', False)
        f1.StudyRoom = request.POST.get('StudyRoom', False)
        f1.ServantRoom = request.POST.get('ServantRoom', False)
        f1.ClubHouse = request.POST.get('ClubHouse', False)

        f1.is_active = True
        if slug == 'rent':
            title = request.POST.get('property_title', '')
        else:
            title = request.POST.get('pg_title', '')
        f1.title = title
        f1.property_name = ""
        state_1 = request.POST.get('state', '')
        district_1 = request.POST.get('district', '')
        locality_1 = request.POST.get('locality', '')
        district = Cities_db.objects.get(id=district_1)
        state = States_db.objects.get(id=state_1)
        if Locality_db.objects.filter(name=locality_1, city_id=district_1, state_id=state_1):
            print('already taken -------------------------------')
            locality = Locality_db.objects.get(name=locality_1, city_id=district_1, state_id=state_1)
        else:
            locality = Locality_db()
            locality.name = locality_1
            locality.state_id = state
            locality.city_id = district
            locality.save()
            locality = Locality_db.objects.get(name=locality_1, city_id=district_1, state_id=state_1)
            print('done---------------------------------')

        f1.state = state
        f1.district = district
        f1.locality = locality

        f1.address = request.POST.get('address', '')
        f1.street_address = request.POST.get('street_address', '')
        f1.latlong = request.POST.get('latlong', '')
        f1.latitude = request.POST.get('latitude', '')
        f1.longitude = request.POST.get('longitude', '')
        f1.description = request.POST.get('description', '')
        a = request.POST.get('description', '')
        print(a, "------------description")

        f1.gender_prefer = request.POST.get('gender_prefer', '')
        f1.prefered_tenant_type = request.POST.get('prefered_tenant_type', '')
        f1.prefered_tenant = request.POST.get('prefered_tenant', '')
        f1.occupation = request.POST.get('occupation', '')

        f1.total_rent = request.POST.get('total_rent', '')
        f1.security_deposit = request.POST.get('security_deposit', '')
        if request.POST.get('today_avaliable'):
            from datetime import datetime
            now = datetime.now()
            f1.availabilty = now.strftime("%d %B, %Y")
        else:
            f1.availabilty = request.POST.get('available_from', '')
        if 'dp' in request.FILES:
            f1.dp = request.FILES['dp']
            f1.images = True
        else:
            f1.dp = ""
            f1.images = False
        f1.parking = request.POST.get('parking', '')
        if request.POST.get('parking'):
            f1.parking_selected = True
        f1.last_entry_time = request.POST.get('entery_time', '')
        f1.notice_period = request.POST.get('notice_period', '')

        f1.veg_only = request.POST.get('veg_only', False)
        f1.no_smoking = request.POST.get('no_smoking', False)
        f1.no_drinking_alcohol = request.POST.get('no_drinking_alcohol', False)
        f1.no_opposite_gender = request.POST.get('no_opposite_gender', False)
        f1.noGuardian = request.POST.get('noGuardian', False)
        f1.pet_allowed = request.POST.get('pet_allowed', False)
        if request.POST.get('veg_only') or request.POST.get('no_smoking') or request.POST.get('no_drinking_alcohol') or \
                request.POST.get('no_opposite_gender') or request.POST.get('noGuardian') or request.POST.get(
            'pet_allowed'):
            f1.rules = True
        f1.laundary = request.POST.get('laundary', False)
        f1.room_cleaning = request.POST.get('room_cleaning', False)
        if request.POST.get('laundary') or request.POST.get('room_cleaning'):
            f1.services_available = True
        f1.Kitchen_self = request.POST.get('Kitchen_self', False)
        f1.security = request.POST.get('security', False)
        f1.ro = request.POST.get('ro', False)
        f1.fridge = request.POST.get('fridge', False)
        f1.Lift = request.POST.get('Lift', False)
        f1.Gymnasium = request.POST.get('Gymnasium', False)
        f1.PowerBackup = request.POST.get('PowerBackup', False)
        f1.WiFi = request.POST.get('WiFi', False)
        f1.TV = request.POST.get('TV', False)
        f1.SwimmingPool = request.POST.get('SwimmingPool', False)
        f1.CCTV = request.POST.get('CCTV', False)
        f1.Sofa = request.POST.get('Sofa', False)
        f1.DiningTable = request.POST.get('DiningTable', False)
        f1.ElectricChimney = request.POST.get('ElectricChimney', False)
        f1.ModularKitchen = request.POST.get('ModularKitchen', False)
        f1.Microwave = request.POST.get('Microwave', False)
        f1.WashingMachine = request.POST.get('WashingMachine', False)
        f1.Bed = request.POST.get('Bed', False)
        f1.Curtains = request.POST.get('Curtains', False)
        f1.Park = request.POST.get('Park', False)
        f1.VisitorParking = request.POST.get('VisitorParking', False)
        f1.WheelchairFriendly = request.POST.get('WheelchairFriendly', False)
        f1.AC = request.POST.get('AC', False)
        f1.Cooler = request.POST.get('Cooler', False)
        f1.Fan = request.POST.get('Fan', False)
        if request.POST.get('WheelchairFriendly') or request.POST.get('VisitorParking') or \
                request.POST.get('Park') or request.POST.get('Curtains') or \
                request.POST.get('Bed') or request.POST.get('WashingMachine') or \
                request.POST.get('Microwave') or request.POST.get('ModularKitchen') or \
                request.POST.get('ElectricChimney') or request.POST.get('ElectricChimney') or \
                request.POST.get('DiningTable') or request.POST.get('Sofa') or request.POST.get('CCTV') or \
                request.POST.get('SwimmingPool') or request.POST.get('Kitchen_self') or \
                request.POST.get('security') or request.POST.get('ro') or request.POST.get('fridge') or \
                request.POST.get('Lift') or request.POST.get('Gymnasium') or request.POST.get('PowerBackup') or \
                request.POST.get('WiFi') or request.POST.get('TV') or request.POST.get('PoojaRoom') or \
                request.POST.get('StudyRoom') or request.POST.get('ServantRoom') or request.POST.get('ClubHouse'):
            print("amentits - ok ")
            f1.amenity = True
        f1.Food_not_included = request.POST.get('Food_not_included', False)
        f1.Owner_Free = request.POST.get('Owner_Free', False)

        f1.Water_not_included = request.POST.get('Water_not_included', False)
        f1.DTH_not_included = request.POST.get('DTH_not_included', False)
        f1.Wifi_not_included = request.POST.get('Wifi_not_included', False)
        f1.Electricity_not_included = request.POST.get('Electricity_not_included', False)
        f1.Housekeeping_not_included = request.POST.get('Housekeeping_not_included', False)
        if request.POST.get('Food_not_included') or request.POST.get('Water_not_included') or \
                request.POST.get('DTH_not_included') or request.POST.get('Wifi_not_included') \
                or request.POST.get('Electricity_not_included') or request.POST.get('Housekeeping_not_included'):
            f1.not_included_Services = True
        f1.rules = request.POST.get('rules', False)
        if slug == "rent":
            if not bedrooms_not_selected and not balcony_not_selected and not bathrooms_not_selected:
                f1.save()
                added = True
            else:
                all_fields_required = True
                print("f1-", f1.save(), "\n")
            primary_key_generated = f1.pk
        if slug == "pg":
            f1.save()
            added = True
            primary_key_generated = f1.pk
        # --------------------review_db()-------------------------------------
        obj = tb_property.objects.get(property_id=primary_key_generated)

        # for multiple selected attributes
        my_terms = Terms_Db.objects.values('slug', 'title', 'attributes_id')
        for myterms in my_terms:
            term_slug = myterms['slug']
            term_title = myterms['title']

            attr_id = myterms['attributes_id']

            res = request.POST.get(term_slug)
            if res == "True":

                print(term_slug, "----------------terms")

                attributes_value = Attributes_Values()
                attributes_value.property_id = obj

                main_attributes = Attributes_Db.objects.values('id', 'title')
                for main_attr in main_attributes:

                    main_attr_id = main_attr['id']
                    main_attr_title = main_attr['title']
                    if main_attr['id'] == attr_id:

                        if primary_key_generated in [c.property_id_id for c in Attributes_Values.objects.all()]:

                            if attr_id not in [c.attributes_id for c in
                                               Attributes_Values.objects.filter(property_id=primary_key_generated)]:
                                attributes_value.attributes_id = main_attr_id
                                attributes_value.title = main_attr_title
                                attributes_value.save()

                        if attr_id in [c.attributes_id for c in Attributes_Values.objects.all()]:

                            if primary_key_generated not in [c.property_id_id for c in Attributes_Values.objects.all()]:
                                attributes_value.attributes_id = main_attr_id
                                attributes_value.title = main_attr_title
                                attributes_value.save()
                        else:
                            attributes_value.attributes_id = main_attr_id
                            attributes_value.title = main_attr_title
                            attributes_value.save()

                if primary_key_generated in [c.property_id_id for c in Terms_Values.objects.all()]:
                    if term_title not in [c.title for c in
                                          Terms_Values.objects.filter(property_id=primary_key_generated)]:
                        terms_value = Terms_Values()
                        terms_value.property_id = obj
                        terms_value.title = term_title
                        terms_value.attributes_id = attr_id
                        terms_value.save()

                if term_title in [c.title for c in Terms_Values.objects.all()]:
                    if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                        terms_value = Terms_Values()
                        terms_value.property_id = obj
                        terms_value.title = term_title
                        terms_value.attributes_id = attr_id
                        terms_value.save()

                if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                    if term_title not in [c.title for c in
                                          Terms_Values.objects.filter(property_id=primary_key_generated)]:
                        terms_value = Terms_Values()
                        terms_value.property_id = obj
                        terms_value.title = term_title
                        terms_value.attributes_id = attr_id
                        terms_value.save()

        # for single selected attributes
        new_attr_ids = Attributes_Db.objects.values('id', 'title')
        for new_attr_id in new_attr_ids:
            attr_id2 = new_attr_id['id']
            new_attr_title = new_attr_id['title']

            new_my_terms = Terms_Db.objects.values('slug', 'title', 'attributes_id')
            for new_myterms in new_my_terms:
                term_slug = new_myterms['slug']
                term_title = new_myterms['title']
                attr_id = new_myterms['attributes_id']

        res = request.POST.get(new_attr_title)

        if res == "True":

            attributes_value = Attributes_Values()
            attributes_value.property_id = obj

            main_attributes = Attributes_Db.objects.values('id', 'title')
            for main_attr in main_attributes:

                main_attr_id = main_attr['id']
                main_attr_title = main_attr['title']
                if main_attr['id'] == attr_id:

                    if primary_key_generated in [c.property_id_id for c in Attributes_Values.objects.all()]:

                        if attr_id not in [c.attributes_id for c in
                                           Attributes_Values.objects.filter(property_id=primary_key_generated)]:
                            attributes_value.attributes_id = main_attr_id
                            attributes_value.title = main_attr_title
                            attributes_value.save()

                    if attr_id in [c.attributes_id for c in Attributes_Values.objects.all()]:

                        if primary_key_generated not in [c.property_id_id for c in
                                                         Attributes_Values.objects.all()]:
                            attributes_value.attributes_id = main_attr_id
                            attributes_value.title = main_attr_title
                            attributes_value.save()
                    else:
                        attributes_value.attributes_id = main_attr_id
                        attributes_value.title = main_attr_title
                        attributes_value.save()

            if primary_key_generated in [c.property_id_id for c in Terms_Values.objects.all()]:
                if term_title not in [c.title for c in Terms_Values.objects.filter(property_id=primary_key_generated)]:
                    terms_value = Terms_Values()
                    terms_value.property_id = obj
                    terms_value.title = term_title
                    terms_value.attributes_id = attr_id
                    terms_value.save()

            if term_title in [c.title for c in Terms_Values.objects.all()]:
                if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                    terms_value = Terms_Values()
                    terms_value.property_id = obj
                    terms_value.title = term_title
                    terms_value.attributes_id = attr_id
                    terms_value.save()

            if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                if term_slug not in [c.title for c in Terms_Values.objects.filter(property_id=primary_key_generated)]:
                    terms_value = Terms_Values()
                    terms_value.property_id = obj
                    terms_value.title = term_title
                    terms_value.attributes_id = attr_id
                    terms_value.save()

        # -------------------------------------------------------------
        # def compress_images(directory="/home/webtunix/Downloads/uploads", quality=30):
        #     # 1. If there is a directory then change into it, else perform the next operations inside of the
        #     # current working directory:
        #     if directory:
        #         os.chdir(directory)
        #
        #     # 2. Extract all of the .png and .jpeg files:
        #     files = os.listdir()
        #
        #     # 3. Extract all of the images:
        #     images = [file for file in files if file.endswith(('jpg', 'png', 'jpeg', 'gif'))]
        #
        #     # 4. Loop over every image:
        #     for image in images:
        #         print(image)
        #
        #         # 5. Open every image:
        #         img = Image.open(image)
        #
        #         # 5. Compress every image and save it with a new name:
        #         img.save(image, optimize=True, quality=quality)
        #
        # compress_images()
        # -------------------------------------------------------------
        files = request.FILES.getlist('image')
        if files:
            print(files, "---------files-------")
            for form_1 in files:
                if form_1:
                    image = form_1
                    photo = tb_property_images(property_id=f1, image=image)
                    photo.save()
        # ----------------------------------------------------------------------
        new_value = percentage_caluc(primary_key_generated, slug)
        to_email = request.user.email
        scheme = request.is_secure() and "https" or "http"
        current_site = get_current_site(request)
        if slug == "pg":
            u_link = f"edit-pg-form/{primary_key_generated}"

        if slug == "rent":
            u_link = f"edit-rent-form/{primary_key_generated}"
        view_link = scheme + "://" + smart_str(current_site.domain) + '/login_with_mailer/?email=' + smart_str(
            request.user.phone) + '&next=/' + u_link
        view_link = short_url(view_link)

        update_link = scheme + "://" + smart_str(current_site.domain) + '/login_with_mailer_email/?email=' + smart_str(
            request.user.email) + '&next=/' + u_link

        update_link = short_url(update_link)

        view_url = f"radeonn.com/view-details/{primary_key_generated}"

        d = ({
            'url': scheme + "://" + str(current_site.domain),
            'posted_user_name': request.user.username,
            'title': request.POST.get('property_title', ''),

            'property_id': primary_key_generated,
            'percetange': new_value,
            'property_link': view_url,
            'property_up_link': update_link,

        })
        plaintext = get_template('email.txt')
        htmly = get_template('dashboard/add-proprety-email-template.html')
        subject, from_email, to = 'Congrats your ad post successfully...!', settings.DEFAULT_FROM_EMAIL, request.user.email
        text_content = plaintext.render(d)
        html_content = htmly.render(d)
        msg = EmailMultiAlternatives(
            subject, text_content, from_email, [to])
        msg.attach_alternative(html_content, "text/html")
        msg.send()

        db_data = tb_property.objects.get(property_id=primary_key_generated)
        phone1 = db_data.posted_user_phone1
        phon2 = db_data.posted_user_phone2
        numbers = [phone1, phon2]
        percentage = str(new_value)
        view_link = view_link
        check_message_sent = property_added_message(key, numbers, primary_key_generated, percentage, view_link)

        if check_message_sent:
            print("confirmation send--------------------")
        else:
            print("error--------------------------")

    attributes = Attributes_Db.objects.all()
    terms = Terms_Db.objects.all()
    property_type = Property_Type.objects.all()
    property_title = Property_Title.objects.all()
    if slug == "pg":
        return render(request, 'add-pg-listing.html', locals())
    if slug == "rent":
        return render(request, 'add-rent-listing.html', locals())


# edit property (rent + pg)
@login_required(login_url="login")
def edit_property(request):
    print("rdit====================")
    from datetime import datetime
    now = datetime.now()
    floor_number_not_selected = False
    if request.method == "POST":
        property_id = request.POST.get('property_id', '')
        slug = request.POST.get('slug', '')
        username = request.POST.get('username', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        xxx = User.objects.filter(Q(email=email) & Q(phone=phone))
        if xxx:
            print()
        else:
            obj_new = User()
            obj_new.username = phone
            obj_new.email = email
            obj_new.phone = phone
            obj_new.save()

        instance = tb_property.objects.get(property_id=property_id)

        form = property_form(request.POST, request.FILES, instance=instance)

        f1 = form.save(commit=False)

        f1.posted_on = now.strftime("%d %B, %Y")
        f1.added_to_cart = False
        f1.user_id = ""
        f1.js_cart_id = ""
        posted_user_name = request.user.username
        f1.posted_user_name = posted_user_name
        posted_user_email = request.user.email
        f1.posted_user_email = posted_user_email
        f1.posted_user_phone1 = request.user.phone
        gender_prefer = request.POST.get('radio1', '')
        if slug == "pg":
            f1.is_pg = True
            f1.rooms_pg = request.POST.get('rooms_pg', '')
            f1.pg_sharing_type = request.POST.get('pg_sharing_type', '')
        if slug == "rent":
            rent_number_bedrooms = request.POST['rent_number_bedrooms']
            rent_number_balcony = request.POST['rent_number_balcony']
            rent_number_bathrooms = request.POST['rent_number_bathrooms']
            rent_number_kitchen = request.POST['rent_number_kitchen']

            if rent_number_bedrooms is None or rent_number_bedrooms == "":
                bedrooms_not_selected = True
            else:
                bedrooms_not_selected = False
            if rent_number_balcony is None or rent_number_balcony == "":
                balcony_not_selected = True
            else:
                balcony_not_selected = False
            if rent_number_bathrooms is None or rent_number_bathrooms == "":
                bathrooms_not_selected = True
            else:
                bathrooms_not_selected = False
            if rent_number_kitchen is None or rent_number_kitchen == "":
                kitchen_not_selected = True
            else:
                bathrooms_not_selected = False
            f1.is_rent = True

            f1.rent_property_type = request.POST.get('rent_property_type', '')
            if request.POST.get('prefered_tenant') == "Live-in":
                f1.for_livein = True
            f1.maintain_charges = request.POST.get('rent_maintain_charges', '')
            f1.maintain_charges_type = request.POST.get('rent_maintain_charges_type', '')
            f1.age_of_construction = request.POST.get('age_of_construction', '')

            if rent_number_bedrooms == "1":
                f1.rooms_rent = "1"
                f1.bedroom1_length = request.POST.get('bedroom_1_length1', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth1', '')

            if rent_number_bedrooms == "2":
                f1.rooms_rent = "2"
                f1.bedroom1_length = request.POST.get('bedroom_1_length2', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth2', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length2', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth2', '')

            if rent_number_bedrooms == "3":
                f1.rooms_rent = "3"
                f1.bedroom1_length = request.POST.get('bedroom_1_length3', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth3', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length3', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth3', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length3', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth3', '')

            if rent_number_bedrooms == "4":
                f1.rooms_rent = "4"
                f1.bedroom1_length = request.POST.get('bedroom_1_length4', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth4', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length4', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth4', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length4', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth4', '')

                f1.bedroom4_length = request.POST.get('bedroom_4_length4', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth4', '')

            if rent_number_bedrooms == "5":
                f1.rooms_rent = "5"
                f1.bedroom1_length = request.POST.get('bedroom_1_length5', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth5', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length5', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth5', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length5', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth5', '')

                f1.bedroom4_length = request.POST.get('bedroom_4_length5', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth5', '')

                f1.bedroom5_length = request.POST.get('bedroom_5_length5', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth5', '')

            if rent_number_bedrooms == "6":
                f1.rooms_rent = "6"
                f1.bedroom1_length = request.POST.get('bedroom_1_length6', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth6', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length6', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth6', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length6', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth6', '')

                f1.bedroom4_length = request.POST.get('bedroom_4_length6', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth6', '')

                f1.bedroom5_length = request.POST.get('bedroom_5_length6', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth6', '')

                f1.bedroom6_length = request.POST.get('bedroom_6_length6', '')
                f1.bedroom6_breadth = request.POST.get('bedroom6_breadth6', '')

            if rent_number_bedrooms == "7":
                f1.rooms_rent = "7"
                f1.bedroom1_length = request.POST.get('bedroom_1_length7', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth7', '')

                f1.bedroom2_length = request.POST.get('bedroom_2_length7', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth7', '')

                f1.bedroom3_length = request.POST.get('bedroom_3_length7', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth7', '')

                f1.bedroom4_length = request.POST.get('bedroom_4_length7', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth7', '')

                f1.bedroom5_length = request.POST.get('bedroom_5_length7', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth7', '')

                f1.bedroom6_length = request.POST.get('bedroom_6_length7', '')
                f1.bedroom6_breadth = request.POST.get('bedroo6_breadth7', '')

                f1.bedroom7_length = request.POST.get('bedroom_7_length7', '')
                f1.bedroom7_breadth = request.POST.get('bedroom7_breadth7', '')

            if rent_number_bedrooms == "8":
                f1.rooms_rent = "8"
                f1.bedroom1_length = request.POST.get('bedroom_1_length8', '')
                f1.bedroom1_breadth = request.POST.get('bedroom_1_breadth8', '')

                f1.bedroom2_length = request.POST.get('bedroom2_length8', '')
                f1.bedroom2_breadth = request.POST.get('bedroom2_breadth8', '')

                f1.bedroom3_length = request.POST.get('bedroom3_length8', '')
                f1.bedroom3_breadth = request.POST.get('bedroom3_breadth8', '')

                f1.bedroom4_length = request.POST.get('bedroom4_length8', '')
                f1.bedroom4_breadth = request.POST.get('bedroom4_breadth8', '')

                f1.bedroom5_length = request.POST.get('bedroom5_length8', '')
                f1.bedroom5_breadth = request.POST.get('bedroom5_breadth8', '')

                f1.bedroom6_length = request.POST.get('bedroom6_length8', '')
                f1.bedroom6_breadth = request.POST.get('bedroom6_breadth8', '')

                f1.bedroom7_length = request.POST.get('bedroom_7_length8', '')
                f1.bedroom7_breadth = request.POST.get('bedroom7_breadth8', '')

                f1.bedroom8_length = request.POST.get('bedroom8_length8', '')
                f1.bedroom8_breadth = request.POST.get('bedroom8_breadth8', '')

            if rent_number_balcony == "1":
                f1.balcony = 1
                f1.balcony1_length = request.POST.get('1rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('1rent_balconyb1', '')
            if rent_number_balcony == "2":
                f1.balcony = 2
                f1.balcony1_length = request.POST.get('2rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('2rent_balconyb1', '')
                f1.balcony2_length = request.POST.get('2rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('2rent_balconyb2', '')
            if rent_number_balcony == "3":
                f1.balcony = 3
                f1.balcony1_length = request.POST.get('3rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('3rent_balconyb1', '')
                f1.balcony2_length = request.POST.get('3rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('3rent_balconyb2', '')
                f1.balcony3_length = request.POST.get('3rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('3rent_balconyb3', '')
            if rent_number_balcony == "4":
                f1.balcony = 4
                f1.balcony1_length = request.POST.get('4rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('4rent_balconyb1', '')
                f1.balcony2_length = request.POST.get('4rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('4rent_balconyb2', '')
                f1.balcony3_length = request.POST.get('4rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('4rent_balconyb3', '')
                f1.balcony4_length = request.POST.get('4rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('4rent_balconyb4', '')
            if rent_number_balcony == "5":
                f1.balcony = 5
                f1.balcony1_length = request.POST.get('5rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('5rent_balconyb1', '')
                f1.balcony2_length = request.POST.get('5rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('5rent_balconyb2', '')
                f1.balcony3_length = request.POST.get('5rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('5rent_balconyb3', '')
                f1.balcony4_length = request.POST.get('5rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('5rent_balconyb4', '')
                f1.balcony5_length = request.POST.get('5rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('5rent_balconyb5', '')
            if rent_number_balcony == "6":
                f1.balcony = 6
                f1.balcony1_length = request.POST.get('6rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('6rent_balconyb1', '')
                f1.balcony2_length = request.POST.get('6rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('6rent_balconyb2', '')
                f1.balcony3_length = request.POST.get('6rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('6rent_balconyb3', '')
                f1.balcony4_length = request.POST.get('6rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('6rent_balconyb4', '')
                f1.balcony5_length = request.POST.get('6rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('6rent_balconyb5', '')
                f1.balcony6_length = request.POST.get('6rent_balconyl6', '')
                f1.balcony6_breadth = request.POST.get('6rent_balconyb6', '')
            if rent_number_balcony == "7":
                f1.balcony = 7
                f1.balcony1_length = request.POST.get('7rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('7rent_balconyb1', '')
                f1.balcony2_length = request.POST.get('7rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('7rent_balconyb2', '')
                f1.balcony3_length = request.POST.get('7rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('7rent_balconyb3', '')
                f1.balcony4_length = request.POST.get('7rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('7rent_balconyb4', '')
                f1.balcony5_length = request.POST.get('7rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('7rent_balconyb5', '')
                f1.balcony6_length = request.POST.get('7rent_balconyl6', '')
                f1.balcony6_breadth = request.POST.get('7rent_balconyb6', '')
                f1.balcony7_length = request.POST.get('7rent_balconyl7', '')
                f1.balcony7_breadth = request.POST.get('7rent_balconyb7', '')
            if rent_number_balcony == "8":
                f1.balcony = 8
                f1.balcony1_length = request.POST.get('8rent_balconyl1', '')
                f1.balcony1_breadth = request.POST.get('8rent_balconyb1', '')
                f1.balcony2_length = request.POST.get('8rent_balconyl2', '')
                f1.balcony2_breadth = request.POST.get('8rent_balconyb2', '')
                f1.balcony3_length = request.POST.get('8rent_balconyl3', '')
                f1.balcony3_breadth = request.POST.get('8rent_balconyb3', '')
                f1.balcony4_length = request.POST.get('8rent_balconyl4', '')
                f1.balcony4_breadth = request.POST.get('8rent_balconyb4', '')
                f1.balcony5_length = request.POST.get('8rent_balconyl5', '')
                f1.balcony5_breadth = request.POST.get('8rent_balconyb5', '')
                f1.balcony6_length = request.POST.get('8rent_balconyl6', '')
                f1.balcony6_breadth = request.POST.get('8rent_balconyb6', '')
                f1.balcony7_length = request.POST.get('8rent_balconyl7', '')
                f1.balcony7_breadth = request.POST.get('8rent_balconyb7', '')
                f1.balcony8_length = request.POST.get('8rent_balconyl8', '')
                f1.balcony8_breadth = request.POST.get('8rent_balconyb8', '')
            if rent_number_bathrooms == "1":
                f1.bathrooms = "1"
                f1.bathroom1_length = request.POST.get('rent_bathrooms_l_1', '')
                f1.bathroom1_breadth = request.POST.get('rent_bathrooms_b_1', '')
            if rent_number_bathrooms == "2":
                f1.bathrooms = "2"
                f1.bathroom1_length = request.POST.get('2rent_bathrooms_l_1', '')
                f1.bathroom1_breadth = request.POST.get('2rent_bathrooms_b_1', '')
                f1.bathroom2_length = request.POST.get('2rent_bathrooms_l_2', '')
                f1.bathroom2_breadth = request.POST.get('2rent_bathrooms_b_2', '')
            if rent_number_bathrooms == "3":
                f1.bathrooms = "3"
                f1.bathroom1_length = request.POST.get('3rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('3rent_bathroomsb1', '')
                f1.bathroom2_length = request.POST.get('3rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('3rent_bathroomsb2', '')
                f1.bathroom3_length = request.POST.get('3rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('3rent_bathroomsb3', '')
            if rent_number_bathrooms == "4":
                f1.bathrooms = "4"
                f1.bathroom1_length = request.POST.get('4rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('4rent_bathroomsb1', '')
                f1.bathroom2_length = request.POST.get('4rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('4rent_bathroomsb2', '')
                f1.bathroom3_length = request.POST.get('4rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('4rent_bathroomsb3', '')
                f1.bathroom4_length = request.POST.get('4rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('4rent_bathroomsb4', '')
            if rent_number_bathrooms == "5":
                f1.bathrooms = "5"
                f1.bathroom1_length = request.POST.get('5rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('5rent_bathroomsb1', '')
                f1.bathroom2_length = request.POST.get('5rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('5rent_bathroomsb2', '')
                f1.bathroom3_length = request.POST.get('5rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('5rent_bathroomsb3', '')
                f1.bathroom4_length = request.POST.get('5rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('5rent_bathroomsb4', '')
                f1.bathroom5_length = request.POST.get('5rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('5rent_bathroomsb5', '')
            if rent_number_bathrooms == "6":
                f1.bathrooms = "6"
                f1.bathroom1_length = request.POST.get('6rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('6rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('6rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('6rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('6rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('6rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('6rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('6rent_bathroomsb4', '')

                f1.bathroom5_length = request.POST.get('6rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('6rent_bathroomsb5', '')

                f1.bathroom6_length = request.POST.get('6rent_bathroomsl6', '')
                f1.bathroom6_breadth = request.POST.get('6rent_bathroomsb6', '')

            if rent_number_bathrooms == "7":
                f1.bathrooms = "7"
                f1.bathroom1_length = request.POST.get('7rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('7rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('7rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('7rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('7rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('7rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('7rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('7rent_bathroomsb4', '')

                f1.bathroom5_length = request.POST.get('7rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('7rent_bathroomsb5', '')

                f1.bathroom6_length = request.POST.get('7rent_bathroomsl6', '')
                f1.bathroom6_breadth = request.POST.get('7rent_bathroomsb6', '')

                f1.bathroom7_length = request.POST.get('7rent_bathroomsl7', '')
                f1.bathroom7_breadth = request.POST.get('7rent_bathroomsb7', '')

            if rent_number_bathrooms == "8":
                f1.bathrooms = "8"
                f1.bathroom1_length = request.POST.get('8rent_bathroomsl1', '')
                f1.bathroom1_breadth = request.POST.get('8rent_bathroomsb1', '')

                f1.bathroom2_length = request.POST.get('8rent_bathroomsl2', '')
                f1.bathroom2_breadth = request.POST.get('8rent_bathroomsb2', '')

                f1.bathroom3_length = request.POST.get('8rent_bathroomsl3', '')
                f1.bathroom3_breadth = request.POST.get('8rent_bathroomsb3', '')

                f1.bathroom4_length = request.POST.get('8rent_bathroomsl4', '')
                f1.bathroom4_breadth = request.POST.get('8rent_bathroomsl4', '')

                f1.bathroom5_length = request.POST.get('8rent_bathroomsl5', '')
                f1.bathroom5_breadth = request.POST.get('8rent_bathroomsl5', '')

                f1.bathroom6_length = request.POST.get('8rent_bathroomsl6', '')
                f1.bathroom6_breadth = request.POST.get('8rent_bathroomsb6', '')

                f1.bathroom7_length = request.POST.get('8rent_bathroomsl7', '')
                f1.bathroom7_breadth = request.POST.get('8rent_bathroomsb7', '')

                f1.bathroom8_length = request.POST.get('8rent_bathroomsl8', '')
                f1.bathroom8_breadth = request.POST.get('8rent_bathroomsb8', '')

            if rent_number_kitchen == "1":
                f1.rent_number_kitchen = 1
                f1.rent_kitchen_lenth_1 = request.POST.get('rent_kitchen_lenth_1', '')
                f1.rent_kitchen_breadth_1 = request.POST.get('rent_kitchen_breadth_1', '')

            if rent_number_kitchen == "2":
                f1.rent_number_kitchen = 2
                f1.rent_kitchen_lenth_1 = request.POST.get('rent_kitchen_lenth_1', '')
                f1.rent_kitchen_breadth_1 = request.POST.get('rent_kitchen_breadth_1', '')

                f1.rent_kitchen_lenth_2 = request.POST.get('rent_kitchen_lenth_2', '')
                f1.rent_kitchen_breadth_2 = request.POST.get('rent_kitchen_breadth_2', '')

            if rent_number_kitchen == "3":
                f1.rent_number_kitchen = 3
                f1.rent_kitchen_lenth_1 = request.POST.get('rent_kitchen_lenth_1', '')
                f1.rent_kitchen_breadth_1 = request.POST.get('rent_kitchen_breadth_1', '')

                f1.rent_kitchen_lenth_2 = request.POST.get('rent_kitchen_lenth_2', '')
                f1.rent_kitchen_breadth_2 = request.POST.get('rent_kitchen_breadth_2', '')

                f1.rent_kitchen_lenth_3 = request.POST.get('rent_kitchen_lenth_3', '')
                f1.rent_kitchen_breadth_3 = request.POST.get('rent_kitchen_breadth_3', '')

            # ----------------------------------------------------------
            floor_number_1 = request.POST.get('floor_number_1', '')
            if floor_number_1:
                f1.floor_number = request.POST.get('floor_number_1', '')
            else:
                f1.floor_number = request.POST.get('floor_number')
            total_floors_1 = request.POST.get('total_floors_1', '')

            if total_floors_1:
                f1.total_floors = request.POST.get('total_floors_1', '')
            else:
                f1.total_floors = request.POST.get('total_floors')
            # ---------------------------------------------------------
            furnished_status = request.POST.get('furnished_status', )
            print("furnished_status", furnished_status)
            if furnished_status is None or furnished_status == "":
                furnished_status_not_selected = True
            else:
                furnished_status_not_selected = False
            f1.furnished_status = request.POST.get('furnished_status', )
        f1.carpet_type = request.POST.get('rent_carpet_type', '')
        f1.carpet_area = request.POST.get('carpet_area', '')
        f1.super_type = request.POST.get('rent_super_type', '')
        f1.super_area = request.POST.get('super_area', '')
        f1.PoojaRoom = request.POST.get('PoojaRoom', False)
        f1.StudyRoom = request.POST.get('StudyRoom', False)
        f1.ServantRoom = request.POST.get('ServantRoom', False)
        f1.ClubHouse = request.POST.get('ClubHouse', False)

        f1.is_active = True
        if slug == 'rent':
            title = request.POST.get('property_title', '')
        else:
            title = request.POST.get('pg_title', '')
        f1.title = title
        state_1 = request.POST.get('state', '')
        district_1 = request.POST.get('district', '')
        locality_1 = request.POST.get('locality', '')
        district = Cities_db.objects.get(id=district_1)
        state = States_db.objects.get(id=state_1)
        if Locality_db.objects.filter(name=locality_1, city_id=district_1, state_id=state_1):
            print('already taken -------------------------------')
            locality = Locality_db.objects.get(name=locality_1, city_id=district_1, state_id=state_1)
        else:
            locality = Locality_db()
            locality.name = locality_1
            locality.state_id = state
            locality.city_id = district
            locality.save()
            locality = Locality_db.objects.get(name=locality_1, city_id=district_1, state_id=state_1)

        print(state, "saving state locality and district1111111111")
        f1.state = state
        print(district, "saving state locality and district22222222222")
        f1.district = district
        print(locality, "saving state locality and district333333333333333")
        f1.locality = locality

        f1.address = request.POST.get('address', '')
        f1.street_address = request.POST.get('street_address', '')
        f1.latlong = request.POST.get('latlong', '')
        f1.latitude = request.POST.get('latitude', '')
        f1.longitude = request.POST.get('longitude', '')
        f1.gender_prefer = request.POST.get('gender_prefer', '')

        if slug == 'rent':
            f1.description = request.POST.get('description', '')
            f1.prefered_tenant = request.POST.get('prefered_tenant', '')
        else:
            f1.description = request.POST.get('pg_description', '')
            f1.prefered_tenant = request.POST.get('prefered_tenant_pg', '')
        f1.prefered_tenant_type = request.POST.get('prefered_tenant_type', '')
        f1.occupation = request.POST.get('occupation', '')
        if slug == 'rent':
            total_rent = request.POST.get('total_rent', '')
            security_deposit = request.POST.get('security_deposit', '')
            f1.last_entry_time = request.POST.get('entery_time', '')

        else:
            total_rent = request.POST.get('pg_total_rent', '')
            print(total_rent, "--------------ttrent")
            f1.last_entry_time = request.POST.get('pg_entery_time', '')

            security_deposit = request.POST.get('pg_security_deposit', '')
            print(security_deposit, "--------------security_deposit")

        f1.total_rent = total_rent

        f1.security_deposit = security_deposit

        if request.POST.get('today_avaliable'):
            from datetime import datetime
            now = datetime.now()
            f1.availabilty = now.strftime("%d %B, %Y")
        else:
            f1.availabilty = request.POST.get('available_from', '')
        if 'dp' in request.FILES:
            f1.dp = request.FILES['dp']
            f1.images = True
        else:
            f1.dp = ""
            f1.images = False
        f1.parking = request.POST.get('parking', '')
        if request.POST.get('parking'):
            f1.parking_selected = True
        f1.notice_period = request.POST.get('notice_period', '')
        f1.veg_only = request.POST.get('veg_only', False)
        f1.no_smoking = request.POST.get('no_smoking', False)
        f1.no_drinking_alcohol = request.POST.get('no_drinking_alcohol', False)
        f1.no_opposite_gender = request.POST.get('no_opposite_gender', False)
        f1.noGuardian = request.POST.get('noGuardian', False)
        f1.pet_allowed = request.POST.get('pet_allowed', False)
        if request.POST.get('veg_only') or request.POST.get('no_smoking') or request.POST.get('no_drinking_alcohol') or \
                request.POST.get('no_opposite_gender') or request.POST.get('noGuardian') or request.POST.get(
            'pet_allowed'):
            f1.rules = True
        f1.laundary = request.POST.get('laundary', False)
        f1.room_cleaning = request.POST.get('room_cleaning', False)
        if request.POST.get('laundary') or request.POST.get('room_cleaning'):
            f1.services_available = True
        f1.Kitchen_self = request.POST.get('Kitchen_self', False)
        f1.security = request.POST.get('security', False)
        f1.ro = request.POST.get('ro', False)
        f1.fridge = request.POST.get('fridge', False)
        f1.Lift = request.POST.get('Lift', False)
        f1.Gymnasium = request.POST.get('Gymnasium', False)
        f1.PowerBackup = request.POST.get('PowerBackup', False)
        f1.WiFi = request.POST.get('WiFi', False)
        f1.TV = request.POST.get('TV', False)
        f1.SwimmingPool = request.POST.get('SwimmingPool', False)
        f1.CCTV = request.POST.get('CCTV', False)
        f1.Sofa = request.POST.get('Sofa', False)
        f1.DiningTable = request.POST.get('DiningTable', False)
        f1.ElectricChimney = request.POST.get('ElectricChimney', False)
        f1.ModularKitchen = request.POST.get('ModularKitchen', False)
        f1.Microwave = request.POST.get('Microwave', False)
        f1.WashingMachine = request.POST.get('WashingMachine', False)
        f1.Bed = request.POST.get('Bed', False)
        f1.Curtains = request.POST.get('Curtains', False)
        f1.Park = request.POST.get('Park', False)
        f1.VisitorParking = request.POST.get('VisitorParking', False)
        f1.AC = request.POST.get('AC', False)
        f1.Cooler = request.POST.get('Cooler', False)
        f1.Fan = request.POST.get('Fan', False)
        f1.WheelchairFriendly = request.POST.get('WheelchairFriendly', False)

        if request.POST.get('WheelchairFriendly') or request.POST.get('VisitorParking') or \
                request.POST.get('Park') or request.POST.get('Curtains') or \
                request.POST.get('Bed') or request.POST.get('WashingMachine') or \
                request.POST.get('Microwave') or request.POST.get('ModularKitchen') or \
                request.POST.get('ElectricChimney') or request.POST.get('ElectricChimney') or \
                request.POST.get('DiningTable') or request.POST.get('Sofa') or request.POST.get('CCTV') or \
                request.POST.get('SwimmingPool') or request.POST.get('Kitchen_self') or \
                request.POST.get('security') or request.POST.get('ro') or request.POST.get('fridge') or \
                request.POST.get('Lift') or request.POST.get('Gymnasium') or request.POST.get('PowerBackup') or \
                request.POST.get('WiFi') or request.POST.get('TV') or request.POST.get('PoojaRoom') or \
                request.POST.get('StudyRoom') or request.POST.get('ServantRoom') or request.POST.get('ClubHouse'):
            print("amentits - ok ")
            f1.amenity = True
        f1.Owner_Free = request.POST.get('Owner_Free', False)
        f1.Food_not_included = request.POST.get('Food_not_included', False)
        f1.Water_not_included = request.POST.get('Water_not_included', False)
        f1.DTH_not_included = request.POST.get('DTH_not_included', False)
        f1.Wifi_not_included = request.POST.get('Wifi_not_included', False)
        f1.Electricity_not_included = request.POST.get('Electricity_not_included', False)
        f1.Housekeeping_not_included = request.POST.get('Housekeeping_not_included', False)
        if request.POST.get('Food_not_included') or request.POST.get('Water_not_included') or \
                request.POST.get('DTH_not_included') or request.POST.get('Wifi_not_included') \
                or request.POST.get('Electricity_not_included') or request.POST.get('Housekeeping_not_included'):
            f1.not_included_Services = True
        f1.rules = request.POST.get('rules', False)
        if slug == "rent":
            f1.save()
            added = True

            primary_key_generated = f1.pk

        if slug == "pg":
            f1.save()
            added = True
            primary_key_generated = f1.pk

        rating = request.POST.get('rating', '')
        obj = tb_property.objects.get(property_id=primary_key_generated)
        dddd = review_db()
        dddd.property_id = obj
        dddd.rating1 = rating
        dddd.email = email
        dddd.name = username
        dddd.save()
        # ---------------------------------------------------------
        # for multiple selected attributes
        my_terms = Terms_Db.objects.values('slug', 'title', 'attributes_id')
        counter = 0
        for myterms in my_terms:
            counter += 1
            term_slug = myterms['slug']
            term_title = myterms['title']

            attr_id = myterms['attributes_id']

            res = request.POST.get(term_slug)
            if res == "True":
                if counter == 1:
                    attr_del = Attributes_Values.objects.filter(property_id_id="973").delete()
                    term_del = Terms_Values.objects.filter(property_id_id="973").delete()

                print(term_slug, "----------------terms")

                main_attributes = Attributes_Db.objects.values('id', 'title')
                for main_attr in main_attributes:

                    main_attr_id = main_attr['id']
                    main_attr_title = main_attr['title']
                    if main_attr['id'] == attr_id:
                        if primary_key_generated in [c.property_id_id for c in Attributes_Values.objects.all()]:

                            if attr_id not in [c.attributes_id for c in
                                               Attributes_Values.objects.filter(property_id=primary_key_generated)]:
                                attributes_value = Attributes_Values()
                                attributes_value.property_id = obj
                                attributes_value.attributes_id = main_attr_id
                                attributes_value.title = main_attr_title
                                attributes_value.save()

                        if attr_id in [c.attributes_id for c in Attributes_Values.objects.all()]:

                            if primary_key_generated not in [c.property_id_id for c in Attributes_Values.objects.all()]:
                                attributes_value = Attributes_Values()
                                attributes_value.property_id = obj
                                attributes_value.attributes_id = main_attr_id
                                attributes_value.title = main_attr_title
                                attributes_value.save()
                        else:
                            attributes_value = Attributes_Values()
                            attributes_value.property_id = obj
                            attributes_value.attributes_id = main_attr_id
                            attributes_value.title = main_attr_title
                            attributes_value.save()

                if primary_key_generated in [c.property_id_id for c in Terms_Values.objects.all()]:
                    if term_title not in [c.title for c in
                                          Terms_Values.objects.filter(property_id=primary_key_generated)]:
                        print("first if-----------")
                        terms_value = Terms_Values()
                        terms_value.property_id = obj
                        terms_value.title = term_title
                        terms_value.attributes_id = attr_id
                        terms_value.save()

                if term_title in [c.title for c in Terms_Values.objects.all()]:
                    if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                        print("second if-----------")
                        terms_value = Terms_Values()
                        terms_value.property_id = obj
                        terms_value.title = term_title
                        terms_value.attributes_id = attr_id
                        terms_value.save()

                if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                    if term_title not in [c.title for c in
                                          Terms_Values.objects.filter(property_id=primary_key_generated)]:
                        print("third if-----------")
                        terms_value = Terms_Values()
                        terms_value.property_id = obj
                        terms_value.title = term_title
                        terms_value.attributes_id = attr_id
                        terms_value.save()

        # for single selected attributes
        new_attr_ids = Attributes_Db.objects.values('id', 'title')
        for new_attr_id in new_attr_ids:
            attr_id2 = new_attr_id['id']
            new_attr_title = new_attr_id['title']

            new_my_terms = Terms_Db.objects.values('slug', 'title', 'attributes_id')
            for new_myterms in new_my_terms:
                term_slug = new_myterms['slug']
                term_title = new_myterms['title']
                attr_id = new_myterms['attributes_id']

        res = request.POST.get(new_attr_title)

        if res == "True":

            attributes_value = Attributes_Values()
            attributes_value.property_id = obj

            main_attributes = Attributes_Db.objects.values('id', 'title')
            for main_attr in main_attributes:

                main_attr_id = main_attr['id']
                main_attr_title = main_attr['title']
                if main_attr['id'] == attr_id:

                    if primary_key_generated in [c.property_id_id for c in Attributes_Values.objects.all()]:

                        if attr_id not in [c.attributes_id for c in
                                           Attributes_Values.objects.filter(property_id=primary_key_generated)]:
                            attributes_value.attributes_id = main_attr_id
                            attributes_value.title = main_attr_title
                            attributes_value.save()

                    if attr_id in [c.attributes_id for c in Attributes_Values.objects.all()]:

                        if primary_key_generated not in [c.property_id_id for c in
                                                         Attributes_Values.objects.all()]:
                            attributes_value.attributes_id = main_attr_id
                            attributes_value.title = main_attr_title
                            attributes_value.save()
                    else:
                        attributes_value.attributes_id = main_attr_id
                        attributes_value.title = main_attr_title
                        attributes_value.save()

            if primary_key_generated in [c.property_id_id for c in Terms_Values.objects.all()]:
                if term_title not in [c.title for c in Terms_Values.objects.filter(property_id=primary_key_generated)]:
                    terms_value = Terms_Values()
                    terms_value.property_id = obj
                    terms_value.title = term_title
                    terms_value.attributes_id = attr_id
                    terms_value.save()

            if term_title in [c.title for c in Terms_Values.objects.all()]:
                if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                    terms_value = Terms_Values()
                    terms_value.property_id = obj
                    terms_value.title = term_title
                    terms_value.attributes_id = attr_id
                    terms_value.save()

            if primary_key_generated not in [c.property_id_id for c in Terms_Values.objects.all()]:
                if term_title not in [c.title for c in Terms_Values.objects.filter(property_id=primary_key_generated)]:
                    terms_value = Terms_Values()
                    terms_value.property_id = obj
                    terms_value.title = term_title
                    terms_value.attributes_id = attr_id
                    terms_value.save()

        # -------------------------------------------------------------
        files = request.FILES.getlist('image')
        if files:
            for form_1 in files:
                if form_1:
                    image = form_1
                    photo = tb_property_images(property_id=f1, image=image)
                    photo.save()
        # ----------------------------------------------------------------------
        new_value = percentage_caluc(primary_key_generated, slug)
        get_property_data = tb_property.objects.get(property_id=primary_key_generated)
        get_property_data.percentage = new_value
        get_property_data.save()
        scheme = request.is_secure() and "https" or "http"
        current_site = get_current_site(request)
        if slug == "pg":
            u_link = f"edit-pg-form/{primary_key_generated}"

        if slug == "rent":
            u_link = f"edit-rent-form/{primary_key_generated}"
        view_link = scheme + "://" + smart_str(current_site.domain) + '/login_with_mailer/?email=' + smart_str(
            request.user.phone) + '&next=/' + u_link
        view_link = short_url(view_link)

        update_link = scheme + "://" + smart_str(current_site.domain) + '/login_with_mailer_email/?email=' + smart_str(
            request.user.email) + '&next=/' + u_link

        update_link = short_url(update_link)

        view_url = f"radeonn.com/view-details/{primary_key_generated}"
        d = ({
            'url': scheme + "://" + str(current_site.domain),
            'posted_user_name': posted_user_name,
            'title': title,

            'property_id': primary_key_generated,
            'percetange': new_value,
            'property_link': view_url,
            'property_up_link': update_link,

        })
        plaintext = get_template('email.txt')
        htmly = get_template('dashboard/add-proprety-email-template.html')
        subject, from_email, to = 'Congrats your ad post successfully...!', settings.DEFAULT_FROM_EMAIL, posted_user_email
        text_content = plaintext.render(d)
        html_content = htmly.render(d)
        msg = EmailMultiAlternatives(
            subject, text_content, from_email, [to])
        msg.attach_alternative(html_content, "text/html")
        msg.send()
        numbers = phone
        percentage = str(new_value)
        view_link = view_link
        sendmsg = request.POST.get('sendmsg', False)
        if sendmsg:
            check_message_sent = property_added_message(key, numbers, primary_key_generated, percentage, view_link)

        list = tb_property.objects.get(property_id=property_id)

        attributes = Attributes_Db.objects.all()
        terms = Terms_Db.objects.all()
        property_type = Property_Type.objects.all()
        property_title = Property_Title.objects.all()
        term_values = []
        terms_vals = Terms_Values.objects.filter(property_id=property_id).values("title")
        for term_val in terms_vals:
            k = term_val['title']
            term_values.append(k)

    return redirect('my_dashboard')


def percentage_caluc(primary_key_generated, slug):
    if tb_property.objects.filter(property_id=primary_key_generated).exists():
        db_data = tb_property.objects.filter(property_id=primary_key_generated).values()
        keys_count = 0
        count = 0
        values_count = 0
        for i in db_data:
            for keys, values in i.items():
                if slug == "rent":
                    total_balconies = ""
                    if keys == "balcony":
                        balcony = i["balcony"]
                        keys_count += 2
                        total_balconies = "balcony" + str(balcony) + "_breadth"
                        print(total_balconies, "total_balconies", balcony, "=balcony")
                        if balcony:
                            values_count += 1
                        else:
                            print("no balcony")
                        try:
                            total_no_balconies = i[total_balconies]
                            if total_no_balconies:
                                values_count += 1
                                print(total_no_balconies, "total_balconies 1")
                            else:
                                print("not upto bed balcony width")
                        except:
                            pass
                    if keys == "not_included_Services":
                        not_included_Services_value = i["not_included_Services"]
                        keys_count += 1
                        if not_included_Services_value:
                            values_count += 1
                        else:
                            print("not_included_Services missing")
                    if keys == "bathrooms":
                        bathrooms = i["bathrooms"]
                        keys_count += 2
                        if bathrooms:
                            values_count += 1
                        else:
                            print("bathrooms missing")
                        total_bathroom = "bathroom" + str(bathrooms) + "_breadth"
                        try:
                            total_no_bathroom = i[total_bathroom]
                            if total_no_bathroom:
                                values_count += 1
                                print(total_no_bathroom, "total_no_bathroom 1")
                            else:
                                print("not upto bed total_no_bathroom width")
                        except:
                            pass
                    if keys == "furnished_status":
                        furnished_status = i["furnished_status"]

                        keys_count += 1
                        if furnished_status:
                            values_count += 1
                        else:
                            print("furnished_status missing")
                    if keys == "total_floors":
                        total_floors = i["total_floors"]
                        keys_count += 1
                        if total_floors:
                            values_count += 1
                        else:
                            print("total_floors missing")
                    if keys == "floor_number":
                        floor_number = i["floor_number"]
                        keys_count += 1
                        if floor_number:
                            values_count += 1
                        else:
                            print("floor_number missing")
                    if keys == "age_of_construction":
                        age_of_construction = i["age_of_construction"]
                        keys_count += 1
                        if age_of_construction:
                            values_count += 1
                        else:
                            print("age_of_construction missing")
                    if keys == "maintain_charges_type":
                        maintain_charges_type = i["maintain_charges_type"]
                        keys_count += 1
                        if maintain_charges_type:
                            values_count += 1
                        else:
                            print("maintain_charges_type missing")
                    if keys == "maintain_charges":
                        maintain_charges = i["maintain_charges"]
                        keys_count += 1
                        if maintain_charges:
                            values_count += 1
                        else:
                            print("maintain_charges missing")
                    if keys == "rent_property_type":
                        rent_property_type = i["rent_property_type"]

                        keys_count += 1
                        if rent_property_type:
                            values_count += 1
                        else:
                            print("rent_property_type missing")
                    if keys == "rooms_rent":
                        rooms_rent = i["rooms_rent"]
                        keys_count += 1
                        if rooms_rent:
                            values_count += 1
                            if keys == "" + str(rooms_rent) + "_breadth":
                                keys_count += 1
                                bd_brdth = "bedroom" + str(rooms_rent) + "_breadth"
                                if bd_brdth:
                                    values_count += 1
                                else:
                                    print("not upto bed rooms width")
                        else:
                            print("rooms_rent missing")
                        total_bedroom = "bedroom" + str(rooms_rent) + "_breadth"
                        try:
                            total_no_bedroom = i[total_bedroom]
                            if total_no_bedroom:
                                values_count += 1
                                print(total_no_bedroom, "total_no_bathroom 1")
                            else:
                                print("not upto bed total_no_bathroom width")
                        except:
                            pass
                if keys == "amenity":
                    amenity_value = i["amenity"]
                    keys_count += 1
                    if amenity_value:
                        values_count += 1
                    else:
                        print("amentity missing")
                if keys == "images":
                    images_value = i["images"]
                    keys_count += 1
                    if images_value:
                        values_count += 1
                    else:
                        print("images missing")
                if keys == "services_available":
                    services_available = i["services_available"]
                    keys_count += 1
                    if services_available:
                        values_count += 1
                    else:
                        print("services_available missing")
                if keys == "dp":
                    dp = i["dp"]
                    keys_count += 1
                    if dp:
                        values_count += 1
                    else:
                        print("dp missing")
                if keys == "notice_period":
                    notice_period = i["notice_period"]
                    keys_count += 1
                    if notice_period:
                        values_count += 1
                    else:
                        print("notice_period missing")
                if keys == "last_entry_time":
                    last_entry_time = i["last_entry_time"]
                    keys_count += 1
                    if last_entry_time:
                        values_count += 1
                    else:
                        print("last_entry_time missing")
                if keys == "availabilty":
                    availabilty = i["availabilty"]
                    keys_count += 1
                    if availabilty:
                        values_count += 1
                    else:
                        print("availabilty missing")
                if keys == "security_deposit":
                    security_deposit = i["security_deposit"]
                    keys_count += 1
                    if security_deposit:
                        values_count += 1
                    else:
                        print("security_deposit missing")
                if keys == "total_rent":
                    total_rent = i["total_rent"]
                    keys_count += 1
                    if total_rent:
                        values_count += 1
                    else:
                        print("total_rent missing")
                if keys == "tenant_prefer":
                    tenant_prefer = i["tenant_prefer"]
                    keys_count += 2
                    if tenant_prefer:
                        values_count += 1
                    else:
                        print("tenant_prefer missing")
                if keys == "description":
                    description = i["description"]
                    keys_count += 1
                    if description:
                        values_count += 1
                    else:
                        print("description missing")
                if keys == "address":
                    address = i["address"]
                    keys_count += 1
                    if address:
                        values_count += 1
                    else:
                        print("address missing")
                if keys == "locality":
                    locality = i["locality"]
                    keys_count += 1
                    if locality:
                        values_count += 1
                    else:
                        print("locality missing")
                if keys == "district":
                    district = i["district"]
                    keys_count += 1
                    if district:
                        values_count += 1
                    else:
                        print("district missing")
                if keys == "state":
                    state = i["state"]
                    keys_count += 1
                    if state:
                        values_count += 1
                    else:
                        print("state missing")
                if keys == "title":
                    title = i["title"]

                    keys_count += 1
                    if title:
                        values_count += 1
                    else:
                        print("title missing")
        print("total keys_count count =", keys_count)
        print("total count =", values_count)
        average = (values_count / keys_count) * 100
        average = str(average)
        a = average.split('.')
        b = a[1][:1]
        new_value = a[0] + "." + b
        get_property_data = tb_property.objects.get(property_id=primary_key_generated)
        get_property_data.percentage = new_value
        get_property_data.save()
    return new_value


from itertools import chain


@login_required(login_url="login")
def my_dashboard(request):
    if request.user.phone:
        my_properties_data1 = tb_property.objects.filter(posted_user_phone1=request.user.phone).order_by('-property_id')
    if request.user.email:
        my_properties_data2 = tb_property.objects.filter(posted_user_email=request.user.email).order_by('-property_id')

    if request.user.phone:
        my_properties_data = my_properties_data1
    if request.user.email:
        my_properties_data = my_properties_data2
    if request.user.phone and request.user.email:
        my_properties_data = set(chain(my_properties_data1, my_properties_data2))
        my_properties_data = list(my_properties_data)

    return render(request, 'userdashboard.html', locals())


@login_required(login_url="login")
def go_to(request):
    if 'go_to' in request.session:
        n_url = request.session['go_to']
        return redirect(n_url)
    else:
        my_properties_data = tb_property.objects.filter(posted_user_phone1=request.user.phone).order_by('-property_id')
        return render(request, 'userdashboard.html', locals())


@login_required(login_url="login")
def my_active_inactive(request, property_id, is_active):
    if int(is_active) == 1:
        is_active = True
        aaa = tb_property.objects.get(property_id=property_id)
        zzz = notify_property.objects.filter(property_id=property_id)
        list_email = []
        for i in zzz:
            list_email.append(i.email)
        scheme = request.is_secure() and "https" or "http"
        current_site = get_current_site(request)
        d = ({
            'title': aaa.title,
            'total_rent': aaa.total_rent,
            'state': aaa.state,
            'district': aaa.district,
            'locality': aaa.locality,
            'rooms_rent': aaa.rooms_rent,
            'property_id': property_id,
            'property_link': scheme + "://" + str(current_site.domain) + '/view-details/' + str(property_id),

        })
        plaintext = get_template('email.txt')
        htmly = get_template('registration/notify-property-email.html')
        subject, from_email, to = 'Property added on Rade onn', settings.DEFAULT_FROM_EMAIL, list_email
        text_content = plaintext.render(d)
        html_content = htmly.render(d)
        msg = EmailMultiAlternatives(
            subject, text_content, from_email, [to])
        msg.attach_alternative(html_content, "text/html")
        msg.send()
    else:
        is_active = False
    from datetime import datetime
    now = datetime.now()
    tb_property.objects.filter(property_id=property_id).update(is_active=is_active, js_cart_id='', user_id='',
                                                               posted_on=now.strftime("%d %B, %Y"))
    return redirect('my_dashboard')


@login_required(login_url="login")
def checklogintype(request):
    if 'clicked_url' in request.session:
        return redirect("/post-property")
    else:
        return redirect("/my-dashboard")







