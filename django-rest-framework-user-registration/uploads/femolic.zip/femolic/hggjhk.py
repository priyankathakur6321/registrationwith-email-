import pandas as pd
import numpy as np
from reportlab.lib.PyFontify import pat

df = pd.read_csv("/home/webtunixpri/Downloads/1637216378-area.csv")
# print(df)
# aa = df['Area(sq.ft)'].str.split(',', expand=True)
# print(aa)
# df[['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']] = df['Area(sq.ft)'].str.split(',', expand=True)
# df[np.arange(len(df['Area(sq.ft)'].tolist()[0].split(',')))] = df['Area(sq.ft)'].str.split(',', expand=True)
ll = [len(i.split(',')) for i in df['Area(sq.ft)'].tolist()]
# # print(ll)
df[np.arange(max(ll))] = df['Area(sq.ft)'].str.split(',', expand=True)
# print(len(df.columns))
# for col in df.columns:
#     # print(col)

# df.drop([0, 2, 4, 6, 8], axis=1, inplace=True)
# print(df)
df.columns = ['projectName', 'Area(sq.ft)', 'Master Bedroom', 'Bedroom', 'Bedroom', 'Bedroom', ' Study Room']
print(df)



