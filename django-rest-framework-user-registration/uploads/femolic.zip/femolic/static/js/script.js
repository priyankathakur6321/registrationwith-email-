/**************************************
       header-script-start
***************************************/
var sections = $('section')
  , nav = $('nav')
  , nav_height = nav.outerHeight();

$(window).on('scroll', function () {
  var cur_pos = $(this).scrollTop();

  sections.each(function() {
    var top = $(this).offset().top - nav_height,
        bottom = top + $(this).outerHeight();

    if (cur_pos >= top && cur_pos <= bottom) {
      nav.find('a').removeClass('active');
      sections.removeClass('active');

      $(this).addClass('active');
      nav.find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
    }
  });
});

nav.find('a').on('click', function () {
  var $el = $(this)
    , id = $el.attr('href');

  $('html, body').animate({
    scrollTop: $(id).offset().top - nav_height
  }, 500);

  return false;
});

/*end-script*/


/**************************************
       header-script-start
***************************************/
window.onscroll = function() {myFunction()};

var header = document.getElementById("webtunix_header");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
/*--- script-end ---*/




$('.digit-group').find('input').each(function() {
	$(this).attr('maxlength', 1);
	$(this).on('keyup', function(e) {
		var parent = $($(this).parent());

		if(e.keyCode === 8 || e.keyCode === 37) {
			var prev = parent.find('input#' + $(this).data('previous'));

			if(prev.length) {
				$(prev).select();
			}
		} else if((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
			var next = parent.find('input#' + $(this).data('next'));

			if(next.length) {
				$(next).select();
			} else {
				if(parent.data('autosubmit')) {
					parent.submit();
				}
			}
		}
	});
});



$( ".webtunix-login-btn" ).mouseenter(function(e) {
   var parentOffset = $(this).offset();

   var relX = e.pageX - parentOffset.left;
   var relY = e.pageY - parentOffset.top;
   $(this).prev(".webtunixsu_button_circle").css({"left": relX, "top": relY });
   $(this).prev(".webtunixsu_button_circle").removeClass("desplode-circle");
   $(this).prev(".webtunixsu_button_circle").addClass("explode-circle");

});

$( ".webtunix-login-btn" ).mouseleave(function(e) {

     var parentOffset = $(this).offset();

     var relX = e.pageX - parentOffset.left;
     var relY = e.pageY - parentOffset.top;
     $(this).prev(".webtunixsu_button_circle").css({"left": relX, "top": relY });
     $(this).prev(".webtunixsu_button_circle").removeClass("explode-circle");
     $(this).prev(".webtunixsu_button_circle").addClass("desplode-circle");

});