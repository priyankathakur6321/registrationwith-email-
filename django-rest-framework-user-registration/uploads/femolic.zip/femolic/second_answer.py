import mysql.connector

try:
    connection = mysql.connector.connect(host='localhost',
                                         database='locationdata',
                                         user='root',
                                         password='')
    sql_select_Query = "SELECT device_id FROM locations_footfalls INNER JOIN locations ON (3959 * acos(cos(radians(locations.lat)) * cos(radians(latitude)) * cos(radians(longitude) - radians(locations.long)) + sin(radians(locations.lat)) * sin(radians(latitude)))) <= 100; "

    cursor = connection.cursor()
    cursor.execute(sql_select_Query)
    # get all records
    records = cursor.fetchall()
    print("Total number of rows in table: ", cursor.rowcount)

    print("\nPrinting each row")
    for row in records:
       print(row)

except mysql.connector.Error as e:
    print("Error reading data from MySQL table", e)
finally:
    if connection.is_connected():
        connection.close()
        cursor.close()
        print("MySQL connection is closed")