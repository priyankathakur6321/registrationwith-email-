"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from django.urls import path
from django.views.static import serve
from django.conf.urls.static import static

from myapp import views
from myapp import views
from myproject import settings
from myproject.settings import DEBUG
from django.conf.urls.static import static
from django.views.static import serve

urlpatterns = [
    url('api/', include('apiapp.urls')),

    path('admin/', admin.site.urls),
    url(r'^admin-login', views.admin_login, name='admin-login'),

    url('ckeditor', include('ckeditor_uploader.urls')),
    url('^ajax/load-cities/', views.load_cities, name='ajax_load_cities'),  # <-- this one here

    path(r'', views.index, name='index'),
    url(r'^login', views.signin_with_phone, name='login'),
    url(r'^otp', views.otp, name='otp'),
    url(r'^blog', views.blog, name='blog'),
    url(r'^goverments', views.goverments, name='goverments'),
    url(r'^support_request_list', views.support_request_list, name='support_request_list'),


    url(r'^admin-index', views.admin_index, name='admin_index'),

    url(r'^add-employee', views.add_employee, name='add_employee'),
    url(r'^delete_emp', views.delete_emp, name='delete_emp'),
    url(r'^edit_add_emp', views.edit_add_emp, name='edit_add_emp'),
    url(r'^search', views.search, name='search'),

    url(r'^address-list', views.address_list, name='address_list'),
    path('request', views.request, name='request'),
    path('request-accepted', views.request_accepted, name='request_accepted'),
    path('request-declined', views.request_declined, name='request_declined'),
    url(r'^users', views.users, name='users'),
    url(r'^address_list_search', views.address_list_search, name='address_list_search'),
    url(r'^user_search', views.user_search, name='user_search'),
    url(r'^delete_address_list', views.delete_address_list, name='delete_address_list'),
    url(r'^edit_address_list', views.edit_address_list, name='edit_address_list'),
    url(r'view_user_detail/(?P<generate_code>[0-9a-zA-z_-]+)$', views.view_user_detail, name='view_user_detail'),
    path('get_location', views.get_location, name='get_location'),

]
if DEBUG == True:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
else:
    urlpatterns += [
        url(r'^static/(?P<path>.*)$', serve, {'document_root': settings.STATIC_ROOT}),
        url(r'^media/(?P<path>.*)$', serve, {'document_root': settings.MEDIA_ROOT}),
]



