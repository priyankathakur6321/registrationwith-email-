# from django.contrib.auth.models import AbstractUser
import re

from django.contrib.auth.models import AbstractUser
from django.core import validators
from django.db import models

# Create your models here.

# from django.contrib.auth.models import AbstractUser
from django.db import models
from ckeditor.fields import RichTextField
from django.utils.translation import ugettext_lazy as _
# Create your models here.


class add_employee_db(models.Model):
    name  = models.CharField(max_length=100)
    email = models.EmailField(max_length=1000)
    phone_number = models.CharField(max_length=16)
    designation = models.CharField(max_length=100)
    emp_id =  models.CharField(max_length=16,default="",null=True, blank=True)
    aadhar_card = models.CharField(max_length=16,null=True,blank=True)




    class Meta:
        db_table = 'add_employee_db'

class User(AbstractUser):

    is_seller = models.BooleanField(default=False)
    phone = models.CharField(default="",max_length=20)
    otp = models.CharField(default="",max_length=30,null=True)
    otp_expired = models.BooleanField(default=True)
    nickname = models.CharField(default="",max_length=30,null=True)
    phone2 =models.CharField(default="",max_length=30,null=True)
    refrel_point = models.IntegerField(default=0)
    refrel_status =models.CharField(default="0",max_length=30,null=True)
    bank_name = models.CharField(max_length=30,null=True)
    bank_account = models.CharField(max_length=30,null=True)
    account_holder_name = models.CharField(max_length=30,null=True)
    ifse_code = models.CharField(max_length=30,null=True)
    refrel_date = models.CharField(max_length=30,null=True)
    phone_number = models.CharField(max_length=16,default="", null=True, blank=True)
    aadhar_card = models.CharField(max_length=16, null=True, blank=True)
    user_type = models.CharField(default="", max_length=100, null=True, blank=True)
    email = models.EmailField(max_length=1000,default="", null=True, blank=True)

    # for employee
    designation = models.CharField(max_length=100, null=True, blank=True)
    emp_id = models.CharField(max_length=100, default="", null=True, blank=True)


class request_db(models.Model):
    name  = models.CharField(max_length=100)
    address = models.CharField(max_length=100,default="", null=True, blank=True)
    state = models.CharField(default="", max_length=100)
    city = models.CharField(default="", max_length=100)
    password1 = models.CharField(max_length=100,default="", null=True, blank=True)
    password2 = models.CharField(max_length=100,default="", null=True, blank=True)
    # latlong = models.TextField(default="", null=True, blank=True)
    latitude = models.TextField(default="", null=True, blank=True)
    longitude = models.TextField(default="", null=True, blank=True)
    email = models.EmailField(max_length=254,default="", null=True, blank=True)
    phone_number = models.CharField(max_length=16, default="", null=True, blank=True)
    aadhar_card = models.CharField(max_length=16, null=True, blank=True)
    user_id = models.CharField(max_length=16, default="", null=True, blank=True)
    qr_code_image = models.FileField(default="", null=True, blank=True, upload_to='qr_code_image')
    request_emp_id = models.ForeignKey(User,on_delete=models.CASCADE, default="", null=True, blank=True)
    request_accepted = models.CharField(max_length=244,default="not_define", null=True, blank=True)
    request_approved = models.BooleanField(default=False)
    request_by_emp = models.CharField(max_length=244,default="not_define", null=True, blank=True)
    # requested_by = models.CharField(max_length=254,default="", null=True, blank=True)


    class Meta:
        db_table = 'request_db'

#
class Blog_Category_Db(models.Model):
    title = models.CharField(max_length=100)
    description = models.CharField(max_length=1000)
    date = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = 'Blog_Category_Db'
    def __str__(self):
        return self.title


class Blog_Db(models.Model):
    Blog_Category_id = models.ForeignKey(Blog_Category_Db ,null=True, blank=True,on_delete=models.CASCADE)
    title = models.CharField(max_length=100,)
    image = models.FileField(upload_to='blog_photo')
    details = RichTextField()
    date = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = 'Blog_Db'


class Blog_view_db(models.Model):
    name  = models.CharField(max_length=100)
    email = models.EmailField(max_length=1000)
    contact_number = models.IntegerField()
    subject  = models.CharField(max_length=100)


    class Meta:
        db_table = 'Blog_view_db'


class States_db(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=150, null=False)
    country_id = models.CharField(max_length=150, default=1)
    create_date = models.DateTimeField(auto_now_add=True)
    state_code=models.CharField(max_length=150,blank=True,null=True)


    def __str__(self):
        return self.name

class Cities_db(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=150, null=False)
    state_id = models.ForeignKey(States_db,  on_delete=models.CASCADE, default="")
    create_date = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return self.name








