from dal import autocomplete
from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.forms import PasswordResetForm, UserCreationForm
from django.contrib.auth.models import User
# from dashboardapp.models import *
from ckeditor_uploader.widgets import CKEditorUploadingWidget
from django.db import transaction

from .models import *

class SignUpForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'}))
    last_name = forms.CharField(max_length=30, required=False,widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last Name'}))
    email = forms.EmailField(max_length=254, required=False,widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email'}))
    username = forms.CharField(max_length=30, required=False,widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}))
    password1 = forms.CharField(max_length=30, required=True,widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}))
    password2 = forms.CharField(max_length=30, required=True, widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Repeat Password to check typos'}))
    phone = forms.CharField(max_length=30, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Phone number'}))
    otp = forms.CharField(max_length=30, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter OTP'}))
    nickname = forms.CharField(max_length=30, required=False,widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Nickname'}))
    phone2 = forms.CharField(max_length=30, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Second Phone Number (optional)'}))


    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email','password1', 'password2', 'is_seller', 'phone','otp','otp_expired','phone2','is_active')
    try:
        def clean_email(self):
            email = self.cleaned_data.get('email')
            if email is not None:
                if User.objects.filter(email=email).exists():
                    raise forms.ValidationError(u'Email already exists.')
                return email
    except:
        pass


class request_db_form(forms.ModelForm):
    name = forms.CharField(required=False)
    address = forms.CharField(required=False)
    email = forms.EmailField(required=False)
    phone_number = forms.IntegerField(required=False)
    aadhar_card = forms.CharField(required=False)

    class Meta:
        model = request_db
        # User._meta.get_field('username')._unique = False
        fields = ['name','address','email','city','state','latitude','longitude','phone_number','aadhar_card']

    def clean_email(self):
        print(self.instance.pk,'----------------')

        email = self.cleaned_data.get('email')
        if self.instance.pk:
            return email
        else:
            if email is not None:
                if request_db.objects.filter(email=email).exists():
                    raise forms.ValidationError(u'Email already exists.')
                return email


class Blog_Category_Form(forms.ModelForm):
    title = forms.CharField(required=True,max_length=100,widget=forms.TextInput(attrs={'class': "inputfield"}))
    description = forms.CharField(required=True,max_length=1000,widget=forms.TextInput(attrs={'class': "inputfield"}))
    class Meta:
        model = Blog_Category_Db
        fields = ['title', 'description']
    def clean_title(self):
        if self.instance.pk != None:
            title = self.cleaned_data.get('title')
            list = Blog_Category_Db.objects.filter(title__iexact=title, id=self.instance.pk)
            if list:
                return title
            else:
                if title and Blog_Category_Db.objects.filter(title__iexact=title).exists():
                    raise forms.ValidationError(u'Title already exists.')
                return title
        else:
            title = self.cleaned_data.get('title')
            if title and Blog_Category_Db.objects.filter(title__iexact=title).exists():
                    raise forms.ValidationError(u'Title already exists.')
        return title



class Blog_Form(forms.ModelForm):
    title = forms.CharField(required=True,max_length=100, widget=forms.TextInput(attrs={'class': "inputfield"}))
    image = forms.ImageField(required=True,max_length=100,)
    details = forms.CharField(required=True, max_length=3000, widget=CKEditorUploadingWidget())
    Blog_Category_id = forms.ModelChoiceField(required=True,queryset=Blog_Category_Db.objects.all(), empty_label="Select Category",widget=forms.Select(attrs={'class': "inputfield"}))
    class Meta:
        # managed = False
        model = Blog_Db
        fields = ['title','image','details' ,'Blog_Category_id',]
    def clean_title(self):
        if self.instance.pk != None:
            title = self.cleaned_data.get('title')
            list = Blog_Db.objects.filter(title__iexact=title,id=self.instance.pk)
            if list:
                return title
            else:
                if title and Blog_Db.objects.filter(title__iexact=title).exists():
                    raise forms.ValidationError(u'Title already exists.')
                return title
        else:
            title = self.cleaned_data.get('title')
            if title and Blog_Db.objects.filter(title__iexact=title).exists():
                raise forms.ValidationError(u'Title already exists.')
        return title

class Blog_view_db_form(forms.ModelForm):
    class Meta:
        model = Blog_view_db
        fields = ['name','email','contact_number','subject']



class add_employee_db_form(forms.ModelForm):
    username = forms.CharField(required=True,max_length=254,widget=forms.TextInput(attrs={'class': "form-control"}))
    email = forms.EmailField( max_length=254,required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))
    phone_number = forms.CharField(required=True,max_length=254,widget=forms.TextInput(attrs={'class': "form-control"}))
    designation = forms.CharField(required=True,max_length=254,widget=forms.TextInput(attrs={'class': "form-control"}))
    emp_id = forms.CharField(required=True,max_length=254,widget=forms.TextInput(attrs={'class': "form-control"}))
    aadhar_card = forms.CharField(required=True,max_length=254,widget=forms.TextInput(attrs={'class': "form-control"}))
    password1 = forms.CharField(max_length=30, required=True,
                                widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}))
    password2 = forms.CharField(max_length=30, required=True, widget=forms.PasswordInput(
        attrs={'class': 'form-control', 'placeholder': 'Repeat Password'}))


    class Meta:
        model = User
        fields = ['username','email','phone_number','designation','emp_id','aadhar_card','password1','password2',]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self._meta.model.USERNAME_FIELD in self.fields:
            self.fields[self._meta.model.USERNAME_FIELD].widget.attrs.update({'autofocus': True})

    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            # raise forms.ValidationError(
            #     self.error_messages['password_mismatch'],
            #     code='password_mismatch',
            # )
            raise forms.ValidationError(u'Password not Match.')

        return password2

    def _post_clean(self):
        super()._post_clean()
        # Validate the password after self.instance is updated with form data
        # by super().
        password = self.cleaned_data.get('password2')
        if password:
            try:
                password_validation.validate_password(password, self.instance)
            except forms.ValidationError as error:
                self.add_error('password2', error)

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


    def clean_email(self):
        print(self.instance.pk,'----------------')

        email = self.cleaned_data.get('email')
        if self.instance.pk:
            return email
        else:
            if email is not None:
                if User.objects.filter(email=email).exists():
                    raise forms.ValidationError(u'Email already exists.')
                return email


class UserLoginForm(forms.Form):
    email = forms.EmailField(label="Email Address", max_length=254,required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))
    password = forms.CharField(label='Password',required=True,max_length=254,widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    def clean_email(self):
        email = self.cleaned_data['email']
        if not User.objects.filter(email__iexact=email,is_active=True).exists():
            raise forms.ValidationError(
                "There is no user registered with the specified email address!")



