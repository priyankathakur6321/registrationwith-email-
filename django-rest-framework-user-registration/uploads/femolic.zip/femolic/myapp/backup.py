import math
import os
import random

from django.contrib.auth import login
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password

from myapp.forms import SignUpForm, request_db_form, Blog_view_db_form
from myapp.messages_send import sendotp
from django.core.mail import send_mail, EmailMultiAlternatives
from django.contrib import messages, auth
from django.template.loader import get_template

from myapp.models import Blog_Db, Blog_Category_Db, States_db, Cities_db, request_db
from myproject.settings import DEFAULT_FROM_EMAIL, BASE_DIR
import pyqrcode
import png
import qrcode
import cv2
from pyqrcode import QRCode
key = 'V/eW+6qrm60-Bw8qAXFEKBlvbeOwyrVmMQD5AGl2f5'



def index(request):
    blog_list = Blog_Db.objects.all()
    list = States_db.objects.filter(country_id=101)

    if request.method == "POST":
        form = request_db_form(request.POST, request.FILES)
        print(form, 'efrfgfg')
        if form.is_valid():
            print('142356656')
            f = form.save(commit=False)
            digit_1 = request.POST.get('digit_1')
            digit_2 = request.POST.get('digit_2')
            digit_3 = request.POST.get('digit_3')
            digit_4 = request.POST.get('digit_4')
            digit_5 = request.POST.get('digit_5')
            digit_6 = request.POST.get('digit_6')
            digit_7 = request.POST.get('digit_7')
            digit_8 = request.POST.get('digit_8')
            digit_9 = request.POST.get('digit_9')
            digit_10 = request.POST.get('digit_10')
            digit_11 = request.POST.get('digit_11')
            digit_12 = request.POST.get('digit_12')

            f.name = request.POST['name']
            f.address = request.POST['address']
            f.state = request.POST['state']

            f.city = request.POST['city']
            # f.latlong = request.POST['latlong']
            f.latitude = request.POST['latitude']
            f.longitude = request.POST['longitude']
            f.email = request.POST['email']
            f.phone_number = request.POST['phone_number']
            aadhar_card = digit_1 + digit_2 + digit_3 + digit_4 + digit_5 + digit_6 + digit_7 + digit_8 + digit_9 + digit_10 + digit_11 + digit_12
            f.aadhar_card = aadhar_card
            aadhar_card=str(aadhar_card)
            print('###############')
            form.save()
            print('save')

            # to generate random id
            rn=random.randint(100000, 999970)
            state= request.POST['state']
            state = [c.name for c in States_db.objects.filter(id=state)]
            stat_rn=str(state)
            s_rn = stat_rn[2:4]
            s_rn = s_rn.upper()
            generate_code =f"{s_rn}-{rn}"
            print(generate_code,"---------------lrn")


            # to create qr code img
            domain = "http://localhost:8000"
            view_link = "/view_user_detail/"
            qr_link = f"{domain}{view_link}{generate_code}"
            img_qr= qrcode.make(qr_link)
            folder_path = os.path.join(BASE_DIR, "media/qr_image/")
            img_name=f"{folder_path}{generate_code}.png"
            # qr_code_image=img_qr.png(img_name, scale=6)
            img_qr.save(img_name)
            print(img_qr,"----------------gr_img")

            #  to save random_id and qr_code_img
            obj=request_db.objects.get(aadhar_card=aadhar_card)
            print(obj,'***************')
            obj.user_id=generate_code
            obj.qr_code_image=img_name
            obj.save()
            print('objsave')

            # to read qr code img
            d = cv2.QRCodeDetector()
            val, points, straight_qrcode = d.detectAndDecode(cv2.imread(img_name))
            print(val,"---------------")

            # if randomnumber not in [c.user_id for c in Views_On_Property.objects.all()]:
            #     request.session['set_my_id'] = randomnumber
            # else:
            #     randomnumber = random.randint(-50000, -11)
            #     print(randomnumber)
            return HttpResponseRedirect('/')

    else:
        request_db_form()
    return render(request, 'index.html', locals())


# def login(request):
#     return render(request, 'login.html', locals())

def otp(request):
    return render(request, 'otp.html', locals())

def goverments(request):
    return render(request, 'goverments.html', locals())

def view_user_detail(request,generate_code):
    list=request_db.objects.get(user_id=generate_code)
    print(list,'9999')
    return render(request, 'view_user_detail.html', locals())


def signin_with_phone(request):
    print("-----------------------------------------")
    digits = [i for i in range(0, 10)]
    generated_otp = ""
    for i in range(6):
        index_1 = math.floor(random.random() * 10)
        generated_otp += str(digits[index_1])
    print(generated_otp)
    form = SignUpForm()
    if 'step1_phone' in request.POST:
        entered_phone_number = request.POST['phone_number']
        print(entered_phone_number, type(entered_phone_number))
        if User.objects.filter(phone=entered_phone_number).exists():
            user = User.objects.get(phone=entered_phone_number)
            user.otp = generated_otp
            user.set_password(generated_otp)
            user.otp_expired = False
            user.save()
            check_message_sent = sendotp(key, entered_phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'otp.html', locals())
            else:
                phone_error = True
                print("error")
            print("exists")
        else:
            form = SignUpForm(request.POST)
            print(form)
            # if form.is_valid():
            user = User.objects.create_user(username=str(request.POST['phone_number']),
                                            password=generated_otp,
                                            is_active=False,
                                            is_seller=True,
                                            otp=generated_otp,
                                            otp_expired=False,
                                            phone=str(request.POST['phone_number']))

            phone_number = request.POST['phone_number']

            check_message_sent = sendotp(key, phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'otp.html', locals())
            else:
                phone_error = True
    print("after-----------------------------")
    if 'otp_entered' in request.POST:
        entered_phone_number = request.POST['entered_phone_number']
        print(entered_phone_number, '*****')
        digit_1 = request.POST['digit-1']
        digit_2 = request.POST['digit-2']
        digit_3 = request.POST['digit-3']
        digit_4 = request.POST['digit-4']
        digit_5 = request.POST['digit-5']
        digit_6 = request.POST['digit-6']
        entered_otp = digit_1 + digit_2 + digit_3 + digit_4 + digit_5 + digit_6
        print(entered_otp, '###')
        print(type(entered_otp), '###')
        user = User.objects.get(phone=entered_phone_number)
        if check_password(entered_otp, user.password):
            print("matched")
            if not user.otp_expired:
                user.otp_expired = False
                user.is_active = True
                user.save()
                login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                # login(request, user)
                return redirect('index')
            elif user.otp_expired:
                otp_expired = True
                return render(request, 'otp.html', locals())


        else:
            otp_expired = True
            return render(request, 'otp.html', locals())
    return render(request, 'login.html', locals())


# def user_detail(request):
#     print("****************************")
#     if request.method == "POST":
#         form = request_db_form(request.POST, request.FILES)
#         print(form, 'efrfgfg')
#         if form.is_valid():
#             print('142356656')
#             f = form.save(commit=False)
#             digit_1 = request.POST.get('digit_1')
#             digit_2 = request.POST.get('digit_2')
#             digit_3 = request.POST.get('digit_3')
#             digit_4 = request.POST.get('digit_4')
#             digit_5 = request.POST.get('digit_5')
#             digit_6 = request.POST.get('digit_6')
#             digit_7 = request.POST.get('digit_7')
#             digit_8 = request.POST.get('digit_8')
#             digit_9 = request.POST.get('digit_9')
#             digit_10 = request.POST.get('digit_10')
#             digit_11 = request.POST.get('digit_11')
#             digit_12 = request.POST.get('digit_12')
#
#             f.name = request.POST['name']
#             f.address = request.POST['address']
#             f.state = request.POST['state']
#             f.city = 'chandigarh'
#             f.city = request.POST['city']
#             f.latlong = '455'
#             f.latitude = '5657'
#             f.longitude = '789'
#             f.email = request.POST['email']
#             f.phone_number = request.POST['phone_number']
#             aadhar_card = digit_1 + digit_2 + digit_3 + digit_4 + digit_5 + digit_6 + digit_7 + digit_8 + digit_9 + digit_10 + digit_11 + digit_12
#             f.aadhar_card = aadhar_card
#             print('###############')
#             form.save()
#             print('save')
#             return HttpResponseRedirect('/')
#
#     else:
#         request_db_form()
#     return render(request, "index.html")


def blog(request):
    return render(request, 'blog.html', locals())


def blog_page(request):
    title = 'webtunix solutions'
    keywords = 'machine learning, business solutions'
    description = 'webtunix solutions - business solutions provider'

    blog_list = Blog_Db.objects.all()
    blog_category_list = Blog_Category_Db.objects.all()

    if request.method == "POST":
        form = Blog_view_db_form(request.POST, request.FILES)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            print(name, 'hcbskfh')
            email = form.cleaned_data.get('email')
            print(email, 'hbhcskdc')
            contact_number = form.cleaned_data.get('contact_number')
            print(contact_number, 'hdhchjcd')
            subject = form.cleaned_data.get('subject')
            print(subject, 'hdhhfc')
            form.save()
            print('save')
            saved = True
            messages.success(request, 'Thank-you for Contact Us')
            send_mail('Project Enquiry on info@ris-ai.com',
                      '\nName :' + name + '\nEmail:' + email + '\nContact Number:' + str(
                          contact_number) + '\nSubject :' + subject,
                      DEFAULT_FROM_EMAIL, [DEFAULT_FROM_EMAIL], fail_silently=False)
            d = ({'email': email})
            plaintext = get_template('email.txt')
            htmly = get_template('email-templates/contact-us.html')
            subject, from_email, to = 'Thank You For Contacting Us', 'info@ris-ai.com', email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
            thankyou = True

    return render(request, "blog.html", locals())


def blog_view(request):
    blog_list = Blog_Db.objects.all()
    blog_category_list = Blog_Category_Db.objects.all()

    if request.method == "POST":
        form = Blog_view_db_form(request.POST, request.FILES)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            print(name, 'hcbskfh')
            email = form.cleaned_data.get('email')
            print(email, 'hbhcskdc')
            contact_number = form.cleaned_data.get('contact_number')
            print(contact_number, 'hdhchjcd')
            subject = form.cleaned_data.get('subject')
            print(subject, 'hdhhfc')
            form.save()
            print('save')
            saved = True
            messages.success(request, 'Thank-you for Contact Us')
            send_mail('Project Enquiry on info@ris-ai.com',
                      '\nName :' + name + '\nEmail:' + email + '\nContact Number:' + str(
                          contact_number) + '\nSubject :' + subject,
                      DEFAULT_FROM_EMAIL, [DEFAULT_FROM_EMAIL], fail_silently=False)
            d = ({'email': email})
            plaintext = get_template('email.txt')
            htmly = get_template('email-templates/contact-us.html')
            subject, from_email, to = 'Thank You For Contacting Us', 'info@ris-ai.com', email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
            thankyou = True

    return render(request, "blog.html", locals())

#################################################################################################

# def state_list(request):
#     list = States_db.objects.filter(country_id=101)
#     return render(request, 'dashboard/state-list.html', locals())
#
def load_cities(request):
    state_id = request.GET.get('state_id')
    cities_list = Cities_db.objects.filter(state_id=state_id).order_by('name')
    return render(request, 'city_dropdown_list_options.html', {'cities_list': cities_list})
#
# def load_locality(request):
#     city_id = request.GET.get('id_city')
#     locality_list = Locality_db.objects.filter(city_id=city_id).order_by('name')
#     return render(request, 'dashboard/locality_dropdown_list_options.html', {'locality_list': locality_list})
#
#
# def load_main_course_category(request):
#     city_id = request.GET.get('city_id','')
#     if int(city_id) > 0:
#         request.session['city_id'] =[city_id]
#         request.session['city_selcetd'] = True
#     else:
#         request.session['city_id'] = []
#         request.session['city_selcetd'] = False
#     return HttpResponse('ok')
#
#
#
# class City_Autocomplete(autocomplete.Select2QuerySetView):
#     def get_queryset(self):
#         if self.request.session['city_selcetd'] == True:
#             qs = Locality_db.objects.filter(city_id__in=self.request.session['city_id']).order_by('name')
#             if self.q:
#                 qs = qs.filter(name__istartswith=self.q)
#             return qs
#         else:
#             qs = Cities_db.objects.filter(
#                 state_id__in=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
#                               26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40])
#             if self.q:
#                 qs = qs.filter(name__istartswith=self.q)
#             return qs
