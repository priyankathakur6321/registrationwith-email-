from django.contrib import admin
from .models import Blog_Db, Blog_view_db, Blog_Category_Db, User

# Register your models here.
admin.site.register(User)
admin.site.register(Blog_Db)
admin.site.register(Blog_view_db)
admin.site.register(Blog_Category_Db)
