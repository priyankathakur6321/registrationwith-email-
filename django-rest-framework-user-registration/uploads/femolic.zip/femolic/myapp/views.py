import math
import os
import random

from django.contrib.auth import login
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.hashers import check_password

from myapp.forms import SignUpForm, Blog_view_db_form, request_db_form, add_employee_db_form, UserLoginForm
from myapp.messages_send import sendotp
from django.core.mail import send_mail, EmailMultiAlternatives
from django.contrib import messages, auth
from django.template.loader import get_template

from myapp.models import Blog_Db, Blog_Category_Db, States_db, Cities_db, User,request_db
from myproject.settings import DEFAULT_FROM_EMAIL, BASE_DIR
import pyqrcode
import png
import qrcode
import cv2
# from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required

from pyqrcode import QRCode
key = 'V/eW+6qrm60-Bw8qAXFEKBlvbeOwyrVmMQD5AGl2f5'



def index(request):
    print(request.user)
    print('************************************************')
    blog_list = Blog_Db.objects.all()
    list = States_db.objects.filter(country_id=101)

    if request.method == "POST":
        print('##############################')
        form = request_db_form(request.POST, request.FILES)
        print(form, 'efrfgfg')
        if form.is_valid():
            print('142356656')
            f = form.save(commit=False)
            digit_1 = request.POST.get('digit_1')
            digit_2 = request.POST.get('digit_2')
            digit_3 = request.POST.get('digit_3')
            digit_4 = request.POST.get('digit_4')
            digit_5 = request.POST.get('digit_5')
            digit_6 = request.POST.get('digit_6')
            digit_7 = request.POST.get('digit_7')
            digit_8 = request.POST.get('digit_8')
            digit_9 = request.POST.get('digit_9')
            digit_10 = request.POST.get('digit_10')
            digit_11 = request.POST.get('digit_11')
            digit_12 = request.POST.get('digit_12')

            f.name = request.POST['name']
            f.address = request.POST['address']
            f.state = request.POST['state']
            city_id=request.POST['city']
            city = [c.name for c in Cities_db.objects.filter(id=city_id)]

            f.city = city[0]

            # f.latlong = request.POST['latlong']
            f.latitude = request.POST['latitude']
            f.longitude = request.POST['longitude']
            f.email = request.POST['email']
            f.phone_number = request.POST['phone_number']
            aadhar_card = digit_1 + digit_2 + digit_3 + digit_4 + digit_5 + digit_6 + digit_7 + digit_8 + digit_9 + digit_10 + digit_11 + digit_12
            f.aadhar_card = aadhar_card
            aadhar_card=str(aadhar_card)
            print('###############')
            form.save()
            print('save')

            # to generate random id
            rn=random.randint(100000, 999970)
            state= request.POST['state']
            state = [c.state_code for c in States_db.objects.filter(name=state)]
            s_rn=str(state[0])
            generate_code =f"{s_rn}-{rn}"
            print(generate_code,"---------------lrn")


            # to create qr code img
            domain = "http://localhost:8000"
            view_link = "/view_user_detail/"
            qr_link = f"{domain}{view_link}{generate_code}"
            img_qr= qrcode.make(qr_link)
            folder_path = os.path.join(BASE_DIR, "media/qr_image/")
            img_name=f"{folder_path}{generate_code}.png"
            # qr_code_image=img_qr.png(img_name, scale=6)
            img_qr.save(img_name)
            print(img_qr,"----------------gr_img")
            db_img_save=f"/qr_image/{generate_code}.png"

            #  to save random_id and qr_code_img
            obj=request_db.objects.get(aadhar_card=aadhar_card)
            print(obj,'***************')
            obj.user_id=generate_code
            obj.qr_code_image=db_img_save
            obj.save()
            print('objsave')

            # to read qr code img
            d = cv2.QRCodeDetector()
            val, points, straight_qrcode = d.detectAndDecode(cv2.imread(img_name))
            print(val,"---------------")

            # if randomnumber not in [c.user_id for c in Views_On_Property.objects.all()]:
            #     request.session['set_my_id'] = randomnumber
            # else:
            #     randomnumber = random.randint(-50000, -11)
            #     print(randomnumber)
            return HttpResponseRedirect('/')

    else:
        request_db_form()
    return render(request, 'index.html', locals())


# def login(request):
#     return render(request, 'login.html', locals())

def otp(request):
    return render(request, 'otp.html', locals())

def get_location(request):
    if request.method=="POST":
        address=request.POST.get("address")
        lat=request.POST.get("latitude")
        long=request.POST.get("longitude")
        address = address.replace("#", "").split(" ")
        new_address = ""
        for addr in address:
            if address.index(addr) < (len(address) - 1):
                new_addr = f"{addr}+"
                new_address += new_addr
            else:
                new_address += addr
        print(new_address)

        go_to=f"https://www.google.co.in/maps/place/{new_address}/@{lat},{long}"
        return redirect(go_to)


def goverments(request):
    return render(request, 'goverments.html', locals())

def view_user_detail(request,generate_code):
    list=request_db.objects.filter(user_id=generate_code)
    # list={"list":list}
    # print(list)
    return render(request,'view_user_detail.html', locals())


def signin_with_phone(request):
    print("-----------------------------------------")
    digits = [i for i in range(0, 10)]
    generated_otp = ""
    for i in range(6):
        index_1 = math.floor(random.random() * 10)
        generated_otp += str(digits[index_1])
    print(generated_otp)
    form = SignUpForm()
    if 'step1_phone' in request.POST:
        entered_phone_number = request.POST['phone_number']
        print(entered_phone_number, type(entered_phone_number))
        if User.objects.filter(phone=entered_phone_number).exists():
            user = User.objects.get(phone=entered_phone_number)
            user.otp = generated_otp
            user.set_password(generated_otp)
            user.otp_expired = False
            user.save()
            check_message_sent = sendotp(key, entered_phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'otp.html', locals())
            else:
                phone_error = True
                print("error")
            print("exists")
        else:
            form = SignUpForm(request.POST)
            print(form)
            # if form.is_valid():
            user = User.objects.create_user(username=str(request.POST['phone_number']),
                                            password=generated_otp,
                                            is_active=False,
                                            is_seller=True,
                                            otp=generated_otp,
                                            otp_expired=False,
                                            phone=str(request.POST['phone_number']))

            phone_number = request.POST['phone_number']

            check_message_sent = sendotp(key, phone_number, generated_otp)
            if check_message_sent:
                return render(request, 'otp.html', locals())
            else:
                phone_error = True
    print("after-----------------------------")
    if 'otp_entered' in request.POST:
        entered_phone_number = request.POST['entered_phone_number']
        print(entered_phone_number, '*****')
        digit_1 = request.POST['digit-1']
        digit_2 = request.POST['digit-2']
        digit_3 = request.POST['digit-3']
        digit_4 = request.POST['digit-4']
        digit_5 = request.POST['digit-5']
        digit_6 = request.POST['digit-6']
        entered_otp = digit_1 + digit_2 + digit_3 + digit_4 + digit_5 + digit_6
        print(entered_otp, '###')
        print(type(entered_otp), '###')
        user = User.objects.get(phone=entered_phone_number)
        if check_password(entered_otp, user.password):
            print("matched")
            if not user.otp_expired:
                user.otp_expired = False
                user.is_active = True
                user.save()
                login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                # login(request, user)
                return redirect('index')
            elif user.otp_expired:
                otp_expired = True
                return render(request, 'otp.html', locals())


        else:
            otp_expired = True
            return render(request, 'otp.html', locals())
    return render(request, 'login.html', locals())




def blog(request):
    return render(request, 'blog.html', locals())


def blog_page(request):
    title = 'webtunix solutions'
    keywords = 'machine learning, business solutions'
    description = 'webtunix solutions - business solutions provider'

    blog_list = Blog_Db.objects.all()
    blog_category_list = Blog_Category_Db.objects.all()

    if request.method == "POST":
        form = Blog_view_db_form(request.POST, request.FILES)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            print(name, 'hcbskfh')
            email = form.cleaned_data.get('email')
            print(email, 'hbhcskdc')
            contact_number = form.cleaned_data.get('contact_number')
            print(contact_number, 'hdhchjcd')
            subject = form.cleaned_data.get('subject')
            print(subject, 'hdhhfc')
            form.save()
            print('save')
            saved = True
            messages.success(request, 'Thank-you for Contact Us')
            send_mail('Project Enquiry on info@ris-ai.com',
                      '\nName :' + name + '\nEmail:' + email + '\nContact Number:' + str(
                          contact_number) + '\nSubject :' + subject,
                      DEFAULT_FROM_EMAIL, [DEFAULT_FROM_EMAIL], fail_silently=False)
            d = ({'email': email})
            plaintext = get_template('email.txt')
            htmly = get_template('email-templates/contact-us.html')
            subject, from_email, to = 'Thank You For Contacting Us', 'info@ris-ai.com', email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
            thankyou = True

    return render(request, "blog.html", locals())


def blog_view(request):
    blog_list = Blog_Db.objects.all()
    blog_category_list = Blog_Category_Db.objects.all()

    if request.method == "POST":
        form = Blog_view_db_form(request.POST, request.FILES)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            print(name, 'hcbskfh')
            email = form.cleaned_data.get('email')
            print(email, 'hbhcskdc')
            contact_number = form.cleaned_data.get('contact_number')
            print(contact_number, 'hdhchjcd')
            subject = form.cleaned_data.get('subject')
            print(subject, 'hdhhfc')
            form.save()
            print('save')
            saved = True
            messages.success(request, 'Thank-you for Contact Us')
            send_mail('Project Enquiry on info@ris-ai.com',
                      '\nName :' + name + '\nEmail:' + email + '\nContact Number:' + str(
                          contact_number) + '\nSubject :' + subject,
                      DEFAULT_FROM_EMAIL, [DEFAULT_FROM_EMAIL], fail_silently=False)
            d = ({'email': email})
            plaintext = get_template('email.txt')
            htmly = get_template('email-templates/contact-us.html')
            subject, from_email, to = 'Thank You For Contacting Us', 'info@ris-ai.com', email
            text_content = plaintext.render(d)
            html_content = htmly.render(d)
            msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
            msg.attach_alternative(html_content, "text/html")
            msg.send()
            thankyou = True

    return render(request, "blog.html", locals())

#################################################################################################

# def state_list(request):
#     list = States_db.objects.filter(country_id=101)
#     return render(request, 'dashboard/state-list.html', locals())
#
def load_cities(request):
    state_id = request.GET.get('state_id')
    cities_list = Cities_db.objects.filter(state_id__name=state_id).order_by('name')
    print(cities_list,"cities---------------------------------")
    return render(request, 'city_dropdown_list_options.html', {'cities_list': cities_list})
#
# def load_locality(request):
#     city_id = request.GET.get('id_city')
#     locality_list = Locality_db.objects.filter(city_id=city_id).order_by('name')
#     return render(request, 'dashboard/locality_dropdown_list_options.html', {'locality_list': locality_list})
#
#
# def load_main_course_category(request):
#     city_id = request.GET.get('city_id','')
#     if int(city_id) > 0:
#         request.session['city_id'] =[city_id]
#         request.session['city_selcetd'] = True
#     else:
#         request.session['city_id'] = []
#         request.session['city_selcetd'] = False
#     return HttpResponse('ok')
#
#
#
# class City_Autocomplete(autocomp "request" lete.Select2QuerySetView):
#     def get_queryset(self):
#         if self.request.session['city_selcetd'] == True:
#             qs = Locality_db.objects.filter(city_id__in=self.request.session['city_id']).order_by('name')
#             if self.q:
#                 qs = qs.filter(name__istartswith=self.q)
#             return qs
#         else:
#             qs = Cities_db.objects.filter(
#                 state_id__in=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
#                               26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40])
#             if self.q:
#                 qs = qs.filter(name__istartswith=self.q)
#             return qs

################################ admin-panel ###################################################
@login_required(login_url="admin-login")
def admin_index(request):
    user_count = User.objects.all().count()
    request_accepted_count = request_db.objects.filter(request_accepted=True).count()
    pending_request_count = request_db.objects.filter(request_accepted="not_define").count()
    count_employee=User.objects.filter(user_type="emp").count()

    request_list=request_db.objects.filter(request_accepted=True)


    add_emp_list=User.objects.filter(user_type="emp")

    return render(request, 'admin-panel/index.html', locals())

def admin_login(request):
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():

            email = request.POST['email']
            password = request.POST['password']
            print(email,password,'================')
            try:
                print("tryyyyyyy--------------")
                username = User.objects.get(email=email.lower()).username
                print(username,"------uuuuuuuuuuuu")
                user = authenticate(request,username=username, password=password)
                print("authenticate")
            except:
                user = None
                messages.error(request, "Your Email Address or Password was not recognized")
                print("except")

            if user is not None:
                auth.login(request, user)
                print("if///////////////////////")

                return HttpResponseRedirect('/admin-index')
            else:
                messages.error(request, "Your Email Address or Password was not recognized")
                print("ghfh///////////////////////")

        else:
            print("ffffff///////////////////////")

            return render(request, "admin-panel/login.html", locals())



    else:
        form = UserLoginForm()
    return render(request, 'admin-panel/login.html', locals())

def users(request):
    list=request_db.objects.all()


    return render(request, 'admin-panel/users.html', locals())


def add_employee(request):
    add_emp_list=User.objects.filter(user_type="emp")
    form = add_employee_db_form()
    if request.method == "POST":
        form = add_employee_db_form(request.POST, request.FILES)
        print(form)
        if form.is_valid():
            password1=request.POST.get('password1')
            f1=form.save(commit=False)
            f1.user_type="emp"
            # f1.password=password1
            print('hfvjkfhg')
            f1.save()
            # f = form.save(commit=False)
            # form.save()
            print('save')
        else:
            print(form.errors)

    return render(request, 'admin-panel/add-employee.html', locals())



def delete_emp(request):
    if request.method == "POST":
        id = request.POST.get('del_emp')
        print(id)
        # emp = add_employee_db.objects.get(pk=id)
        emp = User.objects.get(user_type="emp",pk=id)
        emp.delete()
        return redirect("/add-employee")

def edit_add_emp(request):
    if request.method == "POST":
        id = request.POST.get('emp_edit')
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        emp_id = request.POST.get('emp_id')
        aadhar_card = request.POST.get('aadhar_card')
        designation = request.POST.get('designation')
        obj = User.objects.get(user_type="emp",id=id)
        obj.username = username
        obj.email = email
        obj.phone_number = phone_number
        obj.aadhar_card = aadhar_card
        obj.emp_id = emp_id
        obj.designation = designation

        obj.save()
        return redirect("/add-employee")

    return render(request, 'admin-panel/add-employee.html', locals())



def address_list(request):
    list=request_db.objects.filter(request_approved=True)

    return render(request, 'admin-panel/address-list.html', locals())

def delete_address_list(request):
    if request.method == "POST":
        id = request.POST.get('del_emp')
        print(id)
        emp = request_db.objects.get(pk=id)
        emp.delete()
        return redirect("/address-list")


def edit_address_list(request):
    if request.method == "POST":
        id = request.POST.get('address_edit')
        name = request.POST.get('name')
        phone_number = request.POST.get('phone_number')
        state = request.POST.get('state')
        city = request.POST.get('city')
        address = request.POST.get('address')
        obj = request_db.objects.get(id=id)
        obj.name = name
        obj.phone_number = phone_number
        obj.state = state
        obj.city = city
        obj.address = address

        obj.save()
        return redirect("/address-list")

    return render(request, 'admin-panel/address-list.html', locals())

def support_request_list(request):
    list=request_db.objects.filter(request_accepted="not_define", request_by_emp="False")


    return render(request, 'admin-panel/support-request.html', locals())

def request(request):
    add_emp_list=User.objects.filter(user_type="emp")
    request_list=request_db.objects.filter(request_accepted="not_define",request_by_emp="not_define")
    print("************************************")
    if request.method == "POST":
        print("+++++++delete req++++++++++++++")


        request_id = request.POST.get("delete_request")
        print(request_id, "ydgcfh")
        print(type(request_id))
        obj = request_db.objects.get(id=request_id)
        obj.request_accepted = False
        obj.save()
        return redirect("/request")
    # request_accepted = User.objects.filter(request_accepted="True")

    return render(request, 'admin-panel/request.html', locals())

def request_accepted(request):
    request_list=request_db.objects.filter(request_accepted=True)
    if request.method == "POST":
        print("+++++++++++++++++++++")
        selected_employee_id = request.POST.get("selected_employee_id")
        print(selected_employee_id,type(selected_employee_id),"oooooppppp")

        request_id = request.POST.getlist("request_checkbox")
        print(request_id, "ydgcfh")
        for req_id in request_id:
            print(req_id,type(req_id))
            obj = request_db.objects.get(id=req_id)
            # obj.request_emp_id = selected_employee_id
            obj.request_emp_id = User.objects.get(emp_id=selected_employee_id)
            obj.request_accepted = True
            obj.save()
            print("save", req_id)
        return redirect("/request-accepted")

    return render(request, 'admin-panel/request-accepted.html', locals())

def request_declined(request):
    request_list = request_db.objects.filter(request_accepted=False)
    add_emp_list=User.objects.filter(user_type="emp")

    if request.method == "POST":
        print("+++++++delete req++++++++++++++")

        request_id = request.POST.get("delete_request")
        print(request_id, "ydgcfh")
        print(type(request_id))
        obj = request_db.objects.get(id=request_id)
        obj.request_accepted = False
        obj.save()
        return redirect("/request")


    return render(request, 'admin-panel/request-declined.html', locals())


def search(request):
    if request.method == "POST":
        emp_id = request.POST.get('search')
        # add_emp_list=add_employee_db.objects.filter(emp_id=emp_id)
        add_emp_list=User.objects.filter(user_type="emp",emp_id=emp_id)

    return render(request, 'admin-panel/add-employee.html', locals())

def user_search(request):
    if request.method == "POST":
        id = request.POST.get('search')
        list=request_db.objects.filter(id=id)

    return render(request, 'admin-panel/users.html', locals())

def address_list_search(request):
    if request.method == "POST":
        phone_number = request.POST.get('phone_number')
        district = request.POST.get('district')
        state = request.POST.get('state')

        print(phone_number,"ppppppppppppppppppppp")
        print(district,"ddddddddddddddd")
        print(state,"sssssssssssssssssssss")
        phone_number_Q = Q()
        if phone_number:
            phone_number_Q = Q(phone_number__icontains=phone_number)

        district_Q = Q()
        if district:
            district_Q = Q(city__icontains=district)

        state_Q = Q()
        if state:
            state_Q = Q(state__icontains=state)



        list = request_db.objects.filter(phone_number_Q,district_Q,state_Q).distinct()
        # ,district_Q,state_Q,user_type_Q
        # list = User.objects.filter(city="2066").distinct()
        print(list,"-----------------------")


    return render(request, 'admin-panel/address-list.html', locals())

