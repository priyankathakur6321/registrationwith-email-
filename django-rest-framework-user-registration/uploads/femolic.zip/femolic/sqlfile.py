# import mysql.connector
# mydb = mysql.connector.connect(
#   host="localhost",
#   user="root",
#   password="",
#   port='3306',
#   database='location'
#
#
# )
#
# print(mydb)

from sqlalchemy import create_engine

import pymysql

import pandas as pd


locations_footfalls = pd.read_excel ('/home/webtunixpri/Downloads/1637216388-footfallsSample.xlsx')
print (locations_footfalls)
tableName = "locations_footfalls"

dataFrame = pd.DataFrame(data=locations_footfalls)

sqlEngine = create_engine('mysql+pymysql://root:@127.0.0.1/locationdata', pool_recycle=3600)

dbConnection = sqlEngine.connect()

try:

  frame = dataFrame.to_sql(tableName, dbConnection, if_exists='fail');

except ValueError as vx:

  print(vx)

except Exception as ex:

  print(ex)

else:

  print("Table %s created successfully." % tableName);

finally:

  dbConnection.close()