# Create your views here.
import math
import os
import random

import qrcode
from django.utils.decorators import method_decorator
from rest_framework.views import APIView

from apiapp.serializers import RegisterSerializer, EmployeeloginSerializer, RequestSerializer, demoSerializer, \
     EmployeeListSerializer
from django.contrib.sites.shortcuts import get_current_site
from rest_framework.generics import CreateAPIView, GenericAPIView
from allauth.account import app_settings as allauth_settings
from rest_auth.app_settings import (TokenSerializer, JWTSerializer, create_token)
from rest_auth.utils import jwt_encode

from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated

from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template

from django.views.decorators.debug import sensitive_post_parameters
from django.contrib.auth import (
    login as django_login,
    logout as django_logout
)

from django.utils.encoding import smart_str, force_bytes
from django.utils.http import urlsafe_base64_encode

from myapp.forms import SignUpForm
from myapp.messages_send import sendotp
from myapp.models import request_db, States_db, User, add_employee_db
from myapp.tokens import account_activation_token
from rest_auth.models import TokenModel

from myproject.settings import BASE_DIR
from django.contrib.auth.hashers import check_password
from django.contrib.auth import login, authenticate

sensitive_post_parameters_m = method_decorator(
    sensitive_post_parameters('password1', 'password2')
)
key = 'V/eW+6qrm60-Bw8qAXFEKBlvbeOwyrVmMQD5AGl2f5'

class AddRequest(CreateAPIView):
    permission_classes = (IsAuthenticated,)

    serializer_class = RegisterSerializer

    def post(self, request, format=None):
        serializer = RegisterSerializer(data=request.data)
        print("posting-------------")
        if serializer.is_valid():

            print("valid")
            serializer.save()


            aadhar_card = request.POST.get('aadhar_card')
            print(aadhar_card,type(aadhar_card),"------------------")

            state = request.POST.get('state')
            # to generate random id
            rn = random.randint(100000, 999970)
            state = [c.state_code for c in States_db.objects.filter(name=state)]
            s_rn = str(state[0])

            generate_code = f"{s_rn}-{rn}"
            print(generate_code, "---------------lrn")

            # to create qr code img
            domain = "http://localhost:8000"
            view_link = "/view_user_detail/"
            qr_link = f"{domain}{view_link}{generate_code}"
            img_qr = qrcode.make(qr_link)
            folder_path = os.path.join(BASE_DIR, "media/qr_image/")
            img_name = f"{folder_path}{generate_code}.png"
            # qr_code_image=img_qr.png(img_name, scale=6)
            img_qr.save(img_name)
            print(img_qr, "----------------gr_img")
            db_img_save = f"/qr_image/{generate_code}.png"

            #  to save random_id and qr_code_img
            obj = request_db.objects.get(aadhar_card=aadhar_card)
            print(obj, '***************')
            obj.user_id = generate_code
            obj.qr_code_image = db_img_save
            obj.request_by_emp=False
            print(request.user.id,"------------------ids")
            obj.request_emp_id=User.objects.get(id=request.user.id)
            # obj.user_type = "request"

            obj.save()
            print('objsave')


            headers = self.get_success_headers(serializer.data)
            # return Response(self.get_response_data(user), status=status.HTTP_200_OK, headers=headers)
            return Response(headers=headers,status=status.HTTP_200_OK, )

            # user = {'status': True, 'data': serializer.data, 'message': 'Single_Property_View'}
            # return Response(user, status=status.HTTP_200_OK)
            # return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

##################################### Employee api #######################################


class LoginView(GenericAPIView):
    permission_classes = (AllowAny,)
    serializer_class = EmployeeloginSerializer
    token_model = TokenModel

    @sensitive_post_parameters_m
    def dispatch(self, *args, **kwargs):
        return super(LoginView, self).dispatch(*args, **kwargs)

    def process_login(self):
        django_login(self.request, self.user)

    def get_response_serializer(self):
        if getattr(settings, 'REST_USE_JWT', False):
            response_serializer = JWTSerializer
            print(response_serializer)
        else:
            response_serializer = TokenSerializer
            print(response_serializer)
        return response_serializer

    def login(self):
        self.user = self.serializer.validated_data['user']
        if getattr(settings, 'REST_USE_JWT', False):
            self.token = jwt_encode(self.user)
        else:
            self.token = create_token(self.token_model, self.user,
                                      self.serializer)
        if getattr(settings, 'REST_SESSION_LOGIN', True):
            self.process_login()

    def get_response(self, ):
        serializer_class = self.get_response_serializer()
        if getattr(settings, 'REST_USE_JWT', False):
            data = {
                'user': self.user,
                'token': self.token
            }
            serializer = serializer_class(instance=data, context={'request': self.request})
        else:
            serializer = serializer_class(instance=self.token, context={'request': self.request})
        response = Response({'status': True, 'message': 'sucessfully', 'data': serializer.data},
                            status=status.HTTP_200_OK)
        if getattr(settings, 'REST_USE_JWT', False):
            from rest_framework_jwt.settings import api_settings as jwt_settings
            if jwt_settings.JWT_AUTH_COOKIE:
                from datetime import datetime
                expiration = (datetime.utcnow() + jwt_settings.JWT_EXPIRATION_DELTA)
                response.set_cookie(jwt_settings.JWT_AUTH_COOKIE,
                                    self.token,
                                    expires=expiration,
                                    httponly=True)

        return response

    def post(self, request, *args, **kwargs):
        self.request = request
        print(self.request.data)
        self.serializer = self.get_serializer(data=self.request.data, context={'request': request})
        self.serializer.is_valid(raise_exception=True)
        self.login()
        return self.get_response()

class Signin_With_Phone_Api(APIView):
    permission_classes = (AllowAny,)

    serializer_class = demoSerializer


    def post(self,request, *args, **kwargs):
        serializer = demoSerializer(data=request.data)
        digits = [i for i in range(0, 10)]
        generated_otp = ""
        for i in range(5):
            index_1 = math.floor(random.random() * 10)
            generated_otp += str(digits[index_1])
        print(generated_otp)
        form = SignUpForm()
        # entered_phone_number=request.POST['phone_number']
        entered_phone_number=request.POST.get('phone_number',False)
        print(entered_phone_number,type(entered_phone_number),"-----phone")

        entered_otp = request.POST.get('otp', False)
        print(entered_otp, type(entered_otp),"--------otp")

        if entered_otp:

                entered_phone_number = request.POST['phone_number']
                entered_otp = request.POST['otp']
                user = User.objects.get(phone=entered_phone_number)
                if check_password(entered_otp, user.password):
                    print("matched")
                    if not user.otp_expired:
                        user.otp_expired = False
                        user.is_active = True
                        user.save()
                        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                        # login(request, user)
                        # return redirect('post_property')
                        user = {'status': True,
                                'data': {'user_id': user.id},
                                'message': 'Successfully Login'}
                        return Response(user, status=status.HTTP_200_OK)
                    elif user.otp_expired:
                        otp_expired = True
                        user = {'message': 'Invalid Credentials'}
                        return Response(user, status=status.HTTP_400_BAD_REQUEST,)


                else:
                    otp_expired = True
                    user = {'message': 'Invalid Credentials'}
                    return Response(user, status=status.HTTP_400_BAD_REQUEST)



        if User.objects.filter(phone=entered_phone_number).exists():
            user=User.objects.get(phone=entered_phone_number)
            user.otp=generated_otp
            user.set_password(generated_otp)
            user.otp_expired=False
            user.save()
            check_message_sent = sendotp(key, entered_phone_number, generated_otp)
            if check_message_sent:
                msg_send = True
                # return render(request, 'confirm_otp.html', locals())
            else:
                msg_send = False

        else:
            form = SignUpForm(request.POST)
            print(form)
            # if form.is_valid():
            user= User.objects.create_user(username=str(request.POST['phone_number']),
                                         password=generated_otp,
                                         is_active = False,
                                         is_seller = True,
                                         otp = generated_otp,
                                         otp_expired = False,
                                         phone=str(request.POST['phone_number']))

            phone_number = request.POST['phone_number']

            check_message_sent = sendotp(key, phone_number, generated_otp)
            if check_message_sent:
                msg_send = True
            else:
                msg_send = False
        user = {'status': True, 'data': {'opt':generated_otp,'user_id':user.id,'msg_send':msg_send}, 'message': 'OTP SEND'}
        return Response(user, status=status.HTTP_200_OK)




class EmployeeRequests(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        queryset = request_db.objects.filter(request_emp_id_id=request.user.id)
        serializer = RequestSerializer(queryset, many=True)
        user = {'status': True, 'data': serializer.data, 'message': 'Assigned Request'}
        return Response(user, status=status.HTTP_200_OK)

class EmployeeListRequests(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        queryset = User.objects.filter(user_type="emp")
        serializer = EmployeeListSerializer(queryset, many=True)
        user = {'status': True, 'data': serializer.data, 'message': 'All Employees List'}
        return Response(user, status=status.HTTP_200_OK)