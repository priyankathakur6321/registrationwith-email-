"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from django.urls import path
from django.views.static import serve
from django.conf.urls.static import static

from myapp import views
from myapp import views
from myproject import settings
from myproject.settings import DEBUG
from django.conf.urls.static import static
from django.views.static import serve
from apiapp import views as api_views

urlpatterns = [
    url('AddRequest', api_views.AddRequest.as_view(), name="AddRequest"),
    url('LoginView', api_views.LoginView.as_view(), name="LoginView"),
    url('EmployeeRequests', api_views.EmployeeRequests.as_view(), name="EmployeeRequests"),
    url('signin_with_phone_api', api_views.Signin_With_Phone_Api.as_view(), name="signin_with_phone_api"),
    url('EmployeeListRequests', api_views.EmployeeListRequests.as_view(), name="EmployeeListRequests"),


]
if DEBUG == True:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
else:
    urlpatterns += [
        url(r'^static/(?P<path>.*)$', serve, {'document_root': settings.STATIC_ROOT}),
        url(r'^media/(?P<path>.*)$', serve, {'document_root': settings.MEDIA_ROOT}),

]



