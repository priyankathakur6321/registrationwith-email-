from django.contrib.auth import get_user_model, authenticate
from rest_framework import serializers
from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers, exceptions
from allauth.account import app_settings as allauth_settings
from allauth.utils import email_address_exists
from allauth.account.adapter import get_adapter
from allauth.account.utils import setup_user_email

from myapp.models import request_db, User
from myproject import settings

UserModel = User

class demoSerializer(serializers.ModelSerializer):
    phone_number = serializers.CharField(required=False, write_only=True)
    # phone_number = serializers.CharField(required=False, write_only=True)
    # is_active = serializers.CharField(required=False, write_only=True)
    # is_seller = serializers.CharField(required=False, write_only=True)
    otp = serializers.CharField(required=False, write_only=True)
    # otp_expired = serializers.CharField(required=False, write_only=True)
    class Meta:
        model = User
        fields = ['phone_number','otp']



class RegisterSerializer(serializers.ModelSerializer):

    name = serializers.CharField(required=allauth_settings.USERNAME_REQUIRED)
    email = serializers.EmailField(required=allauth_settings.EMAIL_REQUIRED)
    # password1 = serializers.CharField(required=True, write_only=True)
    # password2 = serializers.CharField(required=True, write_only=True)
    address = serializers.CharField(required=True, write_only=True)
    state = serializers.CharField(required=True, write_only=True)
    city = serializers.CharField(required=True, write_only=True)
    aadhar_card = serializers.CharField(required=True, write_only=True)
    latitude = serializers.CharField(required=True, write_only=True)
    longitude = serializers.CharField(required=True, write_only=True)
    phone_number = serializers.CharField(required=True, write_only=True)
    class Meta:
        model = request_db
        fields = ['name','address','email','city','state','latitude','longitude','phone_number','aadhar_card']

    def validate_email(self, email):
        email = get_adapter().clean_email(email)
        if allauth_settings.UNIQUE_EMAIL:
            if email and email_address_exists(email):
                raise serializers.ValidationError(
                    _("A user is already registered with this e-mail address."))
        return email

    # def validate_password1(self, password):
    #     return get_adapter().clean_password(password)
    #
    #
    #
    # def validate(self, data):
    #     if data['password1'] != data['password2']:
    #         raise serializers.ValidationError(
    #             _("The two password fields didn't match."))
    #     return data


######################### employee ##################33

class EmployeeloginSerializer(serializers.ModelSerializer):
    username = serializers.CharField(required=False, allow_blank=True)
    email = serializers.EmailField(required=False, allow_blank=True)
    password = serializers.CharField(style={'input_type': 'password'})

    class Meta:
        model = User
        fields = ['username','email','password']


    def _validate_email(self, email, password):
        user = None
        print(email, '_validate_email')

        if email and password:
            user = authenticate(email=email, password=password)
        else:
            msg = _('Must include "email" and "password".')
            raise exceptions.ValidationError(msg)
        return user

    def _validate_username(self, username, password):
        user = None

        if username and password:
            user = authenticate(username=username, password=password)
        else:
            msg = _('Must include "username" and "password".')
            raise exceptions.ValidationError(msg)

        return user

    def _validate_username_email(self, username, email, password):
        user = None

        if email and password:
            user = authenticate(email=email, password=password)
        elif username and password:
            user = authenticate(username=username, password=password)
        else:
            msg = _('Must include either "username" or "email" and "password".')
            raise exceptions.ValidationError(msg)
        print(user, '_validate_username_email')
        return user

    def validate(self, attrs):
        username = attrs.get('username')
        email = attrs.get('email')
        password = attrs.get('password')

        user = None

        print(email, '--------------=================', password)

        if email:
            try:
                username = UserModel.objects.get(email__iexact=email).get_username()
            except UserModel.DoesNotExist:
                pass

        if username:
            user = self._validate_username_email(username, '', password)
            print('pppppppppppppppppppppp')

        # Did we get back an active user?
        if user:
            if not user.is_active:
                msg = _('User account is disabled.')
                raise exceptions.ValidationError(msg)
        else:
            msg = _('Unable to log in with provided credentials. 777777')
            raise exceptions.ValidationError(msg)

        # If required, is the email verified?
        if 'rest_auth.registration' in settings.INSTALLED_APPS:
            from allauth.account import app_settings
            if app_settings.EMAIL_VERIFICATION == app_settings.EmailVerificationMethod.MANDATORY:
                email_address = user.emailaddress_set.get(email=user.email)
                if not email_address.verified:
                    raise serializers.ValidationError(_('E-mail is not verified.'))

        attrs['user'] = user
        return attrs

class RequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = request_db
        fields = fields = ['id','name','address','email','city','state','latitude','longitude','phone_number','aadhar_card','user_id','qr_code_image','request_accepted','request_approved','request_emp_id']

class EmployeeListSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = fields = ['username', 'first_name', 'last_name', 'email',
             'is_seller', 'phone','otp',
                           'otp_expired','phone2','is_active',
                           'phone_number','designation','emp_id','aadhar_card']

